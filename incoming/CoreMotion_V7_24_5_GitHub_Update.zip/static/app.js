import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {FBXLoader} from 'three/addons/loaders/FBXLoader.js';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';
const $ = id=>document.getElementById(id);
const DIRS=['S','SW','W','NW','N','NE','E','SE'];
const PRESETS=[
 ['idle','Idle',2.4,true],['walk','Walk',0.95,true],['run','Run',0.64,true],['heavy','Heavy Walk',1.2,true],
 ['sneak','Sneak',1.5,true],['jump','Jump',1.05,false],['fall','Fall',1.0,true],['roll','Roll',0.9,false],
 ['punch','Punch',0.74,false],['kick','Kick',0.95,false],['slash','Sword Slash',0.85,false],['combo','2-Hit Combo',1.25,false],
 ['shoot','Shoot',0.68,true],['block','Guard',1.4,true],['hit','Hit Reaction',0.7,false],['death','Death',1.4,false],
 ['swim','Swim',1.2,true],['wave','Wave',1.5,true]
];
const state={file:null,cutoutFile:null,model:null,pivot:null,rig:null,mixer:null,clips:[],style:'original',preset:'idle',playing:false,speed:1,time:0,dir:'S',angle:0,zoom:1.0,frames:16,selection:'idle',loaded:false,busy:false,exporting:false,fit:null,axis:null,face:null,axisPreset:'Y',modelSource:'generic',rigInfo:null,skeletonHelper:null,facingFlip:false,calibrationKey:null};
let renderer,scene,camera,hemi,key,fill,footFloorGuide, stage=$('stage'), last=performance.now();
const speedSlider=$('speedSlider');
const motionWorkspace={key:null,favorites:new Set(),variants:[],queue:[],running:false,switching:false,steps:[],index:0,repeatNumber:1,stepStart:0,stepEnd:1,nextId:1,selectedStep:0,timeline:null,elapsed:0};
const log=(message,where='aiProgress',error=false)=>{let el=$(where);el.textContent=message;el.classList.toggle('error',error)};
const $buttons=(selector,fn)=>document.querySelectorAll(selector).forEach(b=>b.addEventListener('click',()=>fn(b)));
function setup3d(){
 renderer=new THREE.WebGLRenderer({canvas:stage,antialias:true,alpha:true,preserveDrawingBuffer:true});
 renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.outputColorSpace=THREE.SRGBColorSpace;
 renderer.setClearColor(0x000000,0); renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.35;
 scene=new THREE.Scene(); scene.background=null;
 camera=new THREE.OrthographicCamera(-3.75,3.75,3.75,-3.75,0.01,100); camera.position.set(0,1.5,10);camera.lookAt(0,1.5,0);
 hemi=new THREE.HemisphereLight(0xbddfff,0x35405f,2.3);scene.add(hemi);
 key=new THREE.DirectionalLight(0xffffff,3.0);key.position.set(-3,6,5);scene.add(key);
 fill=new THREE.DirectionalLight(0x6c9bd9,1.9);fill.position.set(4,2,-4);scene.add(fill);
 // Preview-only reference for foot calibration. Never rendered into exported sprites.
 footFloorGuide=new THREE.GridHelper(5.5,14,0x52c5dc,0x39576c);
 footFloorGuide.position.y=-0.027;footFloorGuide.visible=false;
 footFloorGuide.material.transparent=true;footFloorGuide.material.opacity=.44;
 scene.add(footFloorGuide);
 stage.addEventListener('wheel',e=>{e.preventDefault();state.zoom=Math.max(.65,Math.min(2.5,state.zoom+(e.deltaY>0?-.08:.08)));camera.zoom=state.zoom;camera.updateProjectionMatrix()},{passive:false});
 let drag=false, prev=0;stage.addEventListener('pointerdown',e=>{if(v7PointerDown(e))return;drag=true;prev=e.clientX;stage.setPointerCapture(e.pointerId)});
 stage.addEventListener('pointerup',()=>{drag=false;v7PointerUp()});stage.addEventListener('pointercancel',()=>{drag=false;v7PointerUp()});
 stage.addEventListener('pointermove',e=>{if(v7PointerMove(e))return;if(!drag||!state.pivot)return;const dx=e.clientX-prev;prev=e.clientX;state.pivot.rotation.y += dx*.012});
 window.addEventListener('resize',resizeRenderer);resizeRenderer();
 requestAnimationFrame(tick);
}
function resizeRenderer(){const box=$('sceneWrap').getBoundingClientRect();if(box.width<1||box.height<1)return;renderer.setSize(box.width,box.height,false);camera.left=-3.75*box.width/box.height;camera.right=3.75*box.width/box.height;camera.top=3.75;camera.bottom=-3.75;camera.updateProjectionMatrix()}
function tick(now){requestAnimationFrame(tick);if(state.exporting)return;const d=Math.min(.05,(now-last)/1000);last=now;
 if(state.playing){
  if(motionWorkspace.running){workspaceTick(d)}
  else {
   state.time+=d*state.speed;
   // Original clip playback is unchanged by the Motion Workspace.
   if(hasMotion()&&!loopPlayback()&&state.time>=currentPeriod()){
    state.time=currentPeriod();state.playing=false;$('playBtn').textContent='↻ Replay';
   }
  }
 }
 // A paused frame is a held 3D pose, not a new animation evaluation.
 // The old updateAnimation-on-every-RAF behavior could repeatedly touch IK/ankles
 // while time was frozen. Scrubbing and slider changes explicitly re-evaluate once.
 if(state.playing&&state.loaded){if(!motionWorkspace.running)updateAnimation(state.time);updateProgressUI();}
 v7RenderScene();
}
function clearModel(){
 workspaceStopSequence();motionWorkspace.key=null;v7BeforeClear();
 if(state.skeletonHelper){scene.remove(state.skeletonHelper);state.skeletonHelper.geometry.dispose();state.skeletonHelper.material.dispose();state.skeletonHelper=null;}
 if(state.pivot){scene.remove(state.pivot);state.pivot.traverse(o=>{if(o.geometry&&!o.userData.keep)try{o.geometry.dispose()}catch{} });}
 state.pivot=null;state.model=null;state.fit=null;state.axis=null;state.face=null;state.rig=null;
 state.mixer=null;state.clips=[];state.time=0;state.loaded=false;state.rigInfo=null;state.facingFlip=false;state.calibrationKey=null;
}
const gltfLoader=new GLTFLoader();
// The compass rotates the outer pivot; the axis group corrects mesh coordinate axes.
// Separating the two makes directional sprites consistent after an orientation fix.
function standModel(){
 if(!state.fit||!state.axis)return;
 const fit=state.fit,pivot=state.pivot,prevY=pivot.rotation.y;
 pivot.rotation.y=0;fit.position.set(0,0,0);fit.scale.setScalar(1);pivot.updateMatrixWorld(true);
 const b=new THREE.Box3().setFromObject(state.face),sz=b.getSize(new THREE.Vector3());
 const height=Math.max(0.01,sz.y,sz.x*.85,sz.z*.85);
 const scale=3/height;
 fit.scale.setScalar(scale);
 fit.position.set(-(b.min.x+b.max.x)*scale/2,-b.min.y*scale,-(b.min.z+b.max.z)*scale/2);
 pivot.rotation.y=prevY;
 pivot.updateMatrixWorld(true);
}
function selectAxis(axisId){
 if(!state.axis)return;
 state.axisPreset=axisId;
 state.axis.rotation.set(0,0,0);
 if(axisId==='XL')state.axis.rotation.z=-Math.PI/2; // TripoSR sideways: head points left
 if(axisId==='XR')state.axis.rotation.z=Math.PI/2;
 if(axisId==='ZP')state.axis.rotation.x=-Math.PI/2;
 if(axisId==='ZN')state.axis.rotation.x=Math.PI/2;
 $('axisSelect').value=axisId;
 standModel();
 log('Orientation set to '+$('axisSelect').selectedOptions[0].text+'. Check the head, feet and facing.','orientationMessage');
}
function flipFacing(){
 if(!state.face)return;
 state.facingFlip=!state.facingFlip;
 state.face.rotation.y=state.facingFlip?Math.PI:0;
 standModel();
 log('Front/back flipped. The eight-direction compass is independent of model orientation.','orientationMessage');
}
function hasMotion(){return !!(state.loaded&&state.mixer&&state.selection.startsWith('clip::')&&state.clips.length);}
function analyzeRig(root){
 const info={meshCount:0,skinnedMeshes:0,bones:0,uniqueBoneNames:[],clips:[],trackSummary:[],issues:[],type:'static'};
 const boneSet=new Set();const nameSet=new Set();
 root.traverse(o=>{if(o.name)nameSet.add(o.name);if(o.isMesh)info.meshCount++;if(o.isSkinnedMesh){info.skinnedMeshes++;for(const b of (o.skeleton?.bones||[]))boneSet.add(b.name||'(unnamed)');}});
 info.bones=boneSet.size;info.uniqueBoneNames=Array.from(boneSet).sort();
 if(info.skinnedMeshes>0&&info.bones>0)info.type='skinned';
 else if(info.skinnedMeshes>0)info.issues.push('Skinned meshes exist but readable bones were not found.');
 else info.issues.push('This mesh has no skin weights. Animations cannot deform its arms or legs.');
 if(info.bones>0&&info.bones<10)info.issues.push('Fewer than 10 unique bones. Confirm that this rig can articulate the limbs.');
 info._names=nameSet;
 return info;
}
function validateClip(clip,names){
 const mismatched=[];
 for(const track of clip.tracks){
  const k=track.name.lastIndexOf('.');if(k<=0){mismatched.push(track.name);continue;}
  const target=track.name.substring(0,k);
  if(!names.has(target))mismatched.push(target);
 }
 return [...new Set(mismatched)];
}
function rigReport(){
 if(!state.rigInfo)return {status:'no model loaded'};
 const info=state.rigInfo;
 return {version:3,modelSource:state.modelSource,meshCount:info.meshCount,skinnedMeshes:info.skinnedMeshes,
  boneCount:info.bones,bones:info.uniqueBoneNames,animationClips:state.clips.map(c=>({name:c.name,durationSeconds:c.duration,tracks:c.tracks.length,missingTargets:validateClip(c,info._names)})),
  warnings:info.issues,orientation:state.axisPreset,flipped:state.facingFlip,
  note:'A GLB mesh is not a rig. Good results require weight-painted bones and correctly authored animation clips. Animation-only GLBs must use compatible bone names AND rest poses.'};
}
function updatePipelineUI(){
 const i=state.rigInfo,clips=state.clips.length;
 let status='No 3D model',summary='Generate a model, or load a GLB with a skeleton and animation clips.';
 if(i){
  if(i.skinnedMeshes&&clips){status='Rigged + animated';summary=`${i.skinnedMeshes} skinned mesh(es) · ${i.bones} bones · ${clips} usable clip(s). Real motion preview is available.`;}
  else if(i.skinnedMeshes){status='Rigged, no animation';summary=`${i.skinnedMeshes} skinned mesh(es) · ${i.bones} bones. Attach animation GLB files using the SAME skeleton and rest pose.`;}
  else if(clips){status='Animated transforms only';summary=`${clips} node animation(s), but no skinned humanoid. Limbs will not deform like a properly rigged character.`;}
  else{status='Static mesh (no rig)';summary='TripoSR created geometry but no skeleton. Move to a rigging tool, then import the rigged and animated GLB.';}
 }
 $('rigStatus').textContent=status;
 $('pipelineBadge').textContent=status;
 $('pipelineSummary').textContent=summary;
 $('inspectRigBtn').disabled=!state.loaded;
 $('rigReportBtn').disabled=!state.loaded;
 $('motionInput').disabled=!Boolean(i?.skinnedMeshes);
 $('bonesToggle').disabled=!Boolean(i?.skinnedMeshes);
 $('exportStaticBtn').disabled=!state.loaded;
 $('exportOneBtn').disabled=!Boolean(state.loaded&&clips);
 $('exportAllBtn').disabled=!Boolean(state.loaded&&clips);
 $('playBtn').disabled=!Boolean(state.loaded&&clips);
 $('scrub').disabled=!Boolean(state.loaded&&clips);
 if(!clips){state.playing=false;$('playBtn').textContent='▶ Play';$('motionName').textContent='Static pose';}
}
function showBones(visible){
 if(state.skeletonHelper){scene.remove(state.skeletonHelper);state.skeletonHelper.geometry.dispose();state.skeletonHelper.material.dispose();state.skeletonHelper=null;}
 if(!visible||!state.rigInfo?.skinnedMeshes)return;
 const helper=new THREE.SkeletonHelper(state.model);helper.material.depthTest=false;helper.material.transparent=true;helper.material.opacity=.75;
 helper.renderOrder=999;scene.add(helper);state.skeletonHelper=helper;
}
function showRigDetails(){
 $('rigJson').textContent=JSON.stringify(rigReport(),null,2);
 $('rigVeil').classList.add('show');
}
async function importAnimationGLB(file){
 if(!state.loaded||!state.rigInfo?.skinnedMeshes){log('Import a properly skinned GLB character before adding motion.','motionImportStatus',true);return;}
 const url=URL.createObjectURL(file);
 try{
  const g=await new Promise((resolve,reject)=>gltfLoader.load(url,resolve,undefined,reject));
  if(!g.animations?.length)throw new Error('No animation clips were found in this GLB.');
  let imported=0;const rejected=[];
  for(const c of g.animations){
   const missing=validateClip(c,state.rigInfo._names);
   if(missing.length){rejected.push(`${c.name}: missing target(s) ${missing.slice(0,4).join(', ')}`);continue;}
   // Compatible names are necessary, but different bone rest poses can still distort the animation.
   const copy=c.clone();let base=copy.name||'Animation';if(state.clips.some(x=>x.name===base))base=filename(file.name)+'_'+base;
   copy.name=base;state.clips.push(copy);imported++;
  }
  if(!imported)throw new Error('No compatible clips. '+rejected.slice(0,2).join(' | '));
  if(!state.mixer)state.mixer=new THREE.AnimationMixer(state.model);
  refreshClipUI();updatePipelineUI();chooseClip(state.clips[state.clips.length-imported]);
  log(`Added ${imported} real clip(s). ${rejected.length} incompatible clip(s) skipped. Skeleton names must match AND rest poses must agree.`, 'motionImportStatus',!!rejected.length);
 }catch(e){log(e.message,'motionImportStatus',true)}finally{URL.revokeObjectURL(url);$('motionInput').value='';}
}
async function loadModel(url,label='3D model',source='generic',persistentAssetId=null){
 log('Loading 3D model…');
 return new Promise((resolve,reject)=>gltfLoader.load(url,async g=>{
   try{
     let autoRig=null;
     if(g.scene&&!analyzeRig(g.scene).skinnedMeshes){
       log('Model generated. Automatically preparing it for animation…','aiProgress');
       autoRig=await v724RigCurrentGeneratedScene(g,label,source);
     }
     clearModel();const root=g.scene;
     root.updateMatrixWorld(true);
     const geometryBounds=new THREE.Box3().setFromObject(root);
     if(geometryBounds.isEmpty())throw new Error('This model has no visible 3D geometry');
     state.pivot=new THREE.Group();state.pivot.name='Compass direction';scene.add(state.pivot);
     state.fit=new THREE.Group();state.fit.name='Center and scale';state.pivot.add(state.fit);
     state.face=new THREE.Group();state.face.name='Front/back facing correction';state.fit.add(state.face);
     state.axis=new THREE.Group();state.axis.name='Editable imported mesh orientation';state.face.add(state.axis);
     state.axis.add(root);state.model=root;state.modelSource=source;state.calibrationKey=calibrationStorageKey(source,persistentAssetId||label);
     state.rigInfo=analyzeRig(root);
     state.clips=g.animations||[];
     if(state.clips.length===1&&/^(ArmatureAction|Action|Animation)$/i.test(state.clips[0].name)){
       const inferred=/sword|slash|swing|attack/i.test(label)?'Sword Swing':/walk/i.test(label)?'Walk':/run/i.test(label)?'Run':null;
       if(inferred)state.clips[0].name=inferred;
     }
     if(state.clips.length)state.mixer=new THREE.AnimationMixer(root);
     selectAxis(source==='triposr'&&autoRig?.result!=='created'?'XL':'Y');
     state.loaded=true;state.time=0;state.playing=false;
     mapMotionBones();
     restoreFootCalibration();
     v7LoadRig();
     v72TargetRest();
     v74UpdateRigStatus();
     $('emptyState').style.display='none';$('previewTitle').textContent=label;
     $('bonesToggle').checked=false;
     setDirection(state.dir);refreshClipUI();applyStyle(state.style);
     updatePipelineUI();
     if(state.clips.length){chooseClip(state.clips[0]);$('motionHint').textContent='Playing imported GLB clip. Choose presets or clips, or attach additional motion with an identical skeleton.';log('Animated GLB loaded. Select clips or import matching motion files.');}
     else {$('motionName').textContent='Static pose';$('motionHint').textContent='No animation clips were found. Static meshes cannot walk or attack until rigged and animated. Use the Rigging & Motion panel.';log('Static mesh loaded. It needs a proper rig for animations.');}
     resolve();
   }catch(e){log(e.message,'aiProgress',true);reject(e)}
 },undefined,e=>{log('Unable to open GLB: '+e.message,'aiProgress',true);reject(e)}));
}
function updateAnimation(time){
 // Deterministically resample source GLB, then apply non-destructive corrective motion layers.
 // Remove the previous procedural root bob before resampling the original clip.
 // This avoids accumulating vertical drift across preview and sprite frames.
 if(v78State.lastBounce&&v78State.lastBounce.root===state.model){
   state.model.position.y-=v78State.lastBounce.offset;v78State.lastBounce=null;
 }
 updateMotionLab(time);
 v7ApplyLayer();
 v78ApplyMotionStyle(time);
}
function setDirection(dir){state.dir=dir;const angle=DIRS.indexOf(dir)*Math.PI/4;if(state.pivot)state.pivot.rotation.y=angle;
 document.querySelectorAll('#compass button').forEach(el=>el.classList.toggle('active',el.dataset.dir===dir));$('directionStatus').textContent='Facing '+dir;}
function setPreset(name){
 if(!state.loaded){$('motionHint').textContent='Load a rigged and animated character first.';return;}
 if(!state.clips.length){$('motionHint').textContent='This is a static mesh. A real animation requires a skeleton, skin weights and motion clips.';return;}
 const pattern={idle:/idle|breath|stand/i,walk:/walk/i,run:/run|sprint/i,heavy:/heavy/i,sneak:/sneak|crouch/i,jump:/jump/i,fall:/fall/i,roll:/roll/i,punch:/punch/i,kick:/kick/i,slash:/slash|sword|attack/i,combo:/combo/i,shoot:/shoot|fire/i,block:/guard|block/i,hit:/hit|damage/i,death:/death|die/i,swim:/swim/i,wave:/wave/i}[name];
 const matched=state.clips.find(c=>pattern?.test(c.name));
 if(matched){chooseClip(matched);$('motionHint').textContent='Playing real embedded animation: '+matched.name;return;}
 $('motionHint').textContent='No '+name+' clip is available. Import a compatible animation GLB or select another clip. No fake animation was created.';
}
function chooseClip(clip){
 if(!state.mixer||!clip)return;
 if(motionWorkspace.running&&!motionWorkspace.switching)workspaceStopSequence();
 state.selection='clip::'+clip.name;state.preset='clip';state.time=0;state.mixer.stopAllAction();
 state.mixer.clipAction(clip).reset().play();state.mixer.setTime(0);
 labState.endKey=''; labState.endPose=null;
 captureLabAnchors();v78LoadForClip();updateAnimation(0);updateProgressUI();refreshPlaybackLabel();
 document.querySelectorAll('.preset').forEach(b=>b.classList.toggle('active',b.textContent.toLowerCase()===clip.name.toLowerCase()));
 $('motionName').textContent=clip.name;state.playing=true;$('playBtn').textContent='❚❚ Pause';
 $('clipSelect').value=String(state.clips.indexOf(clip));updatePipelineUI();
 if($('wsCurrentClip'))$('wsCurrentClip').textContent=clip.name;
 v71RefreshCatalog();v71GuideMessage('Previewing '+clip.name+'. Select an art style or export its sprite sheet.');
 const current=$('v74CurrentMotion');if(current)current.textContent='Selected: '+clip.name;
}
function refreshClipUI(){v71RefreshCatalog();const sec=$('clipsSection'),sel=$('clipSelect');sec.style.display=state.clips.length?'block':'none';sel.innerHTML='<option value="">Choose a clip...</option>';
 state.clips.forEach((c,i)=>{const o=document.createElement('option');o.value=i;o.textContent=c.name+' ('+c.duration.toFixed(1)+'s)';sel.append(o)});refreshBatchClips();workspaceRefresh()}
function applyStyle(name){state.style=name;document.querySelectorAll('.styleChoice').forEach(b=>b.classList.toggle('active',b.dataset.style===name));
 $('styleBadge').textContent=({'original':'Original texture','pixel':'Pixel art','toon':'Cel shaded','paint':'Hand-painted','silhouette':'Silhouette','gold':'Gold/bronze','mono':'Monochrome','cyber':'Cyberpunk'}[name]);
 v71GuideMessage('Rendering look: '+$('styleBadge').textContent+'. Choose an animation next.');
 if(!state.loaded)return;
 state.pivot.traverse(o=>{
   if(!o.isMesh)return;
   const base=o.userData.originalMaterial||(o.userData.originalMaterial=o.material);
   if(name==='original'||name==='pixel'){o.material=base;return;}
   const styleMat=(m)=>{
     const color=m.color?.clone()||new THREE.Color(0x879fb0);
     if(name==='toon')return new THREE.MeshToonMaterial({color,map:m.map||null,vertexColors:!!m.vertexColors,side:THREE.DoubleSide});
     if(name==='paint')return new THREE.MeshStandardMaterial({color,map:m.map||null,vertexColors:!!m.vertexColors,roughness:1,metalness:0,flatShading:true,side:THREE.DoubleSide});
     if(name==='silhouette')return new THREE.MeshBasicMaterial({color:0x07101b,side:THREE.DoubleSide});
     if(name==='gold')return new THREE.MeshStandardMaterial({color:0xb99651,roughness:.8,metalness:.35,side:THREE.DoubleSide});
     if(name==='mono')return new THREE.MeshStandardMaterial({color:0xadb9c4,roughness:1,flatShading:true,side:THREE.DoubleSide});
     if(name==='cyber')return new THREE.MeshStandardMaterial({color:0x14456f,roughness:.4,metalness:.45,emissive:0x071a32,emissiveIntensity:.8,side:THREE.DoubleSide});
     return m;
   };
   o.material=Array.isArray(base)?base.map(styleMat):styleMat(base);
 });
}
function currentPeriod(){
 if(state.selection.startsWith('clip::'))return state.clips.find(c=>c.name===state.selection.slice(6))?.duration||1;
 return 1;
}
// Non-cyclic actions (sword swings, hits, jumps) should never snap back to frame zero.
// The loop setting affects *preview and export*, not the source GLB animation.
function loopPlayback(){
 const mode=$('playbackMode')?.value||'auto';
 if(mode==='loop')return true;
 if(mode==='once')return false;
 return /idle|walk|run|sprint|sneak|swim|guard|block|breath|hover/i.test(state.selection.slice(6));
}
function refreshPlaybackLabel(){
 if(!$('playbackHint'))return;
 const looping=loopPlayback();
 $('playbackHint').textContent=looping?
  'Loop preview: continuous cycles. Motion Lab can blend the loop seam to avoid a visible reset.':
  'One-shot: ends and freezes the final pose. Pausing will not reapply foot corrections.';
}

function updateProgressUI(){
 if(!state.loaded||!state.clips.length){$('frameBadge').textContent=state.loaded?'Static pose':'No model';$('timeText').textContent='No animation';$('scrub').value=0;return;}
 const period=currentPeriod(),t=loopPlayback()?((state.time/period)%1+1)%1:THREE.MathUtils.clamp(state.time/period,0,1);
 $('scrub').value=t*1000;$('timeText').textContent=`${(t*period).toFixed(2)}s / ${period.toFixed(2)}s`;
 const n=Number($('countSelect').value),current=loopPlayback()?Math.min(n-1,Math.floor(t*n)):Math.min(n-1,Math.round(t*(n-1)));$('frameBadge').textContent=`Frame ${current+1} / ${n}`;
 document.querySelectorAll('#frames .frame').forEach((el,i)=>el.classList.toggle('active',i===(loopPlayback()?Math.min(7,Math.floor(t*8)):Math.min(7,Math.round(t*7)))));
}
function buildTimeline(){const div=$('frames');div.innerHTML='';for(let i=0;i<8;i++){const b=document.createElement('button');b.className='frame';b.textContent=String(i+1).padStart(2,'0');b.addEventListener('click',()=>{state.playing=false;$('playBtn').textContent='▶ Play';state.time=currentPeriod()*(loopPlayback()?i/8:i/7);updateAnimation(state.time);updateProgressUI()});div.appendChild(b)}}
async function askBg(){if(!state.file)return;log('Running local background removal…');$('removeBgBtn').disabled=true;
 try{const fd=new FormData();fd.append('image',state.file);const r=await fetch('/api/remove-background',{method:'POST',body:fd});const data=await r.json();if(!r.ok)throw Error(data.detail||'Background removal failed');const resp=await fetch(data.url);state.cutoutFile=new File([await resp.blob()],'character_no_background.png',{type:'image/png'});$('cutoutPreview').src=URL.createObjectURL(state.cutoutFile);$('cutoutPreview').style.display='block';log('Background removed. Ready to generate the 3D character.');}
 catch(e){log(e.message,'aiProgress',true)}finally{$('removeBgBtn').disabled=false}}
async function generate(){if(!state.file)return;state.busy=true;$('generateBtn').disabled=true;log('Sending image to your local TripoSR process…');
 try{const fd=new FormData();fd.append('image',state.cutoutFile||state.file);const r=await fetch('/api/generate-3d',{method:'POST',body:fd});const d=await r.json();if(!r.ok)throw Error(d.detail||'Generation failed');
 const id=d.job_id;
 while(true){await new Promise(res=>setTimeout(res,1300));const resp=await fetch('/api/jobs/'+id);const j=await resp.json();log(j.message);if(j.status==='error')throw Error(j.message);if(j.status==='done'){await loadModel(j.result,'AI-generated character · TripoSR','triposr');break;}}
 }catch(e){log(e.message,'aiProgress',true)}finally{state.busy=false;$('generateBtn').disabled=!state.file}}
function filename(s){return String(s||'character').replace(/[^a-z0-9_-]/gi,'_').slice(0,50)}
function dataURLBlob(canvas){return new Promise(resolve=>canvas.toBlob(resolve,'image/png'))}
const crcTable=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let j=0;j<8;j++)c=c&1?0xedb88320^(c>>>1):c>>>1;crcTable[n]=c>>>0}
function crc32(data){let c=0xffffffff;for(let i=0;i<data.length;i++)c=crcTable[(c^data[i])&255]^(c>>>8);return(c^0xffffffff)>>>0}
function rawZip(files){const blocks=[],cd=[];let offset=0;const enc=new TextEncoder();const w16=(dv,o,v)=>dv.setUint16(o,v,true),w32=(dv,o,v)=>dv.setUint32(o,v,true);
 for(const f of files){const n=enc.encode(f.name),data=f.bytes,c=crc32(data);const local=new Uint8Array(30+n.length+data.length),view=new DataView(local.buffer);w32(view,0,0x04034b50);w16(view,4,20);w16(view,8,0);w32(view,14,c);w32(view,18,data.length);w32(view,22,data.length);w16(view,26,n.length);local.set(n,30);local.set(data,30+n.length);blocks.push(local);
 const dir=new Uint8Array(46+n.length),d=new DataView(dir.buffer);w32(d,0,0x02014b50);w16(d,4,20);w16(d,6,20);w32(d,16,c);w32(d,20,data.length);w32(d,24,data.length);w16(d,28,n.length);w32(d,42,offset);dir.set(n,46);cd.push(dir);offset+=local.length;
 }
 let cdSize=cd.reduce((s,b)=>s+b.length,0);const end=new Uint8Array(22),dv=new DataView(end.buffer);w32(dv,0,0x06054b50);w16(dv,8,files.length);w16(dv,10,files.length);w32(dv,12,cdSize);w32(dv,16,offset);return new Blob([...blocks,...cd,end],{type:'application/zip'})}
function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000)}
// V6.3: ROOT-MOTION STABILIZATION IN ALL THREE DIMENSIONS.
// Walking clips can travel toward/away from the camera when the model is rotated
// to diagonal views. Simply following world X (V6.2) let the mesh cross the
// camera's NEAR clipping plane and made later SW frames disappear.
// During export ONLY, apply the inverse X/Z root displacement to the outer
// compass pivot. The original animation, vertical jumps, GLB, and preview
// remain untouched. A single fitted camera is shared by all 8 directions.
function exportRigAnchor(){
 if(labState.bones?.hips?.isBone)return labState.bones.hips;
 const root=state.model?.getObjectByName('bone_0');if(root?.isBone)return root;
 let firstSkin=null;state.model?.traverse(o=>{if(!firstSkin&&o.isSkinnedMesh&&o.skeleton?.bones?.length)firstSkin=o});
 if(firstSkin){const bones=firstSkin.skeleton.bones;return bones.find(b=>!b.parent?.isBone)||bones[0]}
 return state.model;
}
function exportVisibleBounds(){
 state.pivot.updateMatrixWorld(true);
 // Skinned mesh bounds must be recomputed for the current bone pose.
 state.model.traverse(o=>{
  if(!o.isSkinnedMesh||!o.visible)return;
  // Three.js does not refresh a SkinnedMesh's cached bounding sphere on each
  // animation sample. The exporter measures a fresh box; refresh the sphere too.
  // Without this, the renderer may decide a visible character is off-screen.
  if(typeof o.computeBoundingBox==='function')o.computeBoundingBox();
  if(typeof o.computeBoundingSphere==='function')o.computeBoundingSphere();
 });
 const box=new THREE.Box3().setFromObject(state.model,true);
 if(box.isEmpty()||[box.min.x,box.min.y,box.min.z,box.max.x,box.max.y,box.max.z].some(v=>!Number.isFinite(v)))throw new Error('Cannot compute animated model bounds.');
 return box;
}
function exportSampleTime(index,count,period){
 if(count<=1)return 0;
 return period*index/(loopPlayback()?count:count-1);
}
// Samples the animation with the pivot at its original position, measures
// skeletal root travel, and then offsets the entire model in X and Z only.
// This must happen AFTER updateAnimation, since bone-specific IK needs its
// original world-space pose. Y is intentionally unchanged for jumps/falls.
function exportInPlacePose(time,dir,reference,anchor,anchorPoint){
 state.pivot.position.set(0,0,0);
 state.pivot.rotation.y=DIRS.indexOf(dir)*Math.PI/4;
 updateAnimation(time);
 state.pivot.updateMatrixWorld(true);
 const p=anchor.getWorldPosition(anchorPoint);
 state.pivot.position.set(reference.x-p.x,0,reference.z-p.z);
 state.pivot.updateMatrixWorld(true);
 return exportVisibleBounds();
}
async function prepareExportCameraPlan(forcedStill=false,frameCountOverride=null){
 if(!state.loaded||!state.pivot)throw new Error('No 3D character loaded');
 const count=forcedStill?1:(frameCountOverride??Number($('countSelect').value)),period=currentPeriod();
 const oldTime=state.time,oldRot=state.pivot.rotation.y,oldPosition=state.pivot.position.clone();
 const anchor=exportRigAnchor(),anchorPos=new THREE.Vector3();
 const refs={},extent={minX:Infinity,maxX:-Infinity,minY:Infinity,maxY:-Infinity,minZ:Infinity,maxZ:-Infinity};
 try{
  for(let d=0;d<DIRS.length;d++){
   const dir=DIRS[d];
   state.pivot.position.set(0,0,0);state.pivot.rotation.y=d*Math.PI/4;
   updateAnimation(0);state.pivot.updateMatrixWorld(true);
   refs[dir]=anchor.getWorldPosition(anchorPos).clone();
   for(let i=0;i<count;i++){
    const bound=exportInPlacePose(exportSampleTime(i,count,period),dir,refs[dir],anchor,anchorPos);
    extent.minX=Math.min(extent.minX,bound.min.x);extent.maxX=Math.max(extent.maxX,bound.max.x);
    extent.minY=Math.min(extent.minY,bound.min.y);extent.maxY=Math.max(extent.maxY,bound.max.y);
    extent.minZ=Math.min(extent.minZ,bound.min.z);extent.maxZ=Math.max(extent.maxZ,bound.max.z);
   }
   if(d%2===1)await new Promise(done=>setTimeout(done,0));
  }
  const width=extent.maxX-extent.minX,height=extent.maxY-extent.minY;
  if(!Number.isFinite(width+height)||width<=0||height<=0)throw new Error('Invalid animated bounds during export.');
  const framing=Number($('exportFitSlider').value)/100;
  // Fit all sampled poses, across all directions, with at least 12% padding.
  // A single camera transform prevents East/West walk frames changing scale.
  const half=Math.max(width,height)*.5*Math.max(1.12,1.25*framing);
  const cameraZ=extent.maxZ+Math.max(10,extent.maxZ-extent.minZ+5);
  const cameraFar=Math.max(100,cameraZ-extent.minZ+25);
  return {halfExtent:Math.max(.15,half),centerX:(extent.minX+extent.maxX)/2,centerY:(extent.minY+extent.maxY)/2,
    cameraZ,cameraFar,refs,width,height,frames:count,stabilization:'XZ-pivot',
    measuredBounds:{...extent},framingMode:'fixed-camera-straight-on'};
 }finally{
  state.pivot.rotation.y=oldRot;state.pivot.position.copy(oldPosition);
  updateAnimation(oldTime);state.pivot.updateMatrixWorld(true);
 }
}
// Export diagnostics work on alpha, not RGB. Transparent black character parts
// still count as pixels. We reject frames that are blank OR touch an edge.
function exportAlphaBounds(ctx,x,y,size){
 const pixels=ctx.getImageData(x,y,size,size).data;
 let l=size,t=size,r=-1,b=-1,count=0;
 for(let py=0;py<size;py++)for(let px=0;px<size;px++){
  if(pixels[(py*size+px)*4+3]<8)continue;
  l=Math.min(l,px);r=Math.max(r,px);t=Math.min(t,py);b=Math.max(b,py);count++;
 }
 return count?{left:l,right:r,top:t,bottom:b,count}:null;
}
function exportBoundsInsideFrame(b,size){
 if(!b)return false;
 const pad=Math.max(2,Math.floor(size*.015));
 return b.left>=pad&&b.right<size-pad&&b.top>=pad&&b.bottom<size-pad;
}
async function renderSheet(dir,forcedStill=false,plan=null,frameCountOverride=null){
 const count=forcedStill?1:(frameCountOverride??Number($('countSelect').value)),size=Number($('sizeSelect').value),columns=forcedStill?1:Number($('colSelect').value),rows=Math.ceil(count/columns);
 if(!DIRS.includes(dir))throw new Error('Invalid export direction');
 const layout=plan||await prepareExportCameraPlan(forcedStill);
 const sheet=document.createElement('canvas');sheet.width=size*columns;sheet.height=size*rows;
 if(sheet.width>16384||sheet.height>16384)throw new Error('Sprite sheet is too large for this browser. Reduce frame size or columns.');
 const ctx=sheet.getContext('2d',{willReadFrequently:true});ctx.clearRect(0,0,sheet.width,sheet.height);
 const oldTime=state.time,oldRot=state.pivot.rotation.y,oldPosition=state.pivot.position.clone();
 const oldSize=new THREE.Vector2();renderer.getSize(oldSize);
 const oldRatio=renderer.getPixelRatio();
 const oldCam={left:camera.left,right:camera.right,top:camera.top,bottom:camera.bottom,near:camera.near,far:camera.far,zoom:camera.zoom,
   position:camera.position.clone(),quaternion:camera.quaternion.clone()};
 const helperVisible=state.skeletonHelper?.visible,footGuideVisible=footFloorGuide?.visible;
 // V6.6: avoid false frustum rejection of moving/skinned meshes during export.
 // Culling is a visibility optimization based on cached bounds, not a reliable
 // test of whether the animated vertices are visible. Always restore it later.
 const savedMeshCulling=[];
 state.model.traverse(o=>{
  if(o.isMesh){savedMeshCulling.push([o,o.frustumCulled]);o.frustumCulled=false;}
 });
 const pixelStyle=state.style==='pixel';const low=Math.min(size,Number($('pixelSelect').value));
 const renderSize=pixelStyle?low:Math.min(2048,size*2);
 const anchor=exportRigAnchor(),anchorPoint=new THREE.Vector3();
 try{
  renderer.setPixelRatio(1);renderer.setSize(renderSize,renderSize,false);
  camera.zoom=1;camera.left=-layout.halfExtent;camera.right=layout.halfExtent;
  camera.top=layout.halfExtent;camera.bottom=-layout.halfExtent;
  camera.near=.01;camera.far=layout.cameraFar;camera.updateProjectionMatrix();
  // DO NOT reuse the preview camera's quaternion: the preview can be tilted
  // toward a different target. Export uses a fixed +Z -> -Z camera; the
  // character's pivot rotation alone chooses the eight viewing directions.
  camera.quaternion.set(0,0,0,1);
  camera.position.set(layout.centerX,layout.centerY,layout.cameraZ);
  camera.updateMatrixWorld(true);
  if(state.skeletonHelper)state.skeletonHelper.visible=false;
  if(footFloorGuide)footFloorGuide.visible=false;
  for(let i=0;i<count;i++){
   const time=exportSampleTime(i,count,currentPeriod());
   const bound=exportInPlacePose(time,dir,layout.refs[dir],anchor,anchorPoint);
   // The measured world-space bbox must fit the *same* camera for every frame.
   // Never silently recenter individual frames: that creates jitter.
   const epsilon=1e-5;
   if(bound.min.x<layout.centerX-layout.halfExtent-epsilon||bound.max.x>layout.centerX+layout.halfExtent+epsilon||
      bound.min.y<layout.centerY-layout.halfExtent-epsilon||bound.max.y>layout.centerY+layout.halfExtent+epsilon||
      bound.max.z>=layout.cameraZ-camera.near||bound.min.z<=layout.cameraZ-layout.cameraFar){
     throw new Error(`${dir} frame ${i+1}/${count} exceeds the measured animation bounds; try Export framing 120%.`);
   }
   v7RenderScene();
   const x=(i%columns)*size,y=Math.floor(i/columns)*size;
   ctx.imageSmoothingEnabled=!pixelStyle;if(!pixelStyle)ctx.imageSmoothingQuality='high';
   ctx.clearRect(x,y,size,size);ctx.drawImage(renderer.domElement,x,y,size,size);
   const frame=exportAlphaBounds(ctx,x,y,size);
   if(!frame)throw new Error(`${dir} frame ${i+1}/${count} still rendered blank with mesh culling disabled. Export stopped; no incomplete pack was downloaded. This animation may need a source-GLB inspection.`);
   if(!exportBoundsInsideFrame(frame,size))throw new Error(`${dir} frame ${i+1}/${count} touches the image border. Increase Export framing for fully visible sprites.`);
   if(i%8===7)await new Promise(done=>setTimeout(done,0));
  }
  const blob=await dataURLBlob(sheet);
  if(!blob)throw new Error('Could not encode sprite sheet as PNG.');
  return blob;
 }finally{
  // Rendering optimizations must never leak back into the user's preview.
  for(const [mesh,previous] of savedMeshCulling)mesh.frustumCulled=previous;
  state.time=oldTime;state.pivot.rotation.y=oldRot;state.pivot.position.copy(oldPosition);
  if(state.skeletonHelper)state.skeletonHelper.visible=helperVisible;
  if(footFloorGuide)footFloorGuide.visible=footGuideVisible;
  renderer.setPixelRatio(oldRatio);renderer.setSize(oldSize.x,oldSize.y,false);
  camera.left=oldCam.left;camera.right=oldCam.right;camera.top=oldCam.top;camera.bottom=oldCam.bottom;
  camera.near=oldCam.near;camera.far=oldCam.far;camera.zoom=oldCam.zoom;
  camera.position.copy(oldCam.position);camera.quaternion.copy(oldCam.quaternion);
  camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
  updateAnimation(oldTime);state.pivot.updateMatrixWorld(true);v7RenderScene();
 }
}
async function exportSheets(all){if(!hasMotion()||state.exporting){log('Load an animated GLB clip before exporting animation frames.','exportProgress',true);return;}state.exporting=true;state.playing=false;$('playBtn').textContent='▶ Play';$('exportOneBtn').disabled=true;$('exportAllBtn').disabled=true;
 const dirs=all?DIRS:[state.dir];const files=[];
 try{log('Measuring full animation for stable framing…','exportProgress');const plan=await prepareExportCameraPlan(false);for(let i=0;i<dirs.length;i++){log(`Rendering direction ${dirs[i]} (${i+1}/${dirs.length})…`,'exportProgress');const blob=await renderSheet(dirs[i],false,plan);files.push({name:`core_keys_${filename(state.selection)}_${dirs[i]}_${$('sizeSelect').value}px.png`,bytes:new Uint8Array(await blob.arrayBuffer())});}
  if(all){files.push({name:'animation.json',bytes:new TextEncoder().encode(JSON.stringify({animation:state.selection,style:state.style,root_motion:'stabilized_XZ_pivot',auto_framed:true,frames:Number($('countSelect').value),frame_size:Number($('sizeSelect').value),columns:Number($('colSelect').value),fps:(Number($('countSelect').value)-(loopPlayback()?0:1))/currentPeriod(),loop:loopPlayback(),directions:DIRS,origin:'bottom center',background:'transparent'},null,2))});download(rawZip(files),`core_keys_${filename(state.selection)}_8_directions.zip`)}
  else download(new Blob([files[0].bytes],{type:'image/png'}),files[0].name);
  log('Export complete — transparent PNG sprites, aligned across directions.','exportProgress');
 }catch(e){log('Export error: '+e.message,'exportProgress',true)}finally{state.exporting=false;updatePipelineUI();last=performance.now()}}
// V6.7: production-first batch exporter, with independently sampled frame counts.
// Frame presets are recommendations, not speed adjustments or invented animation.
// 16 samples capture the full left/right stride in the user's working Walk GLB.
const BATCH_FRAME_OPTIONS=[8,16,24,32,40,48];
function recommendedFramesForClip(name){
 const n=String(name||'').toLowerCase();
 if(/combo|multi[ _-]?hit|chain[ _-]?attack/.test(n))return 24;
 if(/walk|run|sprint|jog|sneak|swim|crawl|dash|roll|climb|jump|fall|dodge/.test(n))return 16;
 if(/sword|slash|swing|attack|punch|kick|shoot|fire|death|hit[ _-]?react|wave|dance|kata/.test(n))return 16;
 return 8; // idle, breath, guard and unclassified clips
}
const batchSelectedNames=new Set();
const batchFramePrefs=new Map();
let activeFrameCharacterKey=null;
function batchFramePrefsKey(){return 'coremotion-export-frames-v1::'+(state.calibrationKey||'unidentified-character')}
function loadBatchFramePrefs(){
 const key=batchFramePrefsKey();
 if(activeFrameCharacterKey===key)return;
 activeFrameCharacterKey=key;
 batchFramePrefs.clear();batchSelectedNames.clear();
 try{
  const parsed=JSON.parse(localStorage.getItem(key)||'{}');
  if(parsed&&typeof parsed==='object'&&!Array.isArray(parsed))for(const [name,n] of Object.entries(parsed)){
   if(BATCH_FRAME_OPTIONS.includes(Number(n)))batchFramePrefs.set(name,Number(n));
  }
 }catch{} // Browser storage restrictions never block batch exports.
}
function saveBatchFramePrefs(){
 try{localStorage.setItem(batchFramePrefsKey(),JSON.stringify(Object.fromEntries(batchFramePrefs)))}catch{}
}
function framesForBatchClip(clip){
 const n=batchFramePrefs.get(clip.name);
 return BATCH_FRAME_OPTIONS.includes(n)?n:recommendedFramesForClip(clip.name);
}
let batchExportCancel=false;
function batchUpdateButton(){
 const button=$('batchExportBtn');if(!button)return;
 const n=state.clips.filter(c=>batchSelectedNames.has(c.name)).length;
 const selected=state.clips.filter(c=>batchSelectedNames.has(c.name));
 const samples=selected.reduce((sum,clip)=>sum+framesForBatchClip(clip),0)*DIRS.length;
 $('batchCount').textContent=`${n} selected · ${samples} frames`;
 button.disabled=!state.loaded||!n||state.exporting;
 button.textContent=n?`Export ${n} animation${n===1?'':'s'} × 8 directions (ZIP)`:'Choose animations to export';
}
function refreshBatchClips(){
 const list=$('batchClipList');if(!list)return;
 loadBatchFramePrefs();
 const current=state.clips.map(c=>c.name);
 // On first import select a small starter set, then preserve the user's selections.
 if(!current.some(name=>batchSelectedNames.has(name))&&current.length){
  const starters=state.clips.filter(c=>/idle|walk/i.test(c.name)).slice(0,2);
  (starters.length?starters:state.clips.slice(0,1)).forEach(c=>batchSelectedNames.add(c.name));
 }
 list.replaceChildren();
 if(!current.length){const t=document.createElement('span');t.className='tiny';t.textContent='Load a rigged character and its animation clips first.';list.append(t);}
 for(const [i,clip] of state.clips.entries()){
  const row=document.createElement('div');row.className='batchClipChoice';
  const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.value=clip.name;checkbox.id=`batchclip-${i}`;checkbox.checked=batchSelectedNames.has(clip.name);
  checkbox.addEventListener('change',()=>{if(checkbox.checked)batchSelectedNames.add(clip.name);else batchSelectedNames.delete(clip.name);batchUpdateButton();});
  const caption=document.createElement('label');caption.htmlFor=checkbox.id;caption.className='batchClipLabel';caption.textContent=`${clip.name} · ${clip.duration.toFixed(2)}s`;caption.title=caption.textContent;
  const frameSelect=document.createElement('select');frameSelect.className='batchFrameSelect';frameSelect.setAttribute('aria-label',`Frame count for ${clip.name}`);frameSelect.title=`Frames for ${clip.name} (suggested ${recommendedFramesForClip(clip.name)})`;
  const recommendation=recommendedFramesForClip(clip.name);
  for(const count of BATCH_FRAME_OPTIONS){const option=document.createElement('option');option.value=String(count);option.textContent=count+'f'+(count===recommendation?' ★':'');frameSelect.append(option)}
  frameSelect.value=String(framesForBatchClip(clip));
  frameSelect.addEventListener('change',()=>{batchFramePrefs.set(clip.name,Number(frameSelect.value));saveBatchFramePrefs();batchUpdateButton()});
  row.append(checkbox,caption,frameSelect);list.append(row);
 }
 batchUpdateButton();
}
function batchMessage(message,error=false){log(message,'batchProgress',error)}
async function exportProductionPack(){
 if(!state.loaded||!state.clips.length||state.exporting){batchMessage('Load an animated model before exporting.',true);return;}
 const selected=state.clips.filter(c=>batchSelectedNames.has(c.name));
 if(!selected.length){batchMessage('Select at least one animation.',true);return;}
 const totalSheets=selected.length*DIRS.length;
 const totalFrames=selected.reduce((s,c)=>s+framesForBatchClip(c)*DIRS.length,0);
 if(totalFrames>1800&&!confirm(`This export will render ${totalFrames} frames. Continue?`))return;
 const oldClip=state.clips.find(c=>state.selection==='clip::'+c.name)||state.clips[0];
 const oldTime=state.time,oldPlaying=state.playing,oldDir=state.dir;
 const data=[];const clipsMeta=[];
 batchExportCancel=false;state.exporting=true;state.playing=false;
 $('playBtn').textContent='▶ Play';$('batchCancelBtn').style.display='block';batchUpdateButton();
 let done=0;
 try{
  for(let j=0;j<selected.length;j++){
   if(batchExportCancel)break;
   const clip=selected[j];chooseClip(clip);state.playing=false;
   const clipFrames=framesForBatchClip(clip);
   const isLoop=loopPlayback();
   batchMessage(`Measuring ${clip.name} · ${clipFrames} frames per direction…`);
   const plan=await prepareExportCameraPlan(false,clipFrames);
   const folder=`animations/${String(j+1).padStart(2,'0')}_${filename(clip.name)}`;
   const m={name:clip.name,duration_seconds:clip.duration,frames:clipFrames,frame_size_px:Number($('sizeSelect').value),columns:Number($('colSelect').value),rows:Math.ceil(clipFrames/Number($('colSelect').value)),root_motion:'stabilized_XZ_pivot',auto_framed:true,visible_frames:clipFrames,loop:isLoop,fps:(clipFrames-(isLoop?0:1))/clip.duration,directions:{}};
   for(const dir of DIRS){
    if(batchExportCancel)break;
    batchMessage(`Rendering ${clip.name}: ${dir} · ${done+1}/${totalSheets} sheets`);
    const blob=await renderSheet(dir,false,plan,clipFrames);
    const name=`${folder}/${dir}.png`;
    data.push({name,bytes:new Uint8Array(await blob.arrayBuffer())});
    m.directions[dir]=name;done++;
    await new Promise(resolve=>setTimeout(resolve,0));
   }
   if(!batchExportCancel)clipsMeta.push(m);
  }
  if(batchExportCancel){batchMessage('Batch export stopped. No ZIP was downloaded.');return;}
  // Each animation now owns its frame count; never describe mixed counts as a single count.
  const counts=clipsMeta.map(c=>c.frames);
  const sharedCount=counts.every(n=>n===counts[0])?counts[0]:null;
  data.push({name:'manifest.json',bytes:new TextEncoder().encode(JSON.stringify({studio:'Core Motion Studio V6.7',art_style:state.style,frame_strategy:'per_animation',frames_per_clip:sharedCount,size_px:Number($('sizeSelect').value),columns:Number($('colSelect').value),directions:DIRS,transparent_background:true,root_motion:'stabilized_XZ_pivot',camera_framing:'fixed_camera_all_directions_per_clip',frames_verified_nonempty:true,animations:clipsMeta},null,2))});
  batchMessage(`Packaging ${clipsMeta.length} animations · ${done} directional sheets…`);
  download(rawZip(data),'CoreMotion_Animation_Sprite_Pack.zip');
  batchMessage(`Exported ${clipsMeta.length} animations, ${done} direction sheets, and manifest.json.`);
 }catch(error){batchMessage('Export failed: '+(error?.message||error),true)}
 finally{
  if(oldClip){chooseClip(oldClip);state.time=oldTime;updateAnimation(oldTime);}
  setDirection(oldDir);state.playing=oldPlaying;
  $('playBtn').textContent=oldPlaying?'❚❚ Pause':'▶ Play';
  state.exporting=false;$('batchCancelBtn').style.display='none';batchUpdateButton();updatePipelineUI();updateProgressUI();last=performance.now();
 }
}
$('batchSelectAll').addEventListener('click',()=>{state.clips.forEach(c=>batchSelectedNames.add(c.name));refreshBatchClips()});
$('batchSelectNone').addEventListener('click',()=>{batchSelectedNames.clear();document.querySelectorAll('#batchClipList input').forEach(el=>el.checked=false);batchUpdateButton()});
$('batchExportBtn').addEventListener('click',exportProductionPack);
$('batchCancelBtn').addEventListener('click',()=>{batchExportCancel=true;batchMessage('Stopping after the current direction…')});
$('batchResetFrames').addEventListener('click',()=>{batchFramePrefs.clear();saveBatchFramePrefs();refreshBatchClips();batchMessage('Recommended per-animation counts restored (Walk/Run 16f, Idle 8f).');});
$('applySingleFrameSuggestion').addEventListener('click',()=>{
 const clip=state.clips.find(c=>state.selection==='clip::'+c.name);
 if(!clip){log('Choose a real animation clip first.','exportProgress',true);return;}
 const n=framesForBatchClip(clip);
 $('countSelect').value=String(n);
 log(`${clip.name}: ${n} frames selected for single-animation export.`, 'exportProgress');
});

async function exportEightStillViews(){
 if(!state.loaded||state.exporting)return;
 state.exporting=true;state.playing=false;
 const files=[];const oldSelect=state.selection;const oldTime=state.time;
 try{
  const plan=await prepareExportCameraPlan(true);for(const dir of DIRS){log('Rendering static '+dir+' view…','exportProgress');const blob=await renderSheet(dir,true,plan);
   files.push({name:`core_keys_static_${dir}_${$('sizeSelect').value}px.png`,bytes:new Uint8Array(await blob.arrayBuffer())});
  }
  files.push({name:'README.txt',bytes:new TextEncoder().encode('These are EIGHT STILL VIEWS, not animation frames. Add a real rig and animation clips for motion sheets.\n')});
  download(rawZip(files),'core_keys_8_static_views.zip');log('Eight still PNG views exported.','exportProgress');
 }catch(e){log(e.message,'exportProgress',true)}finally{state.selection=oldSelect;state.time=oldTime;state.exporting=false;updatePipelineUI();last=performance.now()}
}
async function refreshStatus(){try{const r=await fetch('/api/status');const d=await r.json();$('backendStatus').innerHTML='<span class="statusdot"></span>Local backend online';$('triposrHome').value=d.settings.triposr_home||'';$('triposrPython').value=d.settings.triposr_python||'';$('meshRes').value=d.settings.mc_resolution;$('chunkSize').value=d.settings.chunk_size;
  if(d.model_ready)log('Local TripoSR configured. Upload a T-pose to generate 3D.');else log('3D generation needs local TripoSR setup (⚙ Settings).');
  if(!d.background_ready)$('removeBgBtn').title='Install rembg in the application environment';
 }catch(e){$('backendStatus').textContent='Backend not connected';log('Launch with start_windows.bat — not by double-clicking index.html.','aiProgress',true)}}
$('imageInput').addEventListener('change',e=>{state.file=e.target.files?.[0];state.cutoutFile=null;const p=$('inputPreview');if(!state.file)return;p.src=URL.createObjectURL(state.file);p.style.display='block';$('uploadSymbol').style.display='none';$('uploadLabel').textContent=state.file.name;$('removeBgBtn').disabled=false;$('generateBtn').disabled=false;$('cutoutPreview').style.display='none';log('Image selected. Remove background or generate a 3D model.')});
$('removeBgBtn').addEventListener('click',askBg);$('generateBtn').addEventListener('click',generate);
$('glbInput').addEventListener('change',e=>{const f=e.target.files?.[0];if(!f)return;const url=URL.createObjectURL(f);loadModel(url,f.name,/^mesh\.glb$/i.test(f.name)?'triposr':'generic').finally(()=>URL.revokeObjectURL(url));});
$('demoBtn').addEventListener('click',()=>loadModel('/examples/demo_robot.glb','Sample cyber-armored T-pose · demo'));
$('inspectRigBtn').addEventListener('click',showRigDetails);
$('rigReportBtn').addEventListener('click',()=>download(new Blob([JSON.stringify(rigReport(),null,2)],{type:'application/json'}),'core_motion_rig_report.json'));
$('rigCloseBtn').addEventListener('click',()=>$('rigVeil').classList.remove('show'));
$('rigVeil').addEventListener('click',e=>{if(e.target===$('rigVeil'))$('rigVeil').classList.remove('show')});
$('riggedDemoBtn').addEventListener('click',()=>loadModel('/examples/rigged_robot_demo.glb','Rigged robot · genuine 3D clips','demo-rigged'));
$('motionInput').addEventListener('change',e=>{if(e.target.files?.[0])importAnimationGLB(e.target.files[0]);});
$('bonesToggle').addEventListener('change',e=>showBones(e.target.checked));
$('exportStaticBtn').addEventListener('click',exportEightStillViews);
$('resetViewBtn').addEventListener('click',()=>{state.zoom=1;camera.zoom=1;camera.updateProjectionMatrix();camera.position.set(0,1.5,10);camera.lookAt(0,1.5,0);setDirection('S')});
$('axisSelect').addEventListener('change',e=>selectAxis(e.target.value));
$('flipFacingBtn').addEventListener('click',flipFacing);
$buttons('#compass button',b=>setDirection(b.dataset.dir));
$buttons('#styles .styleChoice',b=>applyStyle(b.dataset.style));
const pres=$('presetList');for(const p of PRESETS){const b=document.createElement('button');b.className='preset'+(p[0]==='idle'?' active':'');b.dataset.preset=p[0];b.textContent=p[1];b.addEventListener('click',()=>setPreset(p[0]));pres.append(b)}
$('clipSelect').addEventListener('change',e=>{if(e.target.value!=='')chooseClip(state.clips[Number(e.target.value)])});
$('playBtn').addEventListener('click',()=>{
 if(!state.clips.length)return;
 // Clicking Play after a finished one-shot should replay from the beginning.
 if(!state.playing&&!loopPlayback()&&state.time>=currentPeriod()-0.0001)state.time=0;
 state.playing=!state.playing;$('playBtn').textContent=state.playing?'❚❚ Pause':'▶ Play';
 // Do not resample after pressing Pause; leave the corrected bones untouched.
 updateProgressUI();last=performance.now();
});
$('playbackMode').addEventListener('change',()=>{
 workspaceStopSequence();
 if(!loopPlayback()&&state.time>=currentPeriod()){
  state.time=currentPeriod();state.playing=false;$('playBtn').textContent='↻ Replay';
 }
 refreshPlaybackLabel();updateAnimation(state.time);updateProgressUI();
});
$('restartBtn').addEventListener('click',()=>{workspaceStopSequence();state.time=0;state.playing=true;$('playBtn').textContent='❚❚ Pause';updateAnimation(0);last=performance.now()});
$('scrub').addEventListener('input',e=>{workspaceStopSequence();state.playing=false;$('playBtn').textContent='▶ Play';state.time=currentPeriod()*Number(e.target.value)/1000;updateAnimation(state.time);updateProgressUI()});
speedSlider.addEventListener('input',e=>{workspaceStopSequence();state.speed=Number(e.target.value);$('speedVal').textContent=state.speed.toFixed(2)+'×'});
$('angleSlider').addEventListener('input',e=>{state.angle=Number(e.target.value);$('angleVal').textContent=state.angle+'°';camera.position.y=1.5+Math.sin(state.angle*Math.PI/180)*10;camera.position.z=Math.cos(state.angle*Math.PI/180)*10;camera.lookAt(0,1.5,0)});
$('exportOneBtn').addEventListener('click',()=>exportSheets(false));$('exportAllBtn').addEventListener('click',()=>exportSheets(true));
$('countSelect').addEventListener('change',()=>{labState.endKey='';updateAnimation(state.time);updateProgressUI()});
$('exportFitSlider').addEventListener('input',e=>$('exportFitVal').textContent=e.target.value+'%');
$('settingsButton').addEventListener('click',()=>$('settingsVeil').classList.add('show'));
$('closeSettings').addEventListener('click',()=>$('settingsVeil').classList.remove('show'));
$('settingsVeil').addEventListener('click',e=>{if(e.target===$('settingsVeil'))$('settingsVeil').classList.remove('show')});
$('saveSettings').addEventListener('click',async()=>{const body={triposr_home:$('triposrHome').value.trim(),triposr_python:$('triposrPython').value.trim(),mc_resolution:Number($('meshRes').value),chunk_size:Number($('chunkSize').value)};
 try{const r=await fetch('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw Error(d.detail||'Could not save configuration');log('Settings saved.','settingsMessage');$('settingsVeil').classList.remove('show');refreshStatus();}catch(e){log(e.message,'settingsMessage',true)}});
// V4 MOTION LAB: non-destructive pose adjustments applied after the REAL GLB clip.
// For this 52-joint SkinTokens rig, leg A and leg B are mapped by their world positions,
// not by arbitrary guesses from bounding boxes. Other rigs retain basic playback/export.
const LAB_DEFAULT={footMode:'level',level:70,lock:35,pitchA:0,pitchB:0,endFootHold:false,loopBlend:12,attackType:'source',power:50,turn:50,timing:0};
const lab={...LAB_DEFAULT},labState={bones:null,anchors:null,basePosition:null,clipId:'',warned:false,endPose:null,endKey:'',loopStartPose:null};
const labBone=n=>state.model?.getObjectByName(n);
const qtmp=new THREE.Quaternion(),vtmp=new THREE.Vector3();
// V5.4: Map 28-joint and 52-joint SkinTokens rigs by hierarchy (not names).
// The 28-joint model has a 19-joint torso branch and 7-joint arms, unlike the older 52-joint model.
// GLB exporters can rename SkinTokens joints while retaining the identical hierarchy.
let footRigBones=[];
const rigChildren=(bone,set)=>bone.children.filter(ch=>ch.isBone&&set.has(ch));
function skinnedBones(){
 const meshes=[];state.model?.traverse(o=>{if(o.isSkinnedMesh&&o.skeleton?.bones?.length)meshes.push(o)});
 meshes.sort((a,b)=>b.skeleton.bones.length-a.skeleton.bones.length);
 // Only use actual skin joints, never non-deforming helper bones from the scene.
 return (meshes[0]?.skeleton?.bones||[]).filter(b=>b?.isBone);
}
function namedHumanoidRig(bones){
 const norm=s=>String(s||'').toLowerCase().replace(/[^a-z0-9]/g,'');
 const nmap=bones.map(b=>({b,n:norm(b.name)}));
 const search=(part,side)=>{
  const aliases={hip:['upleg','thigh'],knee:['lowerleg','shin','calf','leg'],ankle:['foot','ankle'],toe:['toebase','toe','ball']};
  const sides=side==='L'?['left','l']:['right','r'];
  const matches=nmap.filter(({n})=>{
   if(!aliases[part].some(a=>n.includes(a)))return false;
   if(part==='knee'&&(n.includes('upleg')||n.includes('thigh')))return false;
   if(part==='ankle'&&(n.includes('toe')||n.includes('ball')))return false;
   return n.includes(side==='L'?'left':'right')||sides.some(s=>n.startsWith(s)||n.includes(s+'foot')||n.includes(s+'leg')||n.includes(s+'thigh')||n.includes(s+'toe'));
  });
  return matches[0]?.b||null;
 };
 const L={hip:search('hip','L'),knee:search('knee','L'),ankle:search('ankle','L'),toe:search('toe','L')};
 const R={hip:search('hip','R'),knee:search('knee','R'),ankle:search('ankle','R'),toe:search('toe','R')};
 if(!L.ankle||!L.toe||!R.ankle||!R.toe||L.ankle===R.ankle)return null;
 const findName=(...terms)=>nmap.find(({n})=>terms.some(t=>n===t||n.endsWith(t)))?.b||null;
 return {hips:findName('hips','pelvis')||L.hip?.parent||null,
  spine:findName('spine','spine1'),chest:findName('spine2','chest'),upperSpine:findName('upperchest','spine3'),
  armA:findName('leftarm','leftupperarm'),elbowA:findName('leftforearm','leftlowerarm'),
  armB:findName('rightarm','rightupperarm'),elbowB:findName('rightforearm','rightlowerarm'),legs:[L,R]};
}
function mapSkinTokensByStructure(bones){
 // AssetFurnace can output either a 28-joint simplified SkinTokens skeleton
 // or a 52-joint extended skeleton. Their hip -> thigh -> shin -> ankle -> toe
 // chains are equivalent, but arm/spine counts differ. Never rely on bone names.
 if(bones.length<26)return null;
 const smallRig=bones.length<40;
 const minTorso=smallRig?17:20;
 const minArm=smallRig?6:8;
 const set=new Set(bones),children=b=>rigChildren(b,set);
 const subtreeSize=(bone,depth=0)=>depth>70?0:1+children(bone).reduce((n,ch)=>n+subtreeSize(ch,depth+1),0);
 function straightChain(root){
  const path=[root];let b=root;
  for(let i=0;i<8;i++){
   const cs=children(b);if(cs.length!==1)break;
   b=cs[0];path.push(b);
  }
  return path;
 }
 for(const hips of bones){
  const branches=children(hips);
  if(branches.length<3||branches.length>5)continue;
  const info=branches.map(root=>({root,path:straightChain(root),count:subtreeSize(root)}));
  const legBranches=info.filter(v=>v.path.length===4&&children(v.path[3]).length===0);
  const upper=info.filter(v=>v.count>=minTorso).sort((a,b)=>b.count-a.count)[0];
  if(legBranches.length!==2||!upper)continue;
  const spinalPath=straightChain(upper.root);
  const shoulderHub=spinalPath.find(b=>{
   const cs=children(b);return cs.filter(ch=>subtreeSize(ch)>=minArm).length>=2;
  });
  if(!shoulderHub)continue;
  const armBranches=children(shoulderHub).filter(ch=>subtreeSize(ch)>=minArm).sort((a,b)=>{
   // Stable ordering across GLB exporters even if names change.
   return bones.indexOf(a)-bones.indexOf(b);
  });
  if(armBranches.length<2)continue;
  // Keep left/right order stable: compare the actual positions in the model's rest pose.
  state.model.updateMatrixWorld(true);
  const xpos=bone=>bone.getWorldPosition(new THREE.Vector3()).x;
  legBranches.sort((a,b)=>xpos(b.root)-xpos(a.root));
  armBranches.sort((a,b)=>xpos(b)-xpos(a));
  const leg=info=>({hip:info.path[0],knee:info.path[1],ankle:info.path[2],toe:info.path[3]});
  return {hips,spine:spinalPath[0]||null,chest:spinalPath[1]||null,upperSpine:shoulderHub,
   armA:armBranches[0],elbowA:straightChain(armBranches[0])[1]||null,
   armB:armBranches[1],elbowB:straightChain(armBranches[1])[1]||null,
   legs:legBranches.map(leg)};
 }
 return null;
}
function mappedLowerBody(m){return !!(m?.legs?.length===2&&m.legs.every(l=>l.ankle?.isBone&&l.toe?.isBone))}
function activateFootRig(m,method){
 if(!mappedLowerBody(m))return false;
 labState.bones=m;labState.basePosition=state.model.position.clone();
 labState.anchors=null;labState.clipId='';labState.endPose=null;labState.endKey='';labState.loopStartPose=null;
 labState.mappingMethod=method;
 $('labMapping').textContent='✓ Foot controls active · '+method+'. Preview and PNG exports use the same correction.';
 if(state.selection.startsWith('clip::')){captureLabAnchors();updateAnimation(state.time)}
 return true;
}
function refreshManualRigSelectors(){
 const current=footRigBones=skinnedBones();
 const sels=['rigAnkleA','rigToeA','rigAnkleB','rigToeB'];
 for(const id of sels){
  const sel=$(id);sel.innerHTML='';
  const blank=document.createElement('option');blank.value='';blank.textContent='Select joint…';sel.append(blank);
  current.forEach((bone,i)=>{const o=document.createElement('option');o.value=String(i);o.textContent=String(i).padStart(2,'0')+' · '+(bone.name||'(unnamed)');sel.append(o)});
 }
 if(labState.bones)selectManualRigBones(labState.bones);
 $('rigMappingCount').textContent=current.length+' skinned bones detected.';
}
function selectManualRigBones(m){
 if(!m?.legs)return;
 const names=['rigAnkleA','rigToeA','rigAnkleB','rigToeB'];
 const targets=[m.legs[0].ankle,m.legs[0].toe,m.legs[1].ankle,m.legs[1].toe];
 names.forEach((id,i)=>$(id).value=String(footRigBones.indexOf(targets[i])));
}
function applyManualFootRig(quiet=false){
 const ids=['rigAnkleA','rigToeA','rigAnkleB','rigToeB'];
 const joints=ids.map(id=>{const value=$(id).value;return value===''?null:footRigBones[Number(value)]});
 if(joints.some(b=>!b)||new Set(joints).size!==4){if(!quiet)$('rigMapFeedback').textContent='Choose four distinct joints: each ankle and its toe.';return false}
 const [a,at,b,bt]=joints;
 const leg=(ankle,toe)=>({ankle,toe,knee:ankle.parent?.isBone?ankle.parent:null,
  hip:ankle.parent?.parent?.isBone?ankle.parent.parent:null});
 const legs=[leg(a,at),leg(b,bt)];
 const base=labState.bones||{hips:null,spine:null,chest:null,upperSpine:null,armA:null,elbowA:null,armB:null,elbowB:null};
 const candidate={...base,legs};
 if(legs[0].hip?.parent&&legs[0].hip.parent===legs[1].hip?.parent)candidate.hips=legs[0].hip.parent;
 activateFootRig(candidate,'manually selected ankle/toe joints');
 if(!quiet){$('rigMapFeedback').textContent='Manual foot mapping applied. Try changing Foot A pitch by 10° to verify, then save for this character.';updateFootRigAvailability();}
 return true;
}
function updateFootRigAvailability(){
 const enabled=Boolean(labState.bones);
 for(const id of ['footCalSave','footCalReset','footCalInspect','footFloorToggle'])$(id).disabled=!enabled;
 if(footFloorGuide)footFloorGuide.visible=enabled&&Boolean($('footFloorToggle').checked);
 refreshLabLabels();
}
function mapMotionBones(){
 labState.bones=null;labState.anchors=null;labState.clipId='';labState.endPose=null;labState.endKey='';labState.loopStartPose=null;
 footRigBones=[];
 if(!state.model)return;
 const exact={hips:labBone('bone_0'),spine:labBone('bone_1'),chest:labBone('bone_2'),upperSpine:labBone('bone_3'),
  armA:labBone('bone_6'),elbowA:labBone('bone_7'),armB:labBone('bone_25'),elbowB:labBone('bone_26'),
  legs:[{hip:labBone('bone_44'),knee:labBone('bone_45'),ankle:labBone('bone_46'),toe:labBone('bone_47')},
        {hip:labBone('bone_48'),knee:labBone('bone_49'),ankle:labBone('bone_50'),toe:labBone('bone_51')}]};
 const exactOk=Object.values(exact).every(v=>Array.isArray(v)?v.every(l=>Object.values(l).every(o=>o?.isBone)):v?.isBone);
 const bones=skinnedBones();
 let m=null,method='';
 if(exactOk){m=exact;method='original 52-bone SkinTokens names'}
 else if((m=mapSkinTokensByStructure(bones)))method='automatic '+bones.length+'-bone skeleton hierarchy';
 else if((m=namedHumanoidRig(bones)))method='named humanoid joints';
 if(m)activateFootRig(m,method);
 else $('labMapping').textContent='⚠ This rig is animated but its foot joints were not identified. Use the Manual foot joint mapping below. No source GLB has been changed.';
 refreshManualRigSelectors();updateFootRigAvailability();
 $('rigMapFeedback').textContent=m?'Mapped automatically. If a different joint responds, use Manual foot joint mapping to override.':'No automatic match. Select ankle and toe joints to enable foot controls.';
}
function sampleBase(t){
 if(!state.mixer||!state.selection.startsWith('clip::'))return;
 if(labState.basePosition)state.model.position.copy(labState.basePosition);
 state.mixer.setTime(Math.max(0,t));
 state.model.updateMatrixWorld(true);
}
function captureLabAnchors(){
 if(!labState.bones||!state.mixer||!state.selection.startsWith('clip::'))return;
 const key=state.selection;
 sampleBase(0);
 labState.anchors=labState.bones.legs.map(l=>state.model.worldToLocal(l.ankle.getWorldPosition(new THREE.Vector3()).clone()));
 // The source clip's exact start pose is cached, before corrective foot/IK layers.
 // Use it only for explicit loop seam blending. Source animation remains unchanged.
 const bones=[];state.model.traverse(o=>{if(o.isBone)bones.push(o)});
 labState.loopStartPose=bones.map(b=>({bone:b,position:b.position.clone(),rotation:b.quaternion.clone(),scale:b.scale.clone()}));
 labState.clipId=key;
}
const angleRad=deg=>deg*Math.PI/180;
function swingEnvelope(u){
 // Smooth anticipation and punchy impact, then a slow recovery. Zero at both endpoints.
 const gauss=(x,center,spread)=>Math.exp(-.5*((x-center)/spread)**2);
 return {wind:gauss(u,.19,.105),strike:gauss(u,.49,.12),recover:gauss(u,.71,.18)};
}
function rotateLocal(bone,axis,radians){if(!bone||!radians)return;bone.quaternion.multiply(new THREE.Quaternion().setFromAxisAngle(axis,radians)).normalize();}
function applySwordAccent(u){
 if(lab.attackType==='source'||!labState.bones)return;
 const m=labState.bones,amp=(lab.power/100),tw=(lab.turn/100),e=swingEnvelope(u);
 const flow=(-.52*e.wind + 1.05*e.strike - .23*e.recover),rev=lab.attackType==='reverse'?-1:1;
 const axX=new THREE.Vector3(1,0,0),axY=new THREE.Vector3(0,1,0),axZ=new THREE.Vector3(0,0,1);
 rotateLocal(m.spine,axY,rev*flow*tw*.24);
 rotateLocal(m.chest,axY,rev*flow*tw*.32);
 rotateLocal(m.upperSpine,axY,rev*flow*tw*.15);
 if(lab.attackType==='heavy'){
   rotateLocal(m.armA,axZ,amp*(-.40*e.wind+.52*e.strike-.14*e.recover));
   rotateLocal(m.armA,axX,amp*(-.24*e.wind+.20*e.strike));
   rotateLocal(m.elbowA,axX,amp*(-.16*e.wind+.22*e.strike));
   rotateLocal(m.armB,axZ,amp*(.16*e.wind-.19*e.strike));
 }else if(lab.attackType==='diagonal'){
   rotateLocal(m.armA,axX,amp*(-.42*e.wind+.48*e.strike));
   rotateLocal(m.armA,axZ,amp*(.15*e.wind-.34*e.strike));
   rotateLocal(m.elbowA,axZ,amp*(.20*e.wind-.28*e.strike));
   rotateLocal(m.armB,axY,amp*(-.14*e.strike));
 }else if(lab.attackType==='reverse'){
   rotateLocal(m.armB,axZ,amp*(.43*e.wind-.46*e.strike+.09*e.recover));
   rotateLocal(m.armB,axX,amp*(-.30*e.wind+.27*e.strike));
   rotateLocal(m.elbowB,axX,amp*(-.18*e.wind+.28*e.strike));
   rotateLocal(m.armA,axY,amp*(.18*e.strike));
 }
 state.model.updateMatrixWorld(true);
}
// Rotate a bone in WORLD space, converted properly into its parent's local coordinates.
function applyWorldRotation(bone,worldDelta){
 if(!bone||!bone.parent)return;
 const parentWorldQ=bone.parent.getWorldQuaternion(new THREE.Quaternion());
 const localDelta=parentWorldQ.clone().invert().multiply(worldDelta).multiply(parentWorldQ);
 bone.quaternion.premultiply(localDelta).normalize();
 bone.updateMatrixWorld(true);
}
function footLevel(leg,strength,addPitch){
 const ankle=leg.ankle,toe=leg.toe,origin=ankle.getWorldPosition(new THREE.Vector3()),fwd=toe.getWorldPosition(new THREE.Vector3()).sub(origin);
 const horizontal=new THREE.Vector3(fwd.x,0,fwd.z);
 if(horizontal.length()<1e-6)return;
 const pitch=Math.atan2(fwd.y,horizontal.length());
 const right=new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0),horizontal.normalize()).normalize();
 if(right.lengthSq()<1e-6)return;
 // Cap extreme inferred toe slopes so one bad bone does not flip the entire foot.
 const angle=THREE.MathUtils.clamp(pitch,-.65,.65)*strength + angleRad(addPitch);
 applyWorldRotation(ankle,new THREE.Quaternion().setFromAxisAngle(right,angle));
}
// V5.5: A/B pitch fields are direct ankle edits, not a request to recompute
// both feet (and both legs through the optional planted-feet IK solver).
// Freeze the current visible frame, then rotate ONLY the selected ankle by
// the difference in degrees. Play/scrub/export still resample the full source
// clip deterministically and apply both saved pitches.
function isolatedAnklePitchDelta(leg,deltaDegrees){
 if(!leg?.ankle||!leg?.toe||Math.abs(deltaDegrees)<1e-7)return;
 state.model.updateMatrixWorld(true);
 const anklePoint=leg.ankle.getWorldPosition(new THREE.Vector3());
 const forward=leg.toe.getWorldPosition(new THREE.Vector3()).sub(anklePoint);
 forward.y=0;
 if(forward.lengthSq()<1e-10)return;
 const pitchAxis=new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0),forward.normalize()).normalize();
 if(pitchAxis.lengthSq()<1e-10)return;
 applyWorldRotation(leg.ankle,new THREE.Quaternion().setFromAxisAngle(pitchAxis,angleRad(deltaDegrees)));
 state.model.updateMatrixWorld(true);
}
function editFootPitchIndependently(index){
 const input=$(index===0?'labPitchA':'labPitchB');
 const key=index===0?'pitchA':'pitchB';
 const value=THREE.MathUtils.clamp(Number(input.value)||0,-30,30);
 const delta=value-(Number(lab[key])||0);
 lab[key]=value;
 if(state.loaded&&labState.bones&&state.mixer&&state.selection.startsWith('clip::')){
  // Both feet otherwise move because the animation keeps playing during edits.
  state.playing=false;$('playBtn').textContent='▶ Play';last=performance.now();
  if(lab.footMode!=='off')isolatedAnklePitchDelta(labState.bones.legs[index],delta);
  updateProgressUI();
  const hint=$('independentFootHint');
  if(hint)hint.textContent=(index===0?'Foot A':'Foot B')+' edited alone at the paused frame. Playback and exports use the saved pitch.';
 }else if(state.loaded&&lab.footMode==='off'){
  const hint=$('independentFootHint');
  if(hint)hint.textContent='Contact correction is Off. Choose Level shoes to preview foot pitch.';
 }
}
function limitedCCD(leg,target,strength){
 if(strength<=0)return;
 const tip=leg.ankle;
 // Small, bounded solver for attack/idle contact. Full locomotion needs gait-aware stance windows.
 for(let iter=0;iter<5;iter++){
  for(const joint of [leg.knee,leg.hip]){
   const jp=joint.getWorldPosition(new THREE.Vector3());
   const v=tip.getWorldPosition(new THREE.Vector3()).sub(jp),w=target.clone().sub(jp);
   if(v.length()<1e-7||w.length()<1e-7)continue;
   const change=new THREE.Quaternion().setFromUnitVectors(v.normalize(),w.normalize());
   const aa=2*Math.acos(THREE.MathUtils.clamp(change.w,-1,1));
   const limited=Math.min(aa,.13)*strength;
   if(limited<1e-6)continue;
   let axis=new THREE.Vector3(change.x,change.y,change.z);
   if(axis.lengthSq()<1e-9)continue;
   axis.normalize();
   applyWorldRotation(joint,new THREE.Quaternion().setFromAxisAngle(axis,limited));
  }
  if(tip.getWorldPosition(new THREE.Vector3()).distanceTo(target)<.002)break;
 }
}
function applyFootContact(){
 if(!labState.bones||lab.footMode==='off')return;
 const hasStriding=/walk|run|sprint|sneak|swim/i.test(state.selection);
 const strength=lab.lock/100;
 // Stance-locking a continuous walking cycle without ground-contact tags would cause more foot sliding.
 // Thus IK is ONLY applied on stationary/attack clips here; leveling remains available on all clips.
 if(lab.footMode==='lock'&&!hasStriding&&labState.anchors&&labState.bones.legs.every(l=>l.knee?.isBone&&l.hip?.isBone)){
  labState.bones.legs.forEach((leg,i)=>{
   const target=state.model.localToWorld(labState.anchors[i].clone());
   limitedCCD(leg,target,strength);
  });
 }
 labState.bones.legs.forEach((leg,i)=>footLevel(leg,lab.level/100,i===0?Number(lab.pitchA):Number(lab.pitchB)));
}
// Blend the source 3D joint poses across the last part of a forced loop.
// Unlike a pause, this is continuous motion and affects playback + sprite exports alike.
// Only mapped SkinTokens rigs can use this control; 0% = original source clip.
function blendLoopSeam(cycle){
 if(!labState.bones||!loopPlayback()||lab.loopBlend<=0||!labState.loopStartPose)return;
 const range=THREE.MathUtils.clamp(lab.loopBlend/100,0,0.30);
 const from=1-range;
 if(cycle<=from)return;
 const w=THREE.MathUtils.smoothstep(cycle,from,1);
 for(const p of labState.loopStartPose){
  p.bone.position.lerp(p.position,w);
  p.bone.quaternion.slerp(p.rotation,w).normalize();
  p.bone.scale.lerp(p.scale,w);
 }
 state.model.updateMatrixWorld(true);
}
// End-frame correction for a one-shot attack: freeze the lower-body source pose
// at the penultimate exported frame, and blend into it without touching the torso.
// Works in preview AND in sprite-sheet rendering; source GLB and saved sliders remain unchanged.
function holdLastFrameFeet(cycle, period){
 if(!labState.bones||!lab.endFootHold||loopPlayback()||lab.footMode==='off')return;
 const n=Math.max(2,Number($('countSelect').value)||8);
 const holdAt=(n-2)/(n-1); // 8-frame sequence: freeze foot motion at frame 7 (6/7).
 if(cycle<=holdAt)return;
 const key=state.selection+'|'+n;
 if(labState.endKey!==key){
  const b=labState.bones;
  const legBones=[b.hips,...b.legs.flatMap(l=>[l.hip,l.knee,l.ankle,l.toe])].filter(Boolean);
  sampleBase(holdAt*period);
  labState.endPose=legBones.map(o=>({bone:o,position:o.position.clone(),rotation:o.quaternion.clone()}));
  labState.endKey=key;
  sampleBase(cycle*period); // Restore current pose before blending.
 }
 const weight=THREE.MathUtils.smoothstep(cycle,holdAt,Math.min(1,holdAt+0.045));
 for(const p of labState.endPose){
  p.bone.position.lerp(p.position,weight);
  p.bone.quaternion.slerp(p.rotation,weight).normalize();
 }
 state.model.updateMatrixWorld(true);
}
function updateMotionLab(time){
 if(!state.mixer||!state.selection.startsWith('clip::'))return;
 const period=currentPeriod();
 const cycle=period>0?(loopPlayback()?((time%period)+period)%period/period:THREE.MathUtils.clamp(time/period,0,.999999)):0;
 // Phase-warp is smooth, monotone, and periodic at the loop boundary.
 const warped=THREE.MathUtils.clamp(cycle + .0013*lab.timing*Math.sin(2*Math.PI*cycle),0,.999999);
 sampleBase(warped*period);
 if(!labState.bones)return;
 if(labState.clipId!==state.selection)captureLabAnchors();
 // Forced loops blend smoothly back to the start pose. One-shots retain their end.
 blendLoopSeam(warped);
 // Legacy last-frame pose hold is optional and OFF by default in V4.3.
 holdLastFrameFeet(warped,period);
 applySwordAccent(warped);
 applyFootContact();
}
function refreshLabLabels(){
 const f=id=>$(id);lab.footMode=f('labFootMode').value;lab.endFootHold=f('labEndFootHold').checked;lab.loopBlend=Number(f('labLoopBlend').value);
 for(const [key,id,display] of [['level','labLevel','labLevelVal'],['lock','labLock','labLockVal'],['loopBlend','labLoopBlend','labLoopBlendVal'],['power','labPower','labPowerVal'],['turn','labTurn','labTurnVal'],['timing','labTiming','labTimingVal']]){
  lab[key]=Number(f(id).value);f(display).textContent=(key==='timing'?(lab[key]>0?'+':'')+lab[key]:lab[key])+'%';
 }
 for(const key of ['pitchA','pitchB'])lab[key]=THREE.MathUtils.clamp(Number(f('lab'+(key==='pitchA'?'PitchA':'PitchB')).value)||0,-30,30);
 lab.attackType=f('labAttackType').value;
 $('labNotice').textContent=labState.bones?'Corrections are live in preview and PNG exports. IK only applies to non-walking clips; no AI animation or weapon mesh is created.':'This file lacks the mapped 52-bone SkinTokens rig; the original animation still plays.';
}
function setLabFromProfile(profile){
 for(const [key,def] of Object.entries(LAB_DEFAULT)){
  const value=profile[key];
  if(typeof def==='boolean')lab[key]=typeof value==='boolean'?value:def;
  else if(typeof def==='number')lab[key]=Number.isFinite(Number(value))?Number(value):def;
  else lab[key]=(typeof value==='string')?value:def;
 }
 $('labFootMode').value=['off','level','lock'].includes(lab.footMode)?lab.footMode:'level';
 $('labEndFootHold').checked=Boolean(lab.endFootHold);$('labLoopBlend').value=lab.loopBlend;
 $('labAttackType').value=['source','heavy','diagonal','reverse'].includes(lab.attackType)?lab.attackType:'source';
 for(const [key,id] of [['level','labLevel'],['lock','labLock'],['loopBlend','labLoopBlend'],['power','labPower'],['turn','labTurn'],['timing','labTiming'],['pitchA','labPitchA'],['pitchB','labPitchB']])$(id).value=lab[key];
 refreshLabLabels();if(state.loaded)updateAnimation(state.time);
}

// V5.2 ONE-TIME FOOT CALIBRATION
// Source assets from Pixal3D can contain a toe-up rest pose because one front
// reference has no side/depth constraint. This applies consistent per-character
// ankle pitch across all loaded clips. It does NOT change the source GLB bind
// pose or change what AssetFurnace displays; only Core Motion preview + exports.
const FOOT_CALIBRATION_VERSION=1;
const FOOT_CALIBRATION_PREFIX='core_motion_feet_v52:';
const footFields=['footMode','level','lock','pitchA','pitchB'];
function calibrationStorageKey(source,id){
 const clean=String(id||'unnamed').trim().toLowerCase().replace(/\s+/g,' ').slice(0,160);
 return FOOT_CALIBRATION_PREFIX+String(source||'glb')+':'+clean;
}
function savedFootPayload(){
 return {version:FOOT_CALIBRATION_VERSION,
  footMode:lab.footMode,level:lab.level,lock:lab.lock,pitchA:lab.pitchA,pitchB:lab.pitchB,
  manualJoints:labState.mappingMethod==='manually selected ankle/toe joints' ? ['rigAnkleA','rigToeA','rigAnkleB','rigToeB'].map(id=>$(id).value) : null,
  savedAt:new Date().toISOString()};
}
function describeFootSave(text,isError=false){
 const el=$('footCalibrationStatus');if(!el)return;
 el.textContent=text;el.style.color=isError?'#ff9d9d':'#b6d2e0';
}
function restoreFootCalibration(){
 // Every new character starts at neutral per-character defaults rather than
 // inheriting ankle rotations from the last imported GLB.
 const data={...LAB_DEFAULT};
 const key=state.calibrationKey;
 let restored=false;let savedJointIndexes=null;
 if(key){try{
  const val=localStorage.getItem(key);
  if(val){const saved=JSON.parse(val);if(saved?.version===FOOT_CALIBRATION_VERSION){
    for(const k of footFields)if(saved[k]!==undefined)data[k]=saved[k];
    savedJointIndexes=Array.isArray(saved.manualJoints)?saved.manualJoints:null;
    restored=true;
  }}
 }catch(e){describeFootSave('Browser storage unavailable: '+e.message,true)}}
 for(const k of footFields)lab[k]=data[k];
 if(savedJointIndexes?.length===4&&footRigBones.length){
  ['rigAnkleA','rigToeA','rigAnkleB','rigToeB'].forEach((id,i)=>$(id).value=String(savedJointIndexes[i]));
  applyManualFootRig(true);
 }
 $('labFootMode').value=['off','level','lock'].includes(lab.footMode)?lab.footMode:'level';
 $('labLevel').value=lab.level;$('labLock').value=lab.lock;
 $('labPitchA').value=lab.pitchA;$('labPitchB').value=lab.pitchB;
 refreshLabLabels();
 const mapped=Boolean(labState.bones);
 updateFootRigAvailability();
 describeFootSave(mapped?(restored?'Saved foot calibration restored for this character.':'No calibration saved yet. Adjust once, then save for all its clips.'):'Needs a SkinTokens 52-bone rig.');
}
function saveFootCalibration(){
 if(!state.calibrationKey||!labState.bones){describeFootSave('Import a SkinTokens-rigged character first.',true);return}
 refreshLabLabels();
 try{localStorage.setItem(state.calibrationKey,JSON.stringify(savedFootPayload()));
   describeFootSave('Saved for this character. All current and future attached clips will use these foot settings.');
 }catch(e){describeFootSave('Could not save in browser: '+e.message,true)}
}
function clearFootCalibration(){
 if(!state.calibrationKey)return;
 try{localStorage.removeItem(state.calibrationKey)}catch(e){describeFootSave(e.message,true);return}
 restoreFootCalibration();if(state.loaded)updateAnimation(state.time);
 describeFootSave('Saved calibration reset. Original GLB and all animation files remain unchanged.');
}
function inspectFootCalibration(){
 if(!state.loaded||!labState.bones)return;
 // Inspect in a known side-on view and hold a pose without any unwanted pause resampling.
 const idle=state.clips.find(c=>/idle|stand|breath/i.test(c.name));
 if(idle)chooseClip(idle);
 setDirection('E');state.playing=false;$('playBtn').textContent='▶ Play';
 state.time=idle?Math.min(.12,currentPeriod()*.2):0;
 updateAnimation(state.time);updateProgressUI();
 $('footFloorToggle').checked=true;
 if(footFloorGuide)footFloorGuide.visible=true;
 describeFootSave('Side view paused. Level each sole with Foot Leveling and A/B pitch, then click Save for this character.');
}
function markCalibrationChanged(){
 if(!state.calibrationKey||!labState.bones)return;
 describeFootSave('Foot adjustments changed. Click “Save for this character” to reuse across reloads and all clips.');
}
function initFootCalibration(){
 $('footCalSave').addEventListener('click',saveFootCalibration);
 $('footCalReset').addEventListener('click',clearFootCalibration);
 $('footCalInspect').addEventListener('click',inspectFootCalibration);
 $('footFloorToggle').addEventListener('change',e=>{if(footFloorGuide)footFloorGuide.visible=Boolean(e.target.checked&&state.loaded)});
 for(const id of ['labFootMode','labLevel','labLock','labPitchA','labPitchB'])
  $(id).addEventListener('input',markCalibrationChanged);
 $('rigApplyManual').addEventListener('click',()=>applyManualFootRig());
 $('rigAutoDetect').addEventListener('click',()=>{mapMotionBones();restoreFootCalibration();});
}
function initMotionLab(){
 // Pitch editing is intentionally separate: update only the chosen ankle on the
 // currently visible, paused pose. Re-running IK here could shift both feet.
 for(const id of ['labFootMode','labLevel','labLock','labEndFootHold','labLoopBlend','labAttackType','labPower','labTurn','labTiming'])$(id).addEventListener('input',()=>{refreshLabLabels();if(state.loaded)updateAnimation(state.time)});
 $('labPitchA').addEventListener('input',()=>editFootPitchIndependently(0));
 $('labPitchB').addEventListener('input',()=>editFootPitchIndependently(1));
 $('saveMotionProfile').addEventListener('click',()=>download(new Blob([JSON.stringify({studio:'Core Motion V4.3',version:4,rig:'SkinTokens bone_0-51',playbackMode:$('playbackMode').value,settings:lab},null,2)],{type:'application/json'}),'core_motion_foot_and_sword_profile.json'));
 $('loadMotionProfile').addEventListener('click',()=>$('motionProfileFile').click());
 $('motionProfileFile').addEventListener('change',async(e)=>{const file=e.target.files?.[0];if(!file)return;try{const data=JSON.parse(await file.text());setLabFromProfile(data.settings||data);if(['auto','once','loop'].includes(data.playbackMode))$('playbackMode').value=data.playbackMode;refreshPlaybackLabel();$('labNotice').textContent='Profile loaded. Preview and sprite exports use these settings.';markCalibrationChanged();}catch(err){$('labNotice').textContent='Could not read profile: '+err.message;}e.target.value='';});
 refreshLabLabels();
}

initMotionLab();setup3d();initFootCalibration();buildTimeline();refreshStatus();



// ------------------------------------------------------- V5 local AssetFurnace bridge
// Calls ONLY this studio's local FastAPI bridge, which in turn talks to
// AssetFurnace on 127.0.0.1:8777. No paid API or direct browser CORS calls.
const furnace={online:false,moves:[],assets:[],job:null,pollTimer:null};
function furnaceMessage(message,error=false){const el=$('furnaceProgress');el.textContent=message;el.classList.toggle('error',error)}
async function furnaceRequest(path, options){
 const res=await fetch('/api/furnace/'+path,{cache:'no-store',...(options||{})});
 let data;try{data=await res.json()}catch{throw Error('Invalid response from local AI bridge')}
 if(!res.ok)throw Error(data.detail||data.error||'AI engine request failed');
 return data;
}
function furnaceSelectMoves(moves){
 furnace.moves=moves||[];const select=$('furnaceMove'); const prev=select.value;
 select.replaceChildren();
 for(const move of furnace.moves){const option=document.createElement('option');option.value=move.id;option.textContent=move.label;select.appendChild(option)}
 v71RefreshCatalog();
 if(prev&&furnace.moves.some(x=>x.id===prev))select.value=prev;
 else{const idle=furnace.moves.find(m=>/idle/i.test(m.id+' '+m.label));if(idle)select.value=idle.id}
 $('furnaceMore').disabled=!furnace.moves.length||!$('furnaceAssets').value;
}
async function furnaceGetStatus(){
 try{
  const s=await furnaceRequest('status');furnace.online=Boolean(s.online);
  $('furnaceHome').value=s.home||'C:\\AI\\AssetFurnace';
  $('furnaceState').textContent=s.online?'AI engine connected':'AI engine offline';
  $('furnaceNote').textContent=s.message||'';
  $('furnaceStart').disabled=s.online;
  $('furnaceCreate').disabled=!s.online||!state.file;
  if(s.online){
   try{const m=await furnaceRequest('moves');furnaceSelectMoves(m.moves||[])}catch(e){furnaceMessage('Could not load animation list: '+e.message,true)}
   await furnaceRefreshAssets(false);
  }
  return s;
 }catch(e){furnaceMessage(e.message,true);return {online:false}}
}
async function furnaceStart(){
 $('furnaceStart').disabled=true;furnaceMessage('Starting AssetFurnace locally…');
 try{
  const result=await furnaceRequest('start',{method:'POST'});
  furnaceMessage(result.message);
  // Poll for readiness, but never block the browser or claim success prematurely.
  for(let tries=0;tries<45;tries++){
   await new Promise(r=>setTimeout(r,1800));
   const status=await furnaceGetStatus();if(status.online){furnaceMessage('AI ready. Select a T-pose image to generate a 3D character.');return;}
  }
  furnaceMessage('Still offline. Check outputs/furnace_background.log in your studio folder.',true);
 }catch(e){furnaceMessage(e.message,true)}finally{$('furnaceStart').disabled=furnace.online}
}
async function furnaceRefreshAssets(showMessage=true){
 if(!furnace.online)return;
 try{
  const result=await furnaceRequest('assets');furnace.assets=result.assets||[];
  const current=$('furnaceAssets').value;
  $('furnaceAssets').replaceChildren();
  const placeholder=document.createElement('option');placeholder.value='';placeholder.textContent='Select saved character…';$('furnaceAssets').appendChild(placeholder);
  for(const asset of furnace.assets){
   if(asset.kind==='prop'||asset.kind==='prop set')continue;
   const o=document.createElement('option');o.value=asset.id;
   o.textContent=asset.name+(asset.has_rig?' · rigged':' · 3D')+(asset.clips?.length?' · '+asset.clips.length+' moves':'');
   $('furnaceAssets').appendChild(o);
  }
  if([...$('furnaceAssets').options].some(o=>o.value===current))$('furnaceAssets').value=current;
  $('furnaceMore').disabled=!$('furnaceAssets').value||!furnace.moves.length;
  $('furnaceDelete').disabled=!$('furnaceAssets').value;
  v71RefreshCatalog();
  if(showMessage)furnaceMessage('AssetFurnace library refreshed. Select a character to load or add a move.');
 }catch(e){if(showMessage)furnaceMessage(e.message,true)}
}
function furnaceRunning(runId){
 furnace.job=runId;$('furnaceJobBox').style.display='block';
 $('furnaceCreate').disabled=true;$('furnaceMore').disabled=true;
 furnacePoll(runId);
}
async function furnacePoll(runId){
 if(furnace.job!==runId)return;
 try{
  const job=await furnaceRequest('run/'+encodeURIComponent(runId));
  const finished=job.done||[];const status=String(job.status||'running').toLowerCase();
  const stage=job.current?.step||job.current?.name||job.step||'';
  furnaceMessage('AI pipeline: '+status+(stage?' · '+stage:'')+(finished.length?'\nCompleted stages: '+finished.map(x=>typeof x==='string'?x:(x.step||x.name||'step')).join(', '):''));
  if(['done','finished','complete','completed','error','failed','cancelled','canceled'].includes(status)){
   furnace.job=null;$('furnaceJobBox').style.display='none';
   $('furnaceCreate').disabled=!furnace.online||!state.file;
   if(['error','failed','cancelled','canceled'].includes(status)){
    furnaceMessage('AI pipeline '+status+'. '+String(job.error||job.message||'Check AssetFurnace job log.'),true);return;
   }
   await furnaceRefreshAssets(false);
   furnaceMessage('AI job finished. Select your new character in the library and click Load into editor.');
    v71GuideMessage('3D generation completed. Select the new character in the AI library and click Load into editor.');
   return;
  }
  furnace.pollTimer=setTimeout(()=>furnacePoll(runId),1800);
 }catch(e){furnaceMessage(e.message+'; retrying status…',true);furnace.pollTimer=setTimeout(()=>furnacePoll(runId),5000)}
}
async function furnaceCreate(){
 if(!state.file){furnaceMessage('Upload a T-pose PNG in Section 01 first.',true);return}
 if(furnace.job){furnaceMessage('A job is already running.',true);return}
 try{
  const form=new FormData();form.append('image',state.cutoutFile||state.file);
  form.append('title',state.file.name.replace(/\.[^.]+$/,'').replace(/[-_]/g,' ').slice(0,80));
  form.append('stop_after',$('furnaceStop').value);
  // No first_move: AssetFurnace's first-animation clips have known foot-angle artifacts.
  furnaceMessage('Submitting to local Pixal3D → Finish → SkinTokens…');
  const result=await furnaceRequest('create',{method:'POST',body:form});
  if(!result.run_id)throw Error('AssetFurnace did not return a generation ID.');
  furnaceRunning(result.run_id);
 }catch(e){furnaceMessage(e.message,true)}
}
async function furnaceAllClips(){
 const id=$('furnaceAssets').value;
 if(!id||!state.loaded||!state.rigInfo?.skinnedMeshes){
  furnaceMessage('First load the selected rigged character into the editor.',true);return;
 }
 const asset=furnace.assets.find(a=>a.id===id);
 if(!asset?.clips?.length){furnaceMessage('This asset has no saved motion clips.',true);return}
 const button=$('furnaceAllClips');button.disabled=true;
 let added=0,skipped=0,failed=0;
 try{
  for(let i=0;i<asset.clips.length;i++){
   const name=asset.clips[i]||('Clip '+i);
   if(state.clips.some(c=>c.name.toLowerCase()===name.toLowerCase())){skipped++;continue}
   furnaceMessage('Attaching '+(i+1)+'/'+asset.clips.length+': '+name);
   try{
    const result=await furnaceRequest('clip/'+encodeURIComponent(id)+'/'+i);
    const response=await fetch(result.url);
    if(!response.ok)throw Error('Unable to download local clip');
    const before=state.clips.length;
    const blob=await response.blob();
    await importAnimationGLB(new File([blob],(result.name||name)+'.glb',{type:'model/gltf-binary'}));
    if(state.clips.length>before)added++;else failed++;
   }catch(e){failed++;furnaceMessage(name+': '+e.message,true)}
  }
  furnaceMessage('Motion library: '+added+' added, '+skipped+' already loaded, '+failed+' incompatible or unavailable.');
 }finally{button.disabled=false}
}
async function furnaceMore(){
 const id=$('furnaceAssets').value,move=$('furnaceMove').value;
 if(!id||!move){furnaceMessage('Select a rigged character and animation.',true);return}
 try{
  const result=await furnaceRequest('animate-existing',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({asset_id:id,move})});
  if(!result.run_id)throw Error('AssetFurnace did not return a generation ID.');
  furnaceRunning(result.run_id);
 }catch(e){furnaceMessage(e.message,true)}
}
async function furnaceImport(){
 const id=$('furnaceAssets').value;
 if(!id){furnaceMessage('Select an AssetFurnace character first.',true);return}
 try{
  furnaceMessage('Importing your local character, skeleton, and available clips…');
  const result=await furnaceRequest('import/'+encodeURIComponent(id));
  await loadModel(result.url+'?v='+Date.now(),result.name||'AssetFurnace character','assetfurnace',id);
   furnaceMessage('Character imported. Choose an art style, preview available animation clips, then export.');
   v71GuideMessage('3D character loaded. Choose an art style, then pick an animation.');
 }catch(e){furnaceMessage(e.message,true)}
}
async function furnaceDeleteSelected(){
 const id=$('furnaceAssets').value;
 const asset=furnace.assets.find(a=>a.id===id);
 if(!id||!asset){furnaceMessage('Select a saved AssetFurnace character before deleting.',true);return}
 const button=$('furnaceDelete');button.disabled=true;
 try{
  const plan=await furnaceRequest('assets/'+encodeURIComponent(id)+'/delete-plan');
  if(plan.refused){furnaceMessage('AssetFurnace cannot delete this version: '+plan.refused,true);return}
  const fileCount=Array.isArray(plan.folders)?plan.folders.length:0;
  const mb=(Number(plan.bytes||0)/1048576).toFixed(1);
  if(!window.confirm('PERMANENTLY DELETE AssetFurnace character "'+asset.name+'"?\n\n'+fileCount+' owned folder(s), approximately '+mb+' MB will be removed from AssetFurnace storage. This cannot be undone.\n\nYour current editor scene will remain open.'))return;
  const response=await furnaceRequest('assets/'+encodeURIComponent(id)+'/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirm:true})});
  $('furnaceAssets').value='';
  await furnaceRefreshAssets(false);
  furnaceMessage('Deleted "'+asset.name+'" from AssetFurnace ('+(response.deleted?.length||0)+' folders). The current scene remains loaded if it used this character.');
 }catch(e){furnaceMessage('Could not delete AssetFurnace character: '+e.message,true)}
 finally{button.disabled=!$('furnaceAssets').value}
}
async function furnaceCancel(){
 if(!furnace.job)return;
 try{await furnaceRequest('cancel/'+encodeURIComponent(furnace.job),{method:'POST'});furnaceMessage('Cancel requested. Waiting for local AI engine to stop.');}
 catch(e){furnaceMessage(e.message,true)}
}
function initFurnace(){
 $('furnaceStart').addEventListener('click',furnaceStart);
 $('furnaceCheck').addEventListener('click',furnaceGetStatus);
 $('furnaceRefresh').addEventListener('click',()=>furnaceRefreshAssets(true));
 $('furnaceCreate').addEventListener('click',furnaceCreate);
 $('furnaceMore').addEventListener('click',furnaceMore);
 $('furnaceImport').addEventListener('click',furnaceImport);
 $('furnaceDelete').addEventListener('click',furnaceDeleteSelected);
 $('furnaceAllClips').addEventListener('click',furnaceAllClips);
 $('furnaceCancel').addEventListener('click',furnaceCancel);
 $('imageInput').addEventListener('change',()=>{
  $('furnaceCreate').disabled=!furnace.online||!state.file;
  if(state.file)furnaceMessage('T-pose selected. Use Remove Background if needed, then Generate.');
 });
 $('furnaceAssets').addEventListener('change',()=>{
  const a=furnace.assets.find(a=>a.id===$('furnaceAssets').value);
  $('furnaceMore').disabled=!a?.has_rig||!furnace.moves.length;
  $('furnaceDelete').disabled=!a;
  if(a)furnaceMessage(a.name+' · '+(a.has_rig?'Rigged':'Not rigged')+' · '+(a.clips?.length||0)+' motion clips.');
    v71RefreshCatalog();
 });
 $('furnaceSavePath').addEventListener('click',async()=>{
  try{
   const result=await furnaceRequest('config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({furnace_home:$('furnaceHome').value.trim()})});
   furnaceMessage('AssetFurnace path saved: '+result.home);await furnaceGetStatus();
  }catch(e){furnaceMessage(e.message,true)}
 });
 // Never overwrites V4.3 correction settings or GLB file.
 furnaceGetStatus();
}
initFurnace();


// V6.4: built-in local updater. All requests go to the loopback Studio backend.
// A separate launcher stops/restarts the backend when a verified update is queued.
const UPDATE_API='/api/updater';
let updateHasCandidate=false, updateStaged=false, updateCanRollback=false, updateBusy=false, updatePolling=false, updatePreviousVersion='';
function updateMessage(value,error=false){
 const node=$('updateStatus');if(!node)return;
 node.textContent=value;node.style.color=error?'#ff9ba4':'#c1dbed';
}
async function updateRequest(endpoint,options={}){
 const res=await fetch(UPDATE_API+endpoint,{cache:'no-store',...options});
 let value={};try{value=await res.json()}catch{}
 if(!res.ok)throw Error(value.detail||('Update service returned '+res.status));
 return value;
}
async function updateGetStatus(){
 const status=await updateRequest('/status');
 $('installedVersion').textContent='V'+status.version;
 if(document.activeElement!==$('updateFeedUrl'))$('updateFeedUrl').value=status.feed_url||'';
 updateStaged=!!status.has_staged_update; updateCanRollback=!!status.can_rollback;
 $('rollbackUpdate').disabled=updateBusy||!updateCanRollback;
 $('applyUpdate').disabled=updateBusy||!updateStaged;
 return status;
}
function updateSetBusy(b){
 updateBusy=b;
 for(const id of ['checkUpdate','downloadUpdate','applyUpdate','stageManualUpdate','saveUpdateSource','rollbackUpdate']){
  $(id).disabled=b || (id==='downloadUpdate'&&!updateHasCandidate) || (id==='applyUpdate'&&!updateStaged) || (id==='rollbackUpdate'&&!updateCanRollback);
 }
}
async function updateCheck(){
 updateSetBusy(true);updateMessage('Checking the configured release source…');
 try{
  const latest=await updateRequest('/check');
  updateHasCandidate=!!latest.available;
  updateMessage(latest.available?'New version V'+latest.version+' available.\n'+(latest.notes||'Click Download & verify to prepare it.'):'You are already running the latest published release (V'+latest.current_version+').');
 }catch(e){updateHasCandidate=false;updateMessage(e.message,true)}finally{updateSetBusy(false)}
}
async function updateStageRemote(){
 updateSetBusy(true);updateMessage('Downloading the update and verifying its checksums…');
 try{
  const result=await updateRequest('/prepare',{method:'POST'});
  updateStaged=true;updateMessage('V'+result.version+' is verified and ready. Click Install & restart.');
 }catch(e){updateMessage(e.message,true)}finally{updateSetBusy(false);$('applyUpdate').disabled=!updateStaged}
}
async function updateStageFile(){
 const file=$('manualUpdateFile').files?.[0];
 if(!file){updateMessage('Choose a new Core Motion in-app update ZIP first.',true);return}
 updateSetBusy(true);updateMessage('Verifying '+file.name+'…');
 try{
  const data=new FormData();data.append('package',file,file.name);
  const result=await updateRequest('/upload',{method:'POST',body:data});
  updateStaged=true;updateMessage('V'+result.version+' package verified and ready. Click Install & restart.');
 }catch(e){updateMessage(e.message,true)}finally{updateSetBusy(false);$('applyUpdate').disabled=!updateStaged}
}
async function updateInstall(rollback=false){
 if(!window.confirm(rollback?'Restore the previous Core Motion version? Your model and settings files will stay untouched.':'Install the verified update now? The local Studio will restart automatically.'))return;
 updateSetBusy(true);updateMessage('Stopping the local server, applying the update, then restarting. Keep this tab open…');
 try{
  updatePreviousVersion=(await updateGetStatus()).version;
  await updateRequest(rollback?'/rollback':'/apply',{method:'POST'});
  updatePolling=true;
  let attempts=0;
  const polling=async()=>{
   if(!updatePolling)return;
   try{
    const fresh=await updateGetStatus();
    if(fresh.state==='error'){
     updateMessage('Update failed: '+fresh.message,true);updatePolling=false;updateSetBusy(false);return;
    }
    if(fresh.state==='success'&&!fresh.queued&&fresh.message&&fresh.version!==updatePreviousVersion){
     updatePolling=false;updateMessage(fresh.message+'\nReloading Studio…');setTimeout(()=>location.reload(),1200);return;
    }
   }catch{} // Temporary disconnect is expected while the local server restarts.
   if(++attempts>100){updateMessage('The Studio has not reconnected. If necessary, run start_windows.bat again. Your files are backed up.',true);updatePolling=false;updateSetBusy(false);return;}
   setTimeout(polling,1500);
  };
  setTimeout(polling,1500);
 }catch(e){updateMessage(e.message,true);updateSetBusy(false)}
}
function initUpdater(){
 const open=async()=>{
  $('updateVeil').classList.add('show');
  try{
   const status=await updateGetStatus();
   updateMessage(status.message||('Installed: Core Motion V'+status.version+'.\nConfigure a GitHub release source, or choose a future update ZIP.'));
  }catch(e){updateMessage('Cannot reach local updater: '+e.message,true)}
 };
 $('updateButton').addEventListener('click',open);
 $('closeUpdate').addEventListener('click',()=>$('updateVeil').classList.remove('show'));
 $('updateVeil').addEventListener('click',(e)=>{if(e.target===$('updateVeil'))$('updateVeil').classList.remove('show')});
 $('checkUpdate').addEventListener('click',updateCheck);
 $('downloadUpdate').addEventListener('click',updateStageRemote);
 $('applyUpdate').addEventListener('click',()=>updateInstall(false));
 $('rollbackUpdate').addEventListener('click',()=>updateInstall(true));
 $('stageManualUpdate').addEventListener('click',updateStageFile);
 $('saveUpdateSource').addEventListener('click',async()=>{
  try{
   const r=await updateRequest('/source',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({feed_url:$('updateFeedUrl').value.trim()})});
   updateMessage(r.feed_url?'Release source saved. Click Check for updates.':'Release source cleared.');
  }catch(e){updateMessage(e.message,true)}
 });
}
initUpdater();

// V6.8 Motion Workspace: non-destructive clip recipes and sequential preview.
// No animation tracks, original GLBs, or V6.7 sprite-rendering functions are rewritten.
function wsKey(){return 'coremotion-motion-workspace-v1::'+(state.calibrationKey||'temporary-model')}
const wsClamp=(n,min,max)=>Math.min(max,Math.max(min,Number.isFinite(+n)?+n:min));
function wsSafeStep(raw){
 if(!raw||typeof raw.source!=='string')return null;
 const ease=['linear','ease-in','ease-out','ease-in-out'];
 const keyframes=Array.isArray(raw.keyframes)?raw.keyframes.filter(k=>k&&typeof k.bone==='string'&&k.bone.length>0).slice(0,32).map(k=>({
  bone:k.bone.slice(0,100),at:Math.round(wsClamp(k.at,1,99)),rx:wsClamp(k.rx,-45,45),ry:wsClamp(k.ry,-45,45),rz:wsClamp(k.rz,-45,45)
 })):[];
 return {source:raw.source.slice(0,200),label:String(raw.label||raw.source).slice(0,80),
  speed:wsClamp(raw.speed,0.25,2),start:wsClamp(raw.start,0,94),end:wsClamp(raw.end,6,100),
  repeats:Math.round(wsClamp(raw.repeats,1,4)),
  easing:ease.includes(raw.easing)?raw.easing:'linear',fade:wsClamp(raw.fade??0.18,0,.8),keyframes};
}
function workspaceLoad(){
 const key=wsKey();if(motionWorkspace.key===key)return;
 workspaceStopSequence();motionWorkspace.key=key;motionWorkspace.favorites=new Set();motionWorkspace.variants=[];motionWorkspace.queue=[];
 try{
  const v=JSON.parse(localStorage.getItem(key)||'{}');
  if(Array.isArray(v.favorites))motionWorkspace.favorites=new Set(v.favorites.filter(x=>typeof x==='string').slice(0,200));
  if(Array.isArray(v.variants))motionWorkspace.variants=v.variants.slice(0,70).map(x=>({...wsSafeStep(x),id:String(x.id||''),label:String(x.label||'Unnamed').slice(0,80)})).filter(x=>x.source&&x.id&&x.start<x.end);
  if(Array.isArray(v.queue))motionWorkspace.queue=v.queue.slice(0,80).map(wsSafeStep).filter(x=>x&&x.start<x.end);
 }catch{} // Safe fallback if browser storage is missing or invalid.
 motionWorkspace.nextId=1+motionWorkspace.variants.reduce((n,v)=>Math.max(n,Number(v.id)||0),0);
}
function workspaceSave(){
 if(!motionWorkspace.key)return;
 try{localStorage.setItem(motionWorkspace.key,JSON.stringify({schema:'coremotion-motion-workspace-v1',favorites:[...motionWorkspace.favorites],variants:motionWorkspace.variants,queue:motionWorkspace.queue}))}
 catch{wsMessage('Local browser storage is unavailable. Use Export recipe JSON to keep a copy.',true)}
}
function wsMessage(message,isError=false){const el=$('wsStatus');if(!el)return;el.textContent=message;el.classList.toggle('error',isError)}
function wsCategory(name){
 const n=String(name).toLowerCase();
 if(/walk|run|sprint|sneak|swim|crawl|jump|fall|dodge|roll|climb|fly/.test(n))return 'movement';
 if(/punch|kick|slash|sword|attack|hit|shoot|fire|combo|block|guard|death|damage|fight|kata/.test(n))return 'combat';
 return 'other';
}
function wsButton(label,handler,title=''){
 const b=document.createElement('button');b.type='button';b.textContent=label;b.title=title;b.addEventListener('click',handler);return b;
}
function wsClipByName(name){return state.clips.find(c=>c.name===name)}
function wsAddStep(step){
 if(motionWorkspace.queue.length>=80){wsMessage('Maximum 80 sequence steps.',true);return}
 const value=wsSafeStep(step);
 if(!value||!wsClipByName(value.source)||value.start>=value.end){wsMessage('That source clip is not available.',true);return}
 workspaceStopSequence();motionWorkspace.queue.push(value);motionWorkspace.selectedStep=motionWorkspace.queue.length-1;
 workspaceSave();workspaceRenderQueue();wsMessage(`Added ${value.label} to timeline.`);
}
function workspaceRefresh(){
 if(!$('wsLibrary'))return;
 workspaceLoad();
 $('wsCurrentClip').textContent=state.selection.startsWith('clip::')?state.selection.slice(6):'No clip selected';
 const original=$('wsVariantSource').value;
 $('wsVariantSource').replaceChildren();
 for(const c of state.clips){const o=document.createElement('option');o.value=c.name;o.textContent=c.name;$('wsVariantSource').append(o)}
 $('wsVariantSource').value=state.clips.some(x=>x.name===original)?original:(state.clips.find(c=>state.selection==='clip::'+c.name)?.name||state.clips[0]?.name||'');
 $('wsVariantSave').disabled=!state.clips.length;
 $('wsQueuePlay').disabled=!state.clips.length;
 $('wsQueueBatch').disabled=!state.clips.length;
 workspaceRenderLibrary();workspaceRenderVariants();workspaceRenderQueue();
}
function workspaceRenderLibrary(){
 const root=$('wsLibrary');if(!root)return;root.replaceChildren();
 const term=$('wsSearch').value.toLowerCase().trim();const filter=$('wsFilter').value;
 const list=state.clips.filter(c=>c.name.toLowerCase().includes(term)&&(filter==='all'||(filter==='favorites'&&motionWorkspace.favorites.has(c.name))||wsCategory(c.name)===filter));
 if(!list.length){const p=document.createElement('p');p.className='tiny';p.textContent=state.clips.length?'No clips match this filter.':'Load an animated character and attach its saved clips.';root.append(p);return}
 for(const clip of list){
  const row=document.createElement('div');row.className='wsItem';
  const star=wsButton(motionWorkspace.favorites.has(clip.name)?'★':'☆',()=>{
   if(motionWorkspace.favorites.has(clip.name))motionWorkspace.favorites.delete(clip.name);else motionWorkspace.favorites.add(clip.name);
   workspaceSave();workspaceRenderLibrary();
  },'Mark clip as favorite');star.className='wsStar';
  const text=document.createElement('span');text.className='wsItemTitle';text.textContent=`${clip.name} · ${clip.duration.toFixed(2)}s`;text.title=clip.name;
  row.append(star,text,wsButton('▶',()=>{chooseClip(clip);wsMessage('Previewing '+clip.name)},'Preview this clip'),wsButton('+',()=>wsAddStep({source:clip.name,label:clip.name,speed:1,start:0,end:100,repeats:1}),'Add to timeline'));
  root.append(row);
 }
}
function workspaceRenderVariants(){
 const root=$('wsVariants');root.replaceChildren();
 const available=motionWorkspace.variants.filter(v=>wsClipByName(v.source));
 if(!available.length){const p=document.createElement('p');p.className='tiny';p.textContent='No saved motion variations yet.';root.append(p);return}
 for(const v of available){
  const row=document.createElement('div');row.className='wsItem';const label=document.createElement('span');label.className='wsItemTitle';
  label.textContent=`${v.label} · ${v.speed}× · ${v.start}–${v.end}%`;label.title=`Uses original clip ${v.source}, ${v.repeats} repeat(s)`;
  row.append(label,wsButton('▶',()=>workspaceStart([v]),'Preview variation'),wsButton('+',()=>wsAddStep(v),'Add variation to timeline'),wsButton('×',()=>{motionWorkspace.variants=motionWorkspace.variants.filter(x=>x.id!==v.id);workspaceSave();workspaceRenderVariants()},'Delete saved variation'));
  root.append(row)
 }
}
function workspaceRenderQueue(){
 const root=$('wsQueue');root.replaceChildren();let seconds=0;let missing=0;
 for(const [i,s] of motionWorkspace.queue.entries()){
  const clip=wsClipByName(s.source);if(clip)seconds+=clip.duration*(s.end-s.start)/100*s.repeats/s.speed;else missing++;
  const row=document.createElement('div');row.className='wsItem';
  const label=document.createElement('span');label.className='wsItemTitle';label.textContent=`${i+1}. ${s.label} · ${s.speed}×${s.repeats>1?' ×'+s.repeats:''}`;
  if(!clip){label.textContent+=' [missing GLB clip]';label.style.color='#ff9ca9'}
  const up=wsButton('↑',()=>wsMoveQueue(i,-1),'Move earlier');up.disabled=i===0;
  const down=wsButton('↓',()=>wsMoveQueue(i,1),'Move later');down.disabled=i===motionWorkspace.queue.length-1;
  label.style.cursor='pointer';label.title='Click to edit this timeline step';label.addEventListener('click',()=>wsSelectStep(i));
  row.append(label,up,down,wsButton('×',()=>{workspaceStopSequence();motionWorkspace.queue.splice(i,1);
   motionWorkspace.selectedStep=Math.max(0,Math.min(motionWorkspace.selectedStep,motionWorkspace.queue.length-1));
   workspaceSave();workspaceRenderQueue()},'Remove from sequence'));root.append(row);
 }
 $('wsQueueSummary').textContent=`${motionWorkspace.queue.length} step(s) · ~${seconds.toFixed(1)}s${missing?' · '+missing+' clip(s) missing':''}`;
 $('wsQueueExport').disabled=!motionWorkspace.queue.length;
 $('wsQueuePlay').disabled=!motionWorkspace.queue.length||!!missing;
 $('wsQueueBatch').disabled=!motionWorkspace.queue.length||!!missing;
 if(!motionWorkspace.queue.length){const p=document.createElement('p');p.className='tiny';p.textContent='Add clips or saved variations above to build a sequence.';root.append(p)}
 if($('wsSequenceExportBtn'))$('wsSequenceExportBtn').disabled=!motionWorkspace.queue.length||!!missing;
 if($('wsTimelineScrub'))$('wsTimelineScrub').disabled=!motionWorkspace.queue.length||!!missing;
 if($('wsTimelineReplay'))$('wsTimelineReplay').disabled=!motionWorkspace.queue.length||!!missing;
 workspaceRenderTimeline();wsRenderStepEditor();
}
function wsMoveQueue(i,delta){const j=i+delta;if(j<0||j>=motionWorkspace.queue.length)return;
 workspaceStopSequence();const a=motionWorkspace.queue;[a[i],a[j]]=[a[j],a[i]];
 motionWorkspace.selectedStep=j;workspaceSave();workspaceRenderQueue()}
function workspaceExportRecipe(){
 const steps=motionWorkspace.queue.map(s=>({...s,source_duration_seconds:wsClipByName(s.source)?.duration||null}));
 const summary={schema:'coremotion-motion-recipe-v2',studio:'Core Motion V6.9',character:state.calibrationKey||null,sequence:'Custom motion sequence',steps,
  note:'Non-destructive timeline recipe with per-step timing, held-pose transition fades and optional bone rotation offsets. Not a merged GLB or an automatically generated 3D animation.'};
 download(new Blob([JSON.stringify(summary,null,2)],{type:'application/json'}),'CoreMotion_Motion_Sequence.json');wsMessage('Sequence recipe saved as JSON.');
}
function initWorkspace(){
 $('wsSearch').addEventListener('input',workspaceRenderLibrary);
 $('wsFilter').addEventListener('change',workspaceRenderLibrary);
 $('wsVariantSave').addEventListener('click',()=>{
  const source=$('wsVariantSource').value;
  const raw={source,label:$('wsVariantName').value.trim(),speed:Number($('wsVariantSpeed').value),start:Number($('wsVariantStart').value),end:Number($('wsVariantEnd').value),repeats:Number($('wsVariantRepeats').value)};
  if(!source||!wsClipByName(source)){wsMessage('Select a source animation first.',true);return}
  if(!raw.label){wsMessage('Enter a name for the motion variation.',true);return}
  if(raw.start>=raw.end){wsMessage('End percentage must be greater than start.',true);return}
  if(motionWorkspace.variants.length>=70){wsMessage('Maximum 70 saved variations.',true);return}
  const v={...wsSafeStep(raw),id:String(motionWorkspace.nextId++)};
  motionWorkspace.variants.push(v);workspaceSave();workspaceRenderVariants();$('wsVariantName').value='';wsMessage(`Saved ${v.label}. This is a reusable timing variation of ${source}.`);
 });
 $('wsQueuePlay').addEventListener('click',()=>workspaceStart(motionWorkspace.queue));
 $('wsStop').addEventListener('click',()=>{workspaceStopSequence();state.playing=false;$('playBtn').textContent='▶ Play';wsMessage('Sequence preview stopped.');});
 $('wsQueueClear').addEventListener('click',()=>{workspaceStopSequence();motionWorkspace.queue=[];motionWorkspace.selectedStep=0;workspaceSave();workspaceRenderQueue();wsMessage('Timeline cleared. Saved variations were kept.');});
 $('wsQueueExport').addEventListener('click',workspaceExportRecipe);
 $('wsQueueBatch').addEventListener('click',()=>{
  loadBatchFramePrefs();const present=new Set(state.clips.map(x=>x.name));
  for(const step of motionWorkspace.queue)if(present.has(step.source))batchSelectedNames.add(step.source);
  refreshBatchClips();wsMessage('Source clips selected in Batch Export below. The exporter still uses complete original clips, not trimmed variation ranges.');
 });
 $('wsVariantSource').addEventListener('change',()=>{const c=wsClipByName($('wsVariantSource').value);if(c)wsMessage('Source: '+c.name+' · '+c.duration.toFixed(2)+'s')});
 workspaceRefresh();
}
initWorkspace();


// V6.9 TIMELINE ENGINE — non-destructive timeline evaluation and sprite-sequence export.
// The original V6.7/V6.6 single-clip and batch renderers are deliberately unchanged.
const WS_V69_EASING=['linear','ease-in','ease-out','ease-in-out'];
function wsEase(t,mode){
 t=wsClamp(t,0,1);
 if(mode==='ease-in')return t*t;
 if(mode==='ease-out')return 1-(1-t)*(1-t);
 if(mode==='ease-in-out')return t*t*(3-2*t);
 return t;
}
function wsBuildTimeline(steps){
 const segments=[];let cursor=0;
 for(let i=0;i<steps.length;i++){
  const step=steps[i],clip=wsClipByName(step.source);
  if(!clip||step.end<=step.start)throw new Error('A source clip is missing or a trim range is invalid: '+step.source);
  const perRepeat=clip.duration*(step.end-step.start)/100/step.speed;
  if(!(perRepeat>0)||!Number.isFinite(perRepeat))throw new Error('Invalid sequence duration');
  for(let r=0;r<step.repeats;r++){
   segments.push({step,stepIndex:i,repeatIndex:r,begin:cursor,end:cursor+perRepeat,duration:perRepeat,clip});
   cursor+=perRepeat;
  }
 }
 if(!segments.length)throw new Error('Add animation clips to the timeline first.');
 if(cursor>180)throw new Error('Sequence exceeds 180 seconds. Trim or shorten its clips.');
 return {segments,duration:cursor,steps};
}
function wsLocate(t,timeline){
 const seconds=wsClamp(t,0,Math.max(0,timeline.duration-0.000001));
 const index=timeline.segments.findIndex(s=>seconds<s.end);
 const idx=index<0?timeline.segments.length-1:index;
 const seg=timeline.segments[idx];
 const phase=wsClamp((seconds-seg.begin)/seg.duration,0,1);
 return {seg,index:idx,phase,seconds};
}
function wsSelectSourceClip(clip){
 if(state.selection==='clip::'+clip.name)return;
 const ws=motionWorkspace,wasSwitching=ws.switching,wasPlaying=state.playing;
 ws.switching=true;
 try{chooseClip(clip)}finally{ws.switching=wasSwitching;state.playing=wasPlaying}
}
function wsBoneByName(name){let found=null;state.model?.traverse(o=>{if(!found&&o.isBone&&o.name===name)found=o});return found}
function wsApplyPoseKeys(step,clipPercent){
 if(!step.keyframes?.length||!state.model)return;
 const names=[...new Set(step.keyframes.map(k=>k.bone))];
 for(const name of names){
  const bone=wsBoneByName(name);if(!bone)continue;
  const entries=step.keyframes.filter(k=>k.bone===name).sort((a,b)=>a.at-b.at);
  const points=[{at:0,rx:0,ry:0,rz:0},...entries,{at:100,rx:0,ry:0,rz:0}];
  const at=wsClamp(clipPercent,0,100);
  let a=points[0],b=points[points.length-1];
  for(let i=0;i<points.length-1;i++)if(at>=points[i].at&&at<=points[i+1].at){a=points[i];b=points[i+1];break}
  const weight=b.at>a.at?(at-a.at)/(b.at-a.at):1;
  const toRad=Math.PI/180;
  const x=(a.rx+(b.rx-a.rx)*weight)*toRad;
  const y=(a.ry+(b.ry-a.ry)*weight)*toRad;
  const z=(a.rz+(b.rz-a.rz)*weight)*toRad;
  bone.quaternion.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(x,y,z,'XYZ'))).normalize();
 }
 state.model.updateMatrixWorld(true);
}
function wsSampleSegment(seg,phase){
 wsSelectSourceClip(seg.clip);
 const step=seg.step,normalized=wsEase(phase,step.easing);
 const percent=step.start+(step.end-step.start)*normalized;
 const clipTime=Math.min(seg.clip.duration-0.00002,Math.max(0,seg.clip.duration*percent/100));
 state.time=clipTime;
 updateAnimation(clipTime);
 wsApplyPoseKeys(step,phase*100);
 return clipTime;
}
function wsCaptureLocalPose(){
 const pose=[];
 state.model?.traverse(o=>pose.push({obj:o,position:o.position.clone(),rotation:o.quaternion.clone(),scale:o.scale.clone(),morph:o.morphTargetInfluences?.slice()||null}));
 return pose;
}
function wsBlendFromPose(pose,alpha){
 for(const p of pose){const o=p.obj;if(!o||!o.position)continue;
  o.position.lerpVectors(p.position,o.position.clone(),alpha);
  o.quaternion.slerpQuaternions(p.rotation,o.quaternion.clone(),alpha).normalize();
  o.scale.lerpVectors(p.scale,o.scale.clone(),alpha);
  if(p.morph&&o.morphTargetInfluences)for(let i=0;i<Math.min(p.morph.length,o.morphTargetInfluences.length);i++){
   o.morphTargetInfluences[i]=p.morph[i]*(1-alpha)+o.morphTargetInfluences[i]*alpha;
  }
 }
 state.model.updateMatrixWorld(true);
}
function workspaceSampleAt(seconds,timeline,showUI=false){
 if(!state.loaded||!state.mixer||!timeline)return;
 const oldPlaying=state.playing,{seg,index,phase,seconds:actual}=wsLocate(seconds,timeline);
 // Blend from the previous segment's held final pose into the new clip's
 // progressing pose. Unlike a live two-mixer blend, the outgoing clip is frozen.
 const fade=Math.min(seg.step.fade,seg.duration*0.48);
 if(index>0&&fade>0&&actual-seg.begin<fade){
  const prev=timeline.segments[index-1];
  wsSampleSegment(prev,0.99999);
  const prevPose=wsCaptureLocalPose();
  wsSampleSegment(seg,phase);
  wsBlendFromPose(prevPose,wsEase((actual-seg.begin)/fade,'ease-in-out'));
 }else wsSampleSegment(seg,phase);
 state.playing=oldPlaying;
 if(showUI){
  const label=`${seg.stepIndex+1}/${timeline.steps.length}: ${seg.step.label} (${seg.repeatIndex+1}/${seg.step.repeats})`;
  $('wsPlaying').textContent=`${label} · ${actual.toFixed(2)} / ${timeline.duration.toFixed(2)}s`;
  $('wsTimelineScrub').value=String(Math.round(actual/timeline.duration*1000));
  $('wsTimelineTime').textContent=`${actual.toFixed(2)}s / ${timeline.duration.toFixed(2)}s`;
  $('wsTimelineTrack')?.querySelectorAll('.wsClipBlock').forEach((el)=>el.classList.toggle('wsNow',Number(el.dataset.stepIndex)===seg.stepIndex));
 }
}
function workspaceStopSequence(){
 const ws=motionWorkspace;
 ws.running=false;ws.steps=[];ws.timeline=null;ws.elapsed=0;ws.index=0;ws.repeatNumber=1;
 if($('wsStop'))$('wsStop').disabled=true;
 if($('wsPlaying'))$('wsPlaying').textContent='Stopped';
}
function workspaceStart(rawSteps,opts={}){
 if(!state.loaded||!state.mixer){wsMessage('Load a rigged and animated character first.',true);return}
 const steps=rawSteps.map(wsSafeStep);
 if(steps.some(s=>!s||s.start>=s.end||!wsClipByName(s.source))||!steps.length){wsMessage('Sequence contains a missing clip or invalid segment.',true);return}
 let timeline;try{timeline=wsBuildTimeline(steps)}catch(e){wsMessage(e.message,true);return}
 workspaceStopSequence();
 const ws=motionWorkspace;ws.running=true;ws.steps=steps;ws.timeline=timeline;ws.elapsed=wsClamp(opts.startTime??0,0,timeline.duration);
 state.playing=opts.play!==false;
 $('playBtn').textContent=state.playing?'❚❚ Pause':'▶ Play';
 $('wsStop').disabled=false;
 workspaceSampleAt(ws.elapsed,timeline,true);updateProgressUI();last=performance.now();
 wsMessage('Timeline '+(state.playing?'playing':'scrubbing')+'. Transition fades blend from the previous held pose; source GLBs remain unchanged.');
}
function workspaceTick(delta){
 const ws=motionWorkspace;if(!ws.running||!ws.timeline)return;
 ws.elapsed=Math.min(ws.timeline.duration,ws.elapsed+delta);
 workspaceSampleAt(ws.elapsed,ws.timeline,true);
 if(ws.elapsed+0.000001>=ws.timeline.duration){
  state.playing=false;$('playBtn').textContent='↻ Replay';
  ws.running=false;$('wsStop').disabled=true;
  $('wsPlaying').textContent='Sequence complete';wsMessage('Finished. The final pose is held and source GLBs were not modified.');
 }
}
function wsSelectStep(index){
 if(index<0||index>=motionWorkspace.queue.length)return;
 motionWorkspace.selectedStep=index;workspaceRenderTimeline();wsRenderStepEditor();
}
function workspaceRenderTimeline(){
 const track=$('wsTimelineTrack');if(!track)return;
 track.replaceChildren();
 let tl=null;try{if(motionWorkspace.queue.length)tl=wsBuildTimeline(motionWorkspace.queue)}catch(e){/* Missing clips are handled by the library list. */}
 if(!tl){track.textContent='Add motion clips to create an editable timeline.';$('wsTimelineTime').textContent='0.00s / 0.00s';return}
 for(let i=0;i<motionWorkspace.queue.length;i++){
  const s=motionWorkspace.queue[i],clips=tl.segments.filter(g=>g.stepIndex===i);
  const duration=clips.reduce((n,g)=>n+g.duration,0),el=document.createElement('button');
  el.type='button';el.draggable=true;el.className='wsClipBlock'+(motionWorkspace.selectedStep===i?' wsSelected':'');
  el.dataset.stepIndex=String(i);el.style.flexGrow=String(Math.max(0.1,duration));
  el.title=`Drag to reorder. ${s.source}, ${duration.toFixed(2)} seconds. Click to edit.`;
  const text=document.createElement('strong');text.textContent=s.label;
  const sub=document.createElement('span');sub.textContent=`${duration.toFixed(1)}s · ${s.easing}`;
  el.append(text,sub);el.addEventListener('click',()=>wsSelectStep(i));
  el.addEventListener('dragstart',ev=>{ev.dataTransfer?.setData('text/plain',String(i));ev.dataTransfer.effectAllowed='move'});
  el.addEventListener('dragover',ev=>{ev.preventDefault();if(ev.dataTransfer)ev.dataTransfer.dropEffect='move'});
  el.addEventListener('drop',ev=>{ev.preventDefault();const from=Number(ev.dataTransfer?.getData('text/plain'));
    if(!Number.isInteger(from)||from<0||from>=motionWorkspace.queue.length||from===i)return;
    workspaceStopSequence();const [step]=motionWorkspace.queue.splice(from,1);motionWorkspace.queue.splice(i,0,step);
    motionWorkspace.selectedStep=i;workspaceSave();workspaceRenderQueue();wsMessage('Timeline reordered.');
  });
  track.append(el);
 }
 $('wsTimelineTime').textContent=motionWorkspace.running&&motionWorkspace.timeline?`${motionWorkspace.elapsed.toFixed(2)}s / ${motionWorkspace.timeline.duration.toFixed(2)}s`:`0.00s / ${tl.duration.toFixed(2)}s`;
}
function wsRenderStepEditor(){
 const ws=motionWorkspace,index=ws.selectedStep,s=ws.queue[index],panel=$('wsStepEditor');
 if(!panel)return;
 panel.hidden=!s;
 if(!s){$('wsKeyList').replaceChildren();return}
 $('wsSelectedLabel').textContent=`Step ${index+1} — ${s.label}`;
 $('wsStepSpeed').value=String(s.speed);$('wsStepEase').value=s.easing;
 $('wsStepFade').value=String(s.fade);$('wsStepRepeats').value=String(s.repeats);
 $('wsStepStart').value=String(s.start);$('wsStepEnd').value=String(s.end);
 const boneSel=$('wsKeyBone'),old=boneSel.value;boneSel.replaceChildren();
 const names=[];state.model?.traverse(o=>{if(o.isBone&&o.name&&!names.includes(o.name))names.push(o.name)});
 for(const name of names){const opt=document.createElement('option');opt.value=name;opt.textContent=name;boneSel.append(opt)}
 boneSel.value=names.includes(old)?old:(names[0]||'');
 $('wsKeySave').disabled=!names.length;
 wsRenderKeyframes();
}
function wsRenderKeyframes(){
 const s=motionWorkspace.queue[motionWorkspace.selectedStep],root=$('wsKeyList');root.replaceChildren();
 if(!s)return;
 if(!s.keyframes?.length){const p=document.createElement('span');p.className='tiny';p.textContent='No pose offsets yet. Your source animation remains unchanged.';root.append(p);return}
 for(const k of s.keyframes){const row=document.createElement('div');row.className='wsItem';
  const label=document.createElement('span');label.className='wsItemTitle';label.textContent=`${k.bone} · ${k.at}% · (${k.rx}°, ${k.ry}°, ${k.rz}°)`;
  row.append(label,wsButton('×',()=>{workspaceStopSequence();s.keyframes=s.keyframes.filter(x=>x!==k);workspaceSave();wsRenderKeyframes();},'Remove pose keyframe'));root.append(row);
 }
}
function wsUpdateSelectedStep(){
 const s=motionWorkspace.queue[motionWorkspace.selectedStep];if(!s)return;
 const start=wsClamp($('wsStepStart').value,0,94),end=wsClamp($('wsStepEnd').value,6,100);
 if(start>=end){wsMessage('End % must be greater than start %.',true);return}
 workspaceStopSequence();s.start=start;s.end=end;s.speed=wsClamp($('wsStepSpeed').value,.25,2);
 s.repeats=Math.round(wsClamp($('wsStepRepeats').value,1,4));
 s.fade=wsClamp($('wsStepFade').value,0,.8);
 s.easing=WS_V69_EASING.includes($('wsStepEase').value)?$('wsStepEase').value:'linear';
 workspaceSave();workspaceRenderQueue();wsMessage(`Updated ${s.label}: ${s.easing} timing, ${s.fade.toFixed(2)}s pose fade.`);
}
function wsKeySave(){
 const s=motionWorkspace.queue[motionWorkspace.selectedStep],bone=$('wsKeyBone').value;
 if(!s||!bone||!wsBoneByName(bone)){wsMessage('Select a valid rig bone first.',true);return}
 const k={bone,at:Math.round(wsClamp($('wsKeyAt').value,1,99)),rx:wsClamp($('wsKeyX').value,-45,45),ry:wsClamp($('wsKeyY').value,-45,45),rz:wsClamp($('wsKeyZ').value,-45,45)};
 workspaceStopSequence();s.keyframes=s.keyframes||[];
 const j=s.keyframes.findIndex(x=>x.bone===k.bone&&x.at===k.at);
 if(j>=0)s.keyframes[j]=k;else if(s.keyframes.length<32)s.keyframes.push(k);else{wsMessage('Limit: 32 bone keyframes per step.',true);return}
 s.keyframes.sort((a,b)=>a.at-b.at);workspaceSave();wsRenderKeyframes();
 wsMessage(`Pose offset at ${k.at}% saved for ${k.bone}. This rotates the joint locally; the GLB is unchanged.`);
}
function wsSequencePoseAt(seconds,dir,ref,anchor,anchorPoint,timeline){
 state.pivot.position.set(0,0,0);state.pivot.rotation.y=DIRS.indexOf(dir)*Math.PI/4;
 workspaceSampleAt(seconds,timeline,false);
 state.pivot.updateMatrixWorld(true);
 const point=anchor.getWorldPosition(anchorPoint);
 state.pivot.position.set(ref.x-point.x,0,ref.z-point.z);state.pivot.updateMatrixWorld(true);
 return exportVisibleBounds();
}
async function wsSequenceCameraPlan(timeline,count){
 const anchor=exportRigAnchor(),anchorPoint=new THREE.Vector3(),refs={};
 const extent={minX:Infinity,maxX:-Infinity,minY:Infinity,maxY:-Infinity,minZ:Infinity,maxZ:-Infinity};
 for(let d=0;d<DIRS.length;d++){
  const dir=DIRS[d];state.pivot.position.set(0,0,0);state.pivot.rotation.y=d*Math.PI/4;
  workspaceSampleAt(0,timeline,false);state.pivot.updateMatrixWorld(true);
  refs[dir]=anchor.getWorldPosition(anchorPoint).clone();
  for(let i=0;i<count;i++){
   const t=timeline.duration*(i/(count-1)),b=wsSequencePoseAt(t,dir,refs[dir],anchor,anchorPoint,timeline);
   extent.minX=Math.min(extent.minX,b.min.x);extent.maxX=Math.max(extent.maxX,b.max.x);
   extent.minY=Math.min(extent.minY,b.min.y);extent.maxY=Math.max(extent.maxY,b.max.y);
   extent.minZ=Math.min(extent.minZ,b.min.z);extent.maxZ=Math.max(extent.maxZ,b.max.z);
  }
  if(d%2===1)await new Promise(done=>setTimeout(done,0));
 }
 const width=extent.maxX-extent.minX,height=extent.maxY-extent.minY;
 if(!Number.isFinite(width+height)||width<=0||height<=0)throw new Error('Invalid animated bounds for sequence');
 const framing=Number($('exportFitSlider').value)/100;
 const half=Math.max(width,height)*.5*Math.max(1.12,1.25*framing);
 const cameraZ=extent.maxZ+Math.max(10,extent.maxZ-extent.minZ+5);
 return {halfExtent:Math.max(.15,half),centerX:(extent.minX+extent.maxX)/2,centerY:(extent.minY+extent.maxY)/2,
  cameraZ,cameraFar:Math.max(100,cameraZ-extent.minZ+25),refs,measuredBounds:{...extent}};
}
async function wsRenderSequenceSheet(dir,timeline,plan,count){
 const size=Number($('sizeSelect').value),columns=Number($('colSelect').value),rows=Math.ceil(count/columns);
 const sheet=document.createElement('canvas');sheet.width=size*columns;sheet.height=size*rows;
 if(sheet.width>16384||sheet.height>16384||sheet.width*sheet.height>80000000)
  throw new Error('Sequence sheet too large. Reduce sprite size or frame count.');
 const ctx=sheet.getContext('2d',{willReadFrequently:true});ctx.clearRect(0,0,sheet.width,sheet.height);
 const savedSize=new THREE.Vector2();renderer.getSize(savedSize);
 const savedRatio=renderer.getPixelRatio();
 const savedCam={left:camera.left,right:camera.right,top:camera.top,bottom:camera.bottom,near:camera.near,far:camera.far,zoom:camera.zoom,
  position:camera.position.clone(),quaternion:camera.quaternion.clone()};
 const helperVisible=state.skeletonHelper?.visible,footVisible=footFloorGuide?.visible;
 const culling=[];state.model.traverse(o=>{if(o.isMesh){culling.push([o,o.frustumCulled]);o.frustumCulled=false}});
 const pixelStyle=state.style==='pixel',low=Math.min(size,Number($('pixelSelect').value));
 const renderSize=pixelStyle?low:Math.min(2048,size*2);
 const anchor=exportRigAnchor(),anchorPoint=new THREE.Vector3();
 try{
  renderer.setPixelRatio(1);renderer.setSize(renderSize,renderSize,false);
  camera.zoom=1;camera.left=-plan.halfExtent;camera.right=plan.halfExtent;
  camera.top=plan.halfExtent;camera.bottom=-plan.halfExtent;
  camera.near=.01;camera.far=plan.cameraFar;camera.updateProjectionMatrix();
  camera.quaternion.set(0,0,0,1);
  camera.position.set(plan.centerX,plan.centerY,plan.cameraZ);camera.updateMatrixWorld(true);
  if(state.skeletonHelper)state.skeletonHelper.visible=false;if(footFloorGuide)footFloorGuide.visible=false;
  for(let i=0;i<count;i++){
   if(batchExportCancel)throw new Error('Sequence export cancelled. No incomplete ZIP downloaded.');
   const t=timeline.duration*i/(count-1);
   const bound=wsSequencePoseAt(t,dir,plan.refs[dir],anchor,anchorPoint,timeline);
   const e=1e-5;
   if(bound.min.x<plan.centerX-plan.halfExtent-e||bound.max.x>plan.centerX+plan.halfExtent+e||
      bound.min.y<plan.centerY-plan.halfExtent-e||bound.max.y>plan.centerY+plan.halfExtent+e||
      bound.max.z>=plan.cameraZ-camera.near||bound.min.z<=plan.cameraZ-plan.cameraFar)
    throw new Error(`${dir} sequence frame ${i+1}/${count} exceeds camera bounds. Increase Export framing.`);
   v7RenderScene();
   const x=(i%columns)*size,y=Math.floor(i/columns)*size;
   ctx.imageSmoothingEnabled=!pixelStyle;if(!pixelStyle)ctx.imageSmoothingQuality='high';
   ctx.clearRect(x,y,size,size);ctx.drawImage(renderer.domElement,x,y,size,size);
   const frame=exportAlphaBounds(ctx,x,y,size);
   if(!frame)throw new Error(`${dir} sequence frame ${i+1}/${count} rendered blank. Export stopped.`);
   if(!exportBoundsInsideFrame(frame,size))throw new Error(`${dir} sequence frame ${i+1}/${count} is clipped. Increase Export framing.`);
   if(i%8===7)await new Promise(done=>setTimeout(done,0));
  }
  const blob=await dataURLBlob(sheet);if(!blob)throw new Error('Could not encode sequence sheet as PNG');return blob;
 }finally{
  for(const [o,old] of culling)o.frustumCulled=old;
  if(state.skeletonHelper)state.skeletonHelper.visible=helperVisible;
  if(footFloorGuide)footFloorGuide.visible=footVisible;
  renderer.setPixelRatio(savedRatio);renderer.setSize(savedSize.x,savedSize.y,false);
  Object.assign(camera,{left:savedCam.left,right:savedCam.right,top:savedCam.top,bottom:savedCam.bottom,near:savedCam.near,far:savedCam.far,zoom:savedCam.zoom});
  camera.position.copy(savedCam.position);camera.quaternion.copy(savedCam.quaternion);
  camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
 }
}
async function wsExportSequenceSprites(){
 if(state.exporting||!state.loaded||!state.mixer){wsMessage('Load a rigged character before exporting.',true);return}
 let tl;try{tl=wsBuildTimeline(motionWorkspace.queue)}catch(e){wsMessage(e.message,true);return}
 const count=Number($('wsExportCount').value),size=Number($('sizeSelect').value),cols=Number($('colSelect').value);
 if(![8,16,24,32,48,64].includes(count)){wsMessage('Invalid sequence frame count.',true);return}
 if(size*cols*Math.ceil(count/cols)*size>80000000){wsMessage('Sheet too large for safe export. Reduce sprite size or frames.',true);return}
 const oldClip=state.clips.find(c=>state.selection==='clip::'+c.name),oldTime=state.time,oldPlaying=state.playing;
 const oldDir=state.dir,oldPosition=state.pivot.position.clone(),oldRot=state.pivot.rotation.y;
 workspaceStopSequence();state.playing=false;state.exporting=true;batchExportCancel=false;
 $('wsSequenceExportBtn').disabled=true;
 const names=[];
 try{
  wsMessage('Measuring all sequence poses and directions…');
  const plan=await wsSequenceCameraPlan(tl,count);
  const pack=[];
  for(let j=0;j<DIRS.length;j++){
   const dir=DIRS[j];wsMessage(`Rendering sequence ${dir} (${j+1}/8) · ${count} frames…`);
   const blob=await wsRenderSequenceSheet(dir,tl,plan,count);
   const name=`sequence_${dir}_${size}px_${count}f.png`;
   pack.push({name,bytes:new Uint8Array(await blob.arrayBuffer())});names.push(name);
   await new Promise(done=>setTimeout(done,0));
  }
  const manifest={schema:'coremotion-sequence-sprites-v1',studio:'Core Motion V6.9',frames:count,columns:cols,
   rows:Math.ceil(count/cols),sprite_size_px:size,directions:DIRS,sequence_duration_seconds:tl.duration,
   sample_strategy:'full-sequence-uniform-time-including-last-pose',transition:'fade-from-previous-final-pose',
   stabilized_root_motion:'XZ',files:names,steps:tl.steps,transparent_background:true};
  pack.push({name:'manifest.json',bytes:new TextEncoder().encode(JSON.stringify(manifest,null,2))});
  download(rawZip(pack),'CoreMotion_Sequence_Sprite_Pack.zip');
  wsMessage(`Exported ${count} sequence frames × 8 directions with 8 PNGs + manifest.json.`);
 }catch(e){wsMessage('Sequence sprite export failed: '+(e?.message||e),true)}
 finally{
  if(oldClip){motionWorkspace.switching=true;try{chooseClip(oldClip)}finally{motionWorkspace.switching=false}}
  state.time=oldTime;state.pivot.position.copy(oldPosition);state.pivot.rotation.y=oldRot;
  if(oldClip)updateAnimation(oldTime);setDirection(oldDir);
  state.playing=oldPlaying;state.exporting=false;
  $('wsSequenceExportBtn').disabled=!motionWorkspace.queue.length;updateProgressUI();last=performance.now();
 }
}
function initTimelineV69(){
 for(const id of ['wsStepSpeed','wsStepEase','wsStepFade','wsStepRepeats','wsStepStart','wsStepEnd'])$(id).addEventListener('change',wsUpdateSelectedStep);
 $('wsKeySave').addEventListener('click',wsKeySave);
 $('wsSequenceExportBtn').addEventListener('click',wsExportSequenceSprites);
 $('wsTimelineScrub').addEventListener('input',e=>{
  if(!motionWorkspace.running){workspaceStart(motionWorkspace.queue,{play:false,startTime:0});if(!motionWorkspace.running)return}
  state.playing=false;$('playBtn').textContent='▶ Play';
  motionWorkspace.elapsed=motionWorkspace.timeline.duration*Number(e.target.value)/1000;
  workspaceSampleAt(motionWorkspace.elapsed,motionWorkspace.timeline,true);updateProgressUI();
 });
 $('wsTimelineReplay').addEventListener('click',()=>workspaceStart(motionWorkspace.queue,{play:true,startTime:0}));
 workspaceRenderTimeline();wsRenderStepEditor();
}
initTimelineV69();


// V7.0 RIG STUDIO — non-destructive rig posing, reusable poses and custom animation clips.
// Existing clip renderers, timeline, update client and AssetFurnace bridge are unchanged.
const rigStudio={key:null,bones:[],rest:new Map(),poses:[],motions:[],draft:null,selected:null,enabled:false,
 markers:null,markerMeshes:[],drag:null,layerPose:null,layerStrength:0,layerEnabled:false,liveKeys:false};
function v7Key(){return 'coremotion-rig-studio-v1::'+(state.calibrationKey||'temporary-rig')}
function v7Msg(msg,error=false){const el=$('rigStudioStatus');if(el){el.textContent=msg;el.classList.toggle('error',error)}}
function v7Name(text){return String(text||'').trim().slice(0,64)}
function v7AllBones(){const bones=[];const names=new Set();state.model?.traverse(o=>{if(o.isBone&&o.name&&!names.has(o.name)){names.add(o.name);bones.push(o)}});return bones}
function v7Snapshot(){const data={};for(const b of rigStudio.bones){const q=b.quaternion;data[b.name]=[q.x,q.y,q.z,q.w].map(n=>Math.round(n*1e6)/1e6)}return data}
function v7NormalizePose(raw){
 const out={};if(!raw||typeof raw!=='object')return out;
 const valid=new Set(rigStudio.bones.map(b=>b.name));
 for(const [name,q] of Object.entries(raw))if(valid.has(name)&&Array.isArray(q)&&q.length===4&&q.every(n=>typeof n==='number'&&Number.isFinite(n))){
   const quat=new THREE.Quaternion(q[0],q[1],q[2],q[3]);if(quat.lengthSq()>1e-8){quat.normalize();out[name]=quat.toArray()}
 }
 return out;
}
function v7StoredPose(raw){return raw&&typeof raw==='object'&&typeof raw.name==='string'&&raw.name.length>0?
 {name:v7Name(raw.name),bones:v7NormalizePose(raw.bones)}:null}
function v7StoredMotion(raw){
 if(!raw||typeof raw!=='object'||typeof raw.name!=='string')return null;
 const duration=wsClamp(raw.duration,.25,30);
 const keys=Array.isArray(raw.keys)?raw.keys.slice(0,70).map(k=>({at:wsClamp(k?.at,0,duration),bones:v7NormalizePose(k?.bones)})).sort((a,b)=>a.at-b.at):[];
 return {name:v7Name(raw.name),duration,keys};
}
function v7Save(){if(!rigStudio.key)return;
 try{localStorage.setItem(rigStudio.key,JSON.stringify({schema:'coremotion-rig-studio-v1',poses:rigStudio.poses,motions:rigStudio.motions,draft:rigStudio.draft,layerPose:rigStudio.layerPose,layerEnabled:rigStudio.layerEnabled,layerStrength:rigStudio.layerStrength}))}
 catch{v7Msg('Browser storage is full or disabled. Export the studio JSON to keep your edits.',true)}
}
function v7DestroyMarkers(){if(!rigStudio.markers)return;scene.remove(rigStudio.markers);for(const p of rigStudio.markerMeshes){p.geometry.dispose();p.material.dispose()}rigStudio.markerMeshes=[];rigStudio.markers=null}
function v7BeforeClear(){v7DestroyMarkers();rigStudio.key=null;rigStudio.bones=[];rigStudio.rest.clear();rigStudio.selected=null;rigStudio.enabled=false;rigStudio.drag=null;rigStudio.draft=null;rigStudio.layerEnabled=false}
function v7LoadRig(){
 rigStudio.key=v7Key();rigStudio.bones=v7AllBones();rigStudio.rest=new Map(rigStudio.bones.map(b=>[b.name,b.quaternion.clone()]));
 rigStudio.poses=[];rigStudio.motions=[];rigStudio.draft=null;rigStudio.selected=null;rigStudio.enabled=false;
 rigStudio.layerEnabled=false;rigStudio.layerStrength=0;rigStudio.layerPose=null;
 try{const data=JSON.parse(localStorage.getItem(rigStudio.key)||'{}');
  if(Array.isArray(data.poses))rigStudio.poses=data.poses.slice(0,40).map(v7StoredPose).filter(Boolean);
  if(Array.isArray(data.motions))rigStudio.motions=data.motions.slice(0,35).map(v7StoredMotion).filter(m=>m&&m.name&&m.keys.length>=2);
  if(data.draft)rigStudio.draft=v7StoredMotion(data.draft);
  rigStudio.layerPose=v7Name(data.layerPose||'')||null;
  rigStudio.layerStrength=wsClamp(data.layerStrength,0,1);
  rigStudio.layerEnabled=!!data.layerEnabled;
 }catch{}
 for(const motion of rigStudio.motions){const clip=v7BakeMotion(motion);if(clip)state.clips.push(clip)}
 if(!state.mixer&&state.clips.length)state.mixer=new THREE.AnimationMixer(state.model);
 v7BuildMarkers();v7RefreshUI();
 v7Msg(rigStudio.bones.length?`${rigStudio.bones.length} uniquely named rig joints available. Enable Pose mode to select and rotate them.`:'Rig Studio needs a weighted skeleton with named bones.',!rigStudio.bones.length);
}
function v7RestPose(){const values={};for(const [name,q] of rigStudio.rest)values[name]=q.toArray();return values}
function v7ApplyPose(values){for(const b of rigStudio.bones){const q=values?.[b.name];if(q)b.quaternion.fromArray(q).normalize()}state.model?.updateMatrixWorld(true);v7UpdateMarkers()}
function v7StopPreview(){if(motionWorkspace.running)workspaceStopSequence();state.playing=false;$('playBtn').textContent='▶ Play'}
function v7BuildMarkers(){v7DestroyMarkers();if(!scene||!rigStudio.bones.length)return;
 rigStudio.markers=new THREE.Group();rigStudio.markers.name='Core Motion pose handles (preview only)';rigStudio.markers.visible=false;scene.add(rigStudio.markers);
 const sphereGeometry=new THREE.SphereGeometry(.064,10,8);
 for(const bone of rigStudio.bones){const material=new THREE.MeshBasicMaterial({color:0x50cce3,depthTest:false,depthWrite:false,transparent:true,opacity:.87});
  const marker=new THREE.Mesh(sphereGeometry.clone(),material);marker.userData.rigBone=bone;
  marker.renderOrder=1000;rigStudio.markers.add(marker);rigStudio.markerMeshes.push(marker)}
 v7UpdateMarkers();
}
function v7UpdateMarkers(){if(!rigStudio.markers||!rigStudio.enabled||state.exporting)return;
 state.model?.updateMatrixWorld(true);
 for(let i=0;i<rigStudio.markerMeshes.length;i++){const marker=rigStudio.markerMeshes[i],bone=rigStudio.bones[i];bone.getWorldPosition(marker.position);
  const selected=rigStudio.selected===bone.name;marker.scale.setScalar(selected?1.5:1);marker.material.color.setHex(selected?0xffc576:0x50cce3)}
}
function v7RenderScene(){
 if(rigStudio.markers){rigStudio.markers.visible=!!(rigStudio.enabled&&!state.exporting);
  if(rigStudio.markers.visible)v7UpdateMarkers()}
 renderer.render(scene,camera);
}
function v7SetMode(enabled){if(!rigStudio.bones.length){v7Msg('Load a rigged character first.',true);$('rigPoseMode').checked=false;return}
 rigStudio.enabled=enabled;if(enabled){v7StopPreview();$('rigPoseMode').checked=true;v7Msg('Click the cyan joint spheres in the 3D view; drag to rotate along the selected local axis. Orange is the selected joint.')}
 else {rigStudio.drag=null;$('rigPoseMode').checked=false;v7Msg('Pose selection off. Normal viewport rotation is restored.')}
 if(rigStudio.markers)rigStudio.markers.visible=enabled;v7RefreshBoneSelect();v7UpdateMarkers();
}
const v7Raycaster=new THREE.Raycaster();const v7Pointer=new THREE.Vector2();
function v7PointerDown(e){if(!rigStudio.enabled||!rigStudio.markers||state.exporting)return false;
 const rect=stage.getBoundingClientRect();v7Pointer.set((e.clientX-rect.left)/rect.width*2-1,1-(e.clientY-rect.top)/rect.height*2);
 v7Raycaster.setFromCamera(v7Pointer,camera);v7UpdateMarkers();
 const hits=v7Raycaster.intersectObjects(rigStudio.markerMeshes,false);
 if(!hits.length)return false;
 const b=hits[0].object.userData.rigBone;v7StopPreview();rigStudio.selected=b.name;$('rigBoneSelect').value=b.name;
 rigStudio.drag={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,quaternion:b.quaternion.clone(),bone:b};
 stage.setPointerCapture(e.pointerId);v7UpdateMarkers();v7UpdateRotationInfo();return true;
}
function v7PointerMove(e){const drag=rigStudio.drag;if(!drag)return false;
 if(e.pointerId!==drag.pointerId)return false;
 const axis=$('rigDragAxis').value,delta=((e.clientX-drag.startX)-(e.clientY-drag.startY))*.008;
 const euler=new THREE.Euler(axis==='x'?delta:0,axis==='y'?delta:0,axis==='z'?delta:0,'XYZ');
 drag.bone.quaternion.copy(drag.quaternion).multiply(new THREE.Quaternion().setFromEuler(euler)).normalize();
 state.model.updateMatrixWorld(true);v7UpdateMarkers();v7UpdateRotationInfo();return true;
}
function v7PointerUp(){rigStudio.drag=null}
function v7UpdateRotationInfo(){const b=rigStudio.bones.find(x=>x.name===rigStudio.selected);if(!$('rigJointInfo'))return;
 $('rigJointInfo').textContent=b?`${b.name} · local quaternion ${b.quaternion.toArray().map(v=>v.toFixed(2)).join(', ')}`:'Select a joint sphere or choose a bone from the menu.';
}
function v7RefreshBoneSelect(){const select=$('rigBoneSelect'),prev=rigStudio.selected;select.replaceChildren();
 for(const bone of rigStudio.bones){const opt=document.createElement('option');opt.value=bone.name;opt.textContent=bone.name;select.append(opt)}
 if(prev&&rigStudio.bones.some(b=>b.name===prev))select.value=prev;
 else if(rigStudio.bones.length){rigStudio.selected=rigStudio.bones[0].name;select.value=rigStudio.selected}
 v7UpdateRotationInfo();
}
function v7Nudge(degrees){if(!rigStudio.bones.length)return;v7StopPreview();const b=rigStudio.bones.find(x=>x.name===$('rigBoneSelect').value);if(!b)return;
 const axis=$('rigDragAxis').value,rad=degrees*Math.PI/180;
 b.quaternion.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(axis==='x'?rad:0,axis==='y'?rad:0,axis==='z'?rad:0,'XYZ'))).normalize();
 rigStudio.selected=b.name;v7UpdateMarkers();v7UpdateRotationInfo();
}
function v7SavePose(){if(!rigStudio.bones.length)return;const name=v7Name($('rigPoseName').value);
 if(!name){v7Msg('Give this pose a name first.',true);return}
 const pose={name,bones:v7Snapshot()},idx=rigStudio.poses.findIndex(x=>x.name.toLowerCase()===name.toLowerCase());
 if(idx>=0)rigStudio.poses[idx]=pose;else if(rigStudio.poses.length<40)rigStudio.poses.push(pose);else{v7Msg('40 saved poses maximum.',true);return}
 v7Save();v7RefreshUI();$('rigPoseSelect').value=name;v7Msg('Saved pose '+name+' for this character. Original GLB unchanged.');
}
function v7LoadPose(){const name=$('rigPoseSelect').value,pose=rigStudio.poses.find(p=>p.name===name);if(!pose)return;
 v7StopPreview();v7ApplyPose(pose.bones);v7Msg('Applied '+pose.name+'. Save a keyframe to incorporate it into a custom animation.');
}
function v7MirrorBoneName(name){const tryNames=[
 name.replace(/Left/g,'Right'),name.replace(/Right/g,'Left'),name.replace(/left/g,'right'),name.replace(/right/g,'left'),
 name.replace(/^L_/,'R_'),name.replace(/^R_/,'L_'),name.replace(/_L$/,'_R'),name.replace(/_R$/,'_L'),
 name.replace(/\.L$/i,'.R'),name.replace(/\.R$/i,'.L')];
 const found=tryNames.find(n=>n!==name&&rigStudio.rest.has(n));return found||name;
}
function v7MirrorPose(){if(!rigStudio.bones.length)return;
 v7StopPreview();const captured=v7Snapshot(),result={};
 for(const b of rigStudio.bones){const from=v7MirrorBoneName(b.name),source=captured[from],restSrc=rigStudio.rest.get(from),restDst=rigStudio.rest.get(b.name);
  if(!source||!restSrc||!restDst)continue;
  const delta=restSrc.clone().invert().multiply(new THREE.Quaternion().fromArray(source));
  // Approximate sagittal reflection of a local quaternion around the X plane.
  delta.y*=-1;delta.z*=-1;
  result[b.name]=restDst.clone().multiply(delta.normalize()).normalize().toArray();
 }
 v7ApplyPose(result);v7Msg('Mirrored the pose across named left/right joints. Check shoulders and feet: unusual rig axes may require corrections.');
}
function v7ApplyLayer(){if(!rigStudio.layerEnabled||!rigStudio.layerPose||(rigStudio.enabled&&!state.exporting)||!rigStudio.bones.length)return;
 const p=rigStudio.poses.find(v=>v.name===rigStudio.layerPose);if(!p)return;
 const w=rigStudio.layerStrength;if(!w)return;
 for(const b of rigStudio.bones)if(/spine|chest|upperbody|torso|neck|head|shoulder|clavicle|arm|elbow|hand|wrist|finger|thumb/i.test(b.name)){
  const q=p.bones[b.name];if(q)b.quaternion.slerp(new THREE.Quaternion().fromArray(q),w).normalize();
 }
 state.model.updateMatrixWorld(true);
}
function v7RefreshPoseList(){const select=$('rigPoseSelect'),layer=$('rigLayerPose'),prior=select.value,layerPrev=rigStudio.layerPose;
 select.replaceChildren();layer.replaceChildren();
 for(const p of rigStudio.poses){for(const sel of [select,layer]){const option=document.createElement('option');option.value=p.name;option.textContent=p.name;sel.append(option)}}
 if(rigStudio.poses.some(p=>p.name===prior))select.value=prior;
 if(layerPrev&&rigStudio.poses.some(p=>p.name===layerPrev))layer.value=layerPrev;
 rigStudio.layerPose=layer.value||null;
 $('rigPoseLoad').disabled=!rigStudio.poses.length;$('rigPoseDelete').disabled=!rigStudio.poses.length;
 $('rigLayerEnable').disabled=!rigStudio.poses.length;
 $('rigLayerEnable').checked=!!rigStudio.layerEnabled;
 $('rigLayerStrength').value=String(Math.round(rigStudio.layerStrength*100));
 $('rigLayerStrengthValue').textContent=Math.round(rigStudio.layerStrength*100)+'%';
}
function v7BakeMotion(motion){if(!motion?.keys?.length||!rigStudio.bones.length)return null;
 const sorted=[...motion.keys].sort((a,b)=>a.at-b.at);
 if(sorted.length<2||sorted[0].at===sorted[sorted.length-1].at)return null;
 const tracks=[];const times=sorted.map(k=>k.at);
 for(const bone of rigStudio.bones){const fallback=rigStudio.rest.get(bone.name)?.toArray()||[0,0,0,1];const values=[];
  for(const key of sorted)values.push(...(key.bones[bone.name]||fallback));
  tracks.push(new THREE.QuaternionKeyframeTrack(bone.name+'.quaternion',times,values));
 }
 const clip=new THREE.AnimationClip('Studio · '+motion.name,motion.duration,tracks);
 clip.userData={rigStudio:true};return clip;
}
function v7RemoveClipByName(name){const index=state.clips.findIndex(c=>c.name===name);if(index<0)return;
 const existing=state.clips[index];state.mixer?.stopAllAction();state.mixer?.uncacheClip(existing);state.clips.splice(index,1);
}
function v7DraftNew(){if(!rigStudio.bones.length)return;
 const name=v7Name($('rigMotionName').value)||'Custom Movement';const duration=wsClamp($('rigMotionDuration').value,.25,30);
 const initial=v7RestPose();rigStudio.draft={name,duration,keys:[{at:0,bones:initial}]};
 v7StopPreview();v7ApplyPose(initial);$('rigMotionTime').value='0';v7RefreshMotionUI();v7Save();
 v7Msg(`New ${duration.toFixed(2)}s animation “${name}”. Pose the rig, pick a time, and Capture keyframe.`);
}
function v7DraftSample(time){const d=rigStudio.draft;if(!d||!rigStudio.bones.length)return;
 const t=wsClamp(time,0,d.duration);const keys=[...d.keys].sort((a,b)=>a.at-b.at);
 if(!keys.length){v7ApplyPose(v7RestPose());return}
 let a=keys[0],b=keys[keys.length-1];
 if(t<=keys[0].at)b=a;else if(t>=b.at)a=b;else for(let i=0;i<keys.length-1;i++)if(t>=keys[i].at&&t<=keys[i+1].at){a=keys[i];b=keys[i+1];break}
 const p=b.at>a.at?(t-a.at)/(b.at-a.at):0,pose={};
 for(const bone of rigStudio.bones){const rest=rigStudio.rest.get(bone.name)?.toArray()||[0,0,0,1];
  const q1=new THREE.Quaternion().fromArray(a.bones[bone.name]||rest),q2=new THREE.Quaternion().fromArray(b.bones[bone.name]||rest);
  pose[bone.name]=q1.slerp(q2,p).normalize().toArray();
 }
 v7StopPreview();v7ApplyPose(pose);
}
function v7CaptureKey(){const d=rigStudio.draft;if(!d){v7Msg('Click New motion before capturing keyframes.',true);return}
 const at=wsClamp($('rigMotionTime').value,0,d.duration),bones=v7Snapshot();let key=d.keys.find(k=>Math.abs(k.at-at)<.001);
 if(key)key.bones=bones;else if(d.keys.length<70)d.keys.push({at,bones});else{v7Msg('70 keyframes maximum.',true);return}
 d.keys.sort((a,b)=>a.at-b.at);v7Save();v7RefreshMotionUI();v7Msg(`Captured pose at ${at.toFixed(2)}s. The source character remains untouched.`);
}
function v7SaveMotion(){const d=rigStudio.draft;if(!d){v7Msg('Create a motion first.',true);return}
 if(d.keys.length<2||d.keys.at(-1).at-d.keys[0].at<.05){v7Msg('Capture at least two different times, such as 0.0 and 1.0 seconds.',true);return}
 const same=rigStudio.motions.findIndex(m=>m.name.toLowerCase()===d.name.toLowerCase());
 if(same<0&&rigStudio.motions.length>=35){v7Msg('35 animations maximum.',true);return}
 const saved={name:d.name,duration:d.duration,keys:d.keys.map(k=>({at:k.at,bones:{...k.bones}}))};
 const clip=v7BakeMotion(saved);if(!clip){v7Msg('Could not bake rig keyframes.',true);return}
 v7StopPreview();if(!state.mixer)state.mixer=new THREE.AnimationMixer(state.model);
 if(same>=0){v7RemoveClipByName('Studio · '+rigStudio.motions[same].name);rigStudio.motions[same]=saved}
 else rigStudio.motions.push(saved);
 state.clips.push(clip);v7Save();refreshClipUI();updatePipelineUI();chooseClip(clip);
 v7RefreshMotionUI();v7Msg(`Saved Studio · ${d.name}. It is now a playable 3D clip, selectable in Batch Export and the V6.9 timeline.`);
}
function v7RefreshMotionUI(){const d=rigStudio.draft,select=$('rigSavedMotions'),prior=select.value;
 select.replaceChildren();for(const m of rigStudio.motions){const opt=document.createElement('option');opt.value=m.name;opt.textContent=`${m.name} (${m.keys.length} keys)`;select.append(opt)}
 if(rigStudio.motions.some(m=>m.name===prior))select.value=prior;
 $('rigEditMotion').disabled=!rigStudio.motions.length;$('rigDeleteMotion').disabled=!rigStudio.motions.length;
 $('rigMotionTime').disabled=!d;$('rigKeyCapture').disabled=!d;$('rigMotionPublish').disabled=!d;
 if(d){$('rigMotionName').value=d.name;$('rigMotionDuration').value=String(d.duration);$('rigMotionTime').max=String(d.duration);
  $('rigKeySummary').textContent=d.keys.map(k=>k.at.toFixed(2)+'s').join(' · ')||'No keyframes';
 }else {$('rigKeySummary').textContent='Create a motion to start.'}
}
function v7RefreshUI(){v7RefreshBoneSelect();v7RefreshPoseList();v7RefreshMotionUI();
 const enabled=!!rigStudio.bones.length;for(const id of ['rigPoseMode','rigDragAxis','rigPoseName','rigPoseSave','rigPoseMirror','rigMotionName','rigMotionDuration','rigMotionNew','rigNudgeMinus','rigNudgePlus'])$(id).disabled=!enabled;
 $('rigPoseMode').checked=rigStudio.enabled;
}
function v7ExportBackup(){const data={schema:'coremotion-rig-studio-v1',studio:'Core Motion V7.0',character:state.calibrationKey,
  poses:rigStudio.poses,motions:rigStudio.motions,draft:rigStudio.draft,
  note:'Saved pose and quaternion-keyframe recipes for the current named rig. This is not a GLB file.'};
 download(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),'CoreMotion_Rig_Studio_Backup.json');v7Msg('Downloaded pose and animation recipe backup.');
}
function v7Init(){
 $('rigPoseMode').addEventListener('change',e=>v7SetMode(e.target.checked));
 $('rigBoneSelect').addEventListener('change',e=>{rigStudio.selected=e.target.value;v7UpdateMarkers();v7UpdateRotationInfo()});
 $('rigNudgeMinus').addEventListener('click',()=>v7Nudge(-5));$('rigNudgePlus').addEventListener('click',()=>v7Nudge(5));
 $('rigPoseSave').addEventListener('click',v7SavePose);$('rigPoseLoad').addEventListener('click',v7LoadPose);
 $('rigPoseMirror').addEventListener('click',v7MirrorPose);
 $('rigPoseDelete').addEventListener('click',()=>{rigStudio.poses=rigStudio.poses.filter(p=>p.name!==$('rigPoseSelect').value);v7Save();v7RefreshPoseList();v7Msg('Pose removed from library.')});
 $('rigRestPose').addEventListener('click',()=>{v7StopPreview();v7ApplyPose(v7RestPose());v7Msg('Rest pose restored in preview.')});
 $('rigLayerEnable').addEventListener('change',e=>{rigStudio.layerEnabled=e.target.checked;v7Save()});
 $('rigLayerPose').addEventListener('change',e=>{rigStudio.layerPose=e.target.value;v7Save()});
 $('rigLayerStrength').addEventListener('input',e=>{rigStudio.layerStrength=wsClamp(e.target.value,0,100)/100;$('rigLayerStrengthValue').textContent=Math.round(rigStudio.layerStrength*100)+'%';v7Save()});
 $('rigMotionNew').addEventListener('click',v7DraftNew);$('rigKeyCapture').addEventListener('click',v7CaptureKey);$('rigMotionPublish').addEventListener('click',v7SaveMotion);
 $('rigMotionTime').addEventListener('input',e=>{v7DraftSample(e.target.value);$('rigTimeValue').textContent=Number(e.target.value).toFixed(2)+'s'});
 $('rigEditMotion').addEventListener('click',()=>{const src=rigStudio.motions.find(m=>m.name===$('rigSavedMotions').value);if(!src)return;
  rigStudio.draft=structuredClone(src);v7StopPreview();v7RefreshMotionUI();$('rigMotionTime').value='0';v7DraftSample(0);v7Save();v7Msg('Editing saved motion '+src.name+'. Save changes to publish the new version.');
 });
 $('rigDeleteMotion').addEventListener('click',()=>{const name=$('rigSavedMotions').value;if(!name)return;
  v7RemoveClipByName('Studio · '+name);rigStudio.motions=rigStudio.motions.filter(m=>m.name!==name);
  if(state.clips.length)chooseClip(state.clips[0]);else{state.selection='idle';state.playing=false}
  if(rigStudio.draft?.name===name)rigStudio.draft=null;v7Save();refreshClipUI();v7RefreshMotionUI();v7Msg('Deleted Studio · '+name+'. Source clips were not touched.');
 });
 $('rigBackup').addEventListener('click',v7ExportBackup);
 v7RefreshUI();
}
v7Init();


// V7.1 production mode: a catalog is a view of ACTUAL clips and engine-listed moves.
// It must never claim an unavailable preset is installed or automatically retargeted.
const v71FavoritesKey='coremotion-v71-motion-favorites';
const v71PreferencesKey='coremotion-v71-advanced';
let v71Favorites=new Set();
try{v71Favorites=new Set(JSON.parse(localStorage.getItem(v71FavoritesKey)||'[]'))}catch{}
function v71GuideMessage(value){const e=$('v71GuideStatus');if(e)e.textContent=value}
function v71MotionCategory(name){
 const s=String(name||'').toLowerCase();
 if(/walk|run|sprint|sneak|crouch|jump|fall|climb|swim|roll|dash|strafe|crawl|turn|fly|hover|slide|locomotion/.test(s))return 'Movement';
 if(/punch|kick|fight|hit|slash|sword|attack|shoot|fire|block|guard|deflect|combo|reload|aim|death|damage|combat|throw/.test(s))return 'Combat';
 if(/idle|wave|dance|talk|cheer|sit|stand|bow|gesture|point|nod|salute|breath|interact/.test(s))return 'Actions';
 return 'Other';
}
function v71MotionSource(){const source=$('v71Source');return source?source.value:'loaded'}
function v71CatalogData(){
 const loaded=state.clips.map((clip,i)=>({key:'clip:'+clip.name,label:clip.name,source:'loaded',index:i,seconds:Number(clip.duration)||0,category:v71MotionCategory(clip.name)}));
 const moves=(typeof furnace!=='undefined'&&furnace.online?furnace.moves:[]).map(move=>({key:'ai:'+move.id,label:move.label||move.id,source:'engine',move:move.id,category:v71MotionCategory(move.label+' '+move.id)}));
 const library=v72Library.packs.flatMap(pack=>pack.clips.map((clip,i)=>({
  key:'library:'+pack.id+':'+i,label:clip.name,source:'library',packId:pack.id,clipIndex:i,
  packName:pack.name,seconds:clip.seconds,category:v71MotionCategory(clip.name)
 })));
 return loaded.concat(library,moves);
}
function v71RefreshCatalog(){
 const list=$('v71Motions');if(!list)return;
 const query=($('v71Search')?.value||'').trim().toLowerCase();const category=$('v71Category')?.value||'all';const source=v71MotionSource();const packFilter=$('v711PackFilter')?.value||'all';
 let entries=v71CatalogData().filter(m=>(source==='all'||source===m.source||(source==='favorites'&&v71Favorites.has(m.key)))&&(category==='all'||m.category===category)&&(packFilter==='all'||(m.source==='library'&&m.packId===packFilter))&&(!query||m.label.toLowerCase().includes(query)||m.category.toLowerCase().includes(query)||(m.packName||'').toLowerCase().includes(query)));
 entries.sort((a,b)=>Number(v71Favorites.has(b.key))-Number(v71Favorites.has(a.key))||a.label.localeCompare(b.label));
 $('v71MotionCount').textContent=entries.length+' shown';list.replaceChildren();
 if(!entries.length){
  const el=document.createElement('div');el.className='v71Empty';
  el.textContent=source==='loaded'?'No matching animation clips on this character. Choose a motion from Your motion packs or AssetFurnace.':source==='engine'?'No engine moves to display. Start AssetFurnace and click Check to load its real presets.':source==='library'?'No saved motion packs yet. Import GLB/FBX files or ZIP animation packs.':'No motions match this search and category.';
  list.append(el);return;
 }
 for(const m of entries.slice(0,v711VisibleLimit)){
  const wrap=document.createElement('div');wrap.className='v71Motion'+(m.source==='loaded'&&state.selection==='clip::'+m.label?' v71Active':'');
  const desc=document.createElement('div');desc.style.minWidth='0';
  const name=document.createElement('div');name.className='v71MotionName';name.title=m.label;name.textContent=m.label;
  const meta=document.createElement('div');meta.className='v71MotionMeta';meta.textContent=m.category+' · '+(m.source==='loaded'?('On character · '+m.seconds.toFixed(1)+'s'):m.source==='library'?('Saved pack: '+m.packName+' · '+m.seconds.toFixed(1)+'s'):'AssetFurnace preset · generate locally');desc.append(name,meta);
  const actions=document.createElement('div');actions.className='v71Actions';
  const favorite=document.createElement('button');favorite.type='button';favorite.className='fav'+(v71Favorites.has(m.key)?' on':'');favorite.textContent=v71Favorites.has(m.key)?'★':'☆';favorite.title='Favorite motion';favorite.setAttribute('aria-label',(v71Favorites.has(m.key)?'Remove favorite ':'Favorite ')+m.label);
  favorite.addEventListener('click',()=>{if(v71Favorites.has(m.key))v71Favorites.delete(m.key);else v71Favorites.add(m.key);try{localStorage.setItem(v71FavoritesKey,JSON.stringify([...v71Favorites]))}catch{}v71RefreshCatalog()});
  const go=document.createElement('button');go.type='button';go.className='primary';go.textContent=m.source==='loaded'?'▶ Preview':m.source==='library'?'＋ Use & preview':'Select AI move';
  go.addEventListener('click',()=>{
   if(m.source==='loaded'){
    if(state.clips[m.index])chooseClip(state.clips[m.index]);
   }else if(m.source==='library'){
    v72Attach(m.packId,m.clipIndex);
   }else{
    const pick=$('furnaceMove');if(!pick||![...pick.options].some(x=>x.value===m.move)){v71GuideMessage('This move is no longer available from the AI engine. Click Check to refresh.');return}
    pick.value=m.move;v71GuideMessage('Selected '+m.label+'. Choose a rigged character in the local AI library, then click Generate selected move.');
    $('v5Panel')?.scrollIntoView({block:'start',behavior:'smooth'});
   }
  });
  actions.append(favorite,go);wrap.append(desc,actions);list.append(wrap);
 }
 if(entries.length>v711VisibleLimit){const more=document.createElement('button');more.type='button';more.className='wide';more.textContent=`Show more (${Math.min(100,entries.length-v711VisibleLimit)} of ${entries.length-v711VisibleLimit} remaining)`;more.addEventListener('click',()=>{v711VisibleLimit+=100;v71RefreshCatalog()});list.append(more)}
}
function v71Advanced(enabled){
 $('coreShell').classList.toggle('guided',!enabled);
 $('v71ModeSwitch').textContent=enabled?'✓ Advanced tools · return to simple':'⚙ Advanced tools';
 $('v71ModeSwitch').setAttribute('aria-pressed',String(enabled));
 if(!enabled){
  const pose=$('rigPoseMode');if(pose?.checked){pose.checked=false;v7SetMode(false)}
  const skeleton=$('bonesToggle');if(skeleton?.checked){skeleton.checked=false;showBones(false)}
  $('rigStudioPanel')?.querySelector('details')?.removeAttribute('open');
 }
 try{localStorage.setItem(v71PreferencesKey,enabled?'1':'0')}catch{}
 v71GuideMessage(enabled?'Advanced rigging and timeline controls are visible. Switch back to Simple mode for the five-step workflow.':'Simple mode: upload, generate, choose style, select a real animation, export. Manual rigging is hidden.');
}
function v71Jump(id){const el=$(id);if(el)el.scrollIntoView({behavior:'smooth',block:'start'})}
function v71Init(){
 let advanced=false;try{advanced=localStorage.getItem(v71PreferencesKey)==='1'}catch{}
 v71Advanced(advanced);
 $('v71ModeSwitch').addEventListener('click',()=>v71Advanced($('coreShell').classList.contains('guided')));
 for(const b of document.querySelectorAll('[data-quick]'))b.addEventListener('click',()=>{
  const step=b.dataset.quick;
  if(step==='upload'){v71Jump('imageDrop');$('imageInput').click()}
  else if(step==='generate'){
   v71Jump('v5Panel');if(!state.file)v71GuideMessage('Upload a character image first; then use Generate from uploaded image in the local AI panel.');
   else if(!furnace.online)v71GuideMessage('Start the local AI engine, then click Generate from uploaded image.');
   else v71GuideMessage('Choose Generate through: 3D → Finish → Rig → Animate, then click Generate from uploaded image.');
  }
  else if(step==='styles')v71Jump('v71StylesSection');
  else if(step==='motions'){v71Jump('v71AnimationsSection');$('v71Search').focus({preventScroll:true})}
  else if(step==='export')v71Jump('v71ExportSection');
 });
 for(const id of ['v71Search','v71Source','v71Category'])$(id).addEventListener(id==='v71Search'?'input':'change',v71RefreshCatalog);
 $('v71ImportMotion').addEventListener('click',()=>{
  $('v72MotionPacks').open=true; $('v72Files').click();
 });
 // Prefer real, available motions; keep the original 18 shortcut buttons under Advanced mode.
 v71RefreshCatalog();
}
// Initialization moved below the V7.2 library declarations.

// V7.2: reusable local motion-pack library (GLB / FBX / ZIP of GLB/FBX).
// Every catalog entry represents a real clip parsed from user-provided bytes.
// Auto-retargeting is conservative: unrecognized skeletons are declined, never faked.
const V72_DB='coremotion-motion-library-v1';
const v72Library={db:null,packs:[],busy:false,targetRest:new Map(),lastReport:[]};
function v72Status(msg,error=false){const node=$('v72Status');if(node){node.textContent=msg;node.classList.toggle('error',!!error)}}
function v72Friendly(name){return String(name||'motion').split(/[\\/]/).pop().replace(/[^\w.() \-]/g,'_').slice(0,100)}
function v72ReadableBytes(n){return n>=1048576?(n/1048576).toFixed(1)+' MB':Math.ceil(n/1024)+' KB'}
function v72OpenDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open(V72_DB,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains('motions'))r.result.createObjectStore('motions',{keyPath:'id'})};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error||new Error('IndexedDB unavailable'))})}
function v72Transaction(mode,fn){return new Promise((resolve,reject)=>{
 if(!v72Library.db){reject(new Error('Browser storage unavailable'));return}
 const tx=v72Library.db.transaction('motions',mode),store=tx.objectStore('motions');let result;
 tx.oncomplete=()=>resolve(result);tx.onerror=()=>reject(tx.error||new Error('Motion library transaction failed'));tx.onabort=()=>reject(tx.error||new Error('Motion library transaction aborted'));
 try{result=fn(store)}catch(e){tx.abort();reject(e)}
})}
function v72GetAll(){return new Promise((resolve,reject)=>{if(!v72Library.db)return resolve([]);const r=v72Library.db.transaction('motions','readonly').objectStore('motions').getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error)})}
function v72GetRecord(id){return new Promise((resolve,reject)=>{if(!v72Library.db)return reject(new Error('Motion library is unavailable'));const r=v72Library.db.transaction('motions','readonly').objectStore('motions').get(id);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function v72Digest(buf){const a=await crypto.subtle.digest('SHA-256',buf);return Array.from(new Uint8Array(a)).map(n=>n.toString(16).padStart(2,'0')).join('')}
function v72Ext(name){return (/\.(glb|fbx|zip)$/i.exec(name)||[])[1]?.toLowerCase()||''}
async function v72ParseMotion(name,bytes){
 const ext=v72Ext(name);let obj;
 if(ext==='glb'){
  obj=await new Promise((resolve,reject)=>gltfLoader.parse(bytes.slice(0),'',resolve,reject));
  // KinemIQ's standalone animation GLBs contain an animated joint hierarchy,
  // but no skin/mesh, so GLTFLoader instantiates Object3D nodes instead of Bones.
  // A skeleton retarget requires actual Bone instances. Rebuild an equivalent
  // motion-only hierarchy, retaining each joint's name, local rest transform,
  // parents and source animation tracks. This never alters the imported bytes.
  if(!v72BoneNodes(obj.scene).length && obj.animations?.length){
   const trackTargets=new Set(obj.animations.flatMap(c=>c.tracks.map(t=>v72TrackInfo(t.name)?.node).filter(Boolean)));
   let matches=0;obj.scene.traverse(n=>{if(n.name&&trackTargets.has(n.name))matches++});
   if(matches>=9){
    const skeleton=new THREE.Group();skeleton.name='Animation-only GLB skeleton';
    // A single clone per node is required (do not reuse source Object3D parents).
    const cloneTree=(n)=>{const out=n.name?new THREE.Bone():new THREE.Group();
     out.name=n.name;out.position.copy(n.position);out.quaternion.copy(n.quaternion);out.scale.copy(n.scale);
     n.children.forEach(c=>out.add(cloneTree(c)));return out;};
    obj.scene.children.forEach(c=>skeleton.add(cloneTree(c)));
    skeleton.updateMatrixWorld(true);
    return {root:skeleton,animations:obj.animations||[],motionOnly:true};
   }
  }
  return {root:obj.scene,animations:obj.animations||[]};
 }
 if(ext==='fbx'){
  const loader=new FBXLoader();const root=loader.parse(bytes.slice(0),'');
  return {root,animations:root.animations||[]};
 }
 throw new Error('Only .glb and .fbx motion files can be imported.');
}
function v72Describe(clip){return {name:String(clip.name||'Animation').slice(0,100),seconds:Math.round(clip.duration*1000)/1000,tracks:clip.tracks.length}}
// Minimal local ZIP reader: reads the central directory; supports Store or DEFLATE.
// Rejects encryption, zip64, oversized entries and unexpectedly large expansions.
async function v72ExtractZip(buffer){
 const u=new Uint8Array(buffer),dv=new DataView(buffer);let eocd=-1;
 for(let p=u.length-22;p>=Math.max(0,u.length-65557);p--){if(dv.getUint32(p,true)===0x06054b50){eocd=p;break}}
 if(eocd<0)throw new Error('Not a supported ZIP archive.');
 const count=dv.getUint16(eocd+10,true),offset=dv.getUint32(eocd+16,true),size=dv.getUint32(eocd+12,true);
 if(count>160||count===0xffff||offset===0xffffffff||offset+size>u.length)throw new Error('Too many entries or ZIP64 archive; use a smaller pack.');
 let p=offset,total=0;const files=[];
 for(let i=0;i<count;i++){
  if(p+46>u.length||dv.getUint32(p,true)!==0x02014b50)throw new Error('Invalid ZIP central directory.');
  const flags=dv.getUint16(p+8,true),method=dv.getUint16(p+10,true),compressed=dv.getUint32(p+20,true),uncompressed=dv.getUint32(p+24,true);
  const n=dv.getUint16(p+28,true),ex=dv.getUint16(p+30,true),co=dv.getUint16(p+32,true),loc=dv.getUint32(p+42,true);
  if(p+46+n+ex+co>u.length)throw new Error('Truncated ZIP entry.');
  const filename=new TextDecoder().decode(u.subarray(p+46,p+46+n));p+=46+n+ex+co;
  if(!/\.(glb|fbx)$/i.test(filename)||filename.startsWith('__MACOSX/'))continue;
  if(flags&1||![0,8].includes(method))throw new Error('Encrypted or unsupported ZIP entry: '+v72Friendly(filename));
  if(uncompressed>44*1024*1024||compressed>44*1024*1024)throw new Error('Motion file is too large: '+v72Friendly(filename));
  total+=uncompressed;if(total>240*1024*1024)throw new Error('Pack expands beyond the 240 MB safety limit.');
  if(loc+30>u.length||dv.getUint32(loc,true)!==0x04034b50)throw new Error('ZIP entry data missing.');
  const start=loc+30+dv.getUint16(loc+26,true)+dv.getUint16(loc+28,true);
  if(start+compressed>u.length)throw new Error('Truncated motion file in ZIP.');
  let data;
  if(method===0)data=u.slice(start,start+compressed);
  else{
   const stream=new Blob([u.slice(start,start+compressed)]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
   const decompressed=await new Response(stream).arrayBuffer();data=new Uint8Array(decompressed);
  }
  if(data.length!==uncompressed)throw new Error('Unexpected ZIP entry size for '+v72Friendly(filename));
  files.push({name:v72Friendly(filename),bytes:data.buffer});
 }
 if(!files.length)throw new Error('The ZIP contains no GLB or FBX motion files.');
 // Identical KayKit animation collections in FBX and GLB should not be installed twice.
 const glbKeys=new Set(files.filter(f=>v72Ext(f.name)==='glb').map(f=>f.name.replace(/\.(?:glb|fbx)$/i,'').toLowerCase()));
 return files.filter(f=>v72Ext(f.name)!=='fbx'||!glbKeys.has(f.name.replace(/\.(?:glb|fbx)$/i,'').toLowerCase()));
}
async function v72ImportFiles(files){
 if(v72Library.busy)return;
 const picked=Array.from(files||[]);if(!picked.length)return;
 if(!v72Library.db){v72Status('Browser storage must be available to save imported packs.',true);return}
 if(picked.length>75){v72Status('Import up to 75 files at a time.',true);return}
 v72Library.busy=true;$('v72ImportBtn').disabled=true;
 let imported=0,clips=0,duplicates=0;const errors=[];
 try{
  for(const file of picked){
   if(file.size>120*1024*1024){errors.push(v72Friendly(file.name)+': file exceeds 120 MB');continue}
   let inputs=[];
   try{
    const binary=await file.arrayBuffer();inputs=v72Ext(file.name)==='zip'?await v72ExtractZip(binary):[{name:v72Friendly(file.name),bytes:binary}];
    if(!inputs.length)throw new Error('No motion files found');
   }catch(e){errors.push(v72Friendly(file.name)+': '+e.message);continue}
   for(const item of inputs){
    try{
     if(!['glb','fbx'].includes(v72Ext(item.name)))throw new Error('GLB and FBX only');
     if(item.bytes.byteLength>44*1024*1024)throw new Error('Motion file exceeds 44 MB');
     const id=await v72Digest(item.bytes);
     if(v72Library.packs.some(p=>p.id===id)){duplicates++;continue}
     v72Status('Reading '+item.name+'…');
     const parsed=await v72ParseMotion(item.name,item.bytes);
     const descriptions=(parsed.animations||[]).filter(c=>c&&c.tracks?.length&&c.duration>0).map(v72Describe);
     if(!descriptions.length)throw new Error('No playable animation tracks found');
     const record={id,name:v72Friendly(item.name),sourceGroup:v72Friendly(file.name),format:v72Ext(item.name),added:new Date().toISOString(),clips:descriptions,bytes:item.bytes};
     await v72Transaction('readwrite',store=>store.put(record));
     v72Library.packs.push({id,name:record.name,sourceGroup:record.sourceGroup,format:record.format,added:record.added,clips:record.clips,size:record.bytes.byteLength});
     imported++;clips+=descriptions.length;
    }catch(e){errors.push(item.name+': '+e.message)}
   }
  }
 }finally{
  v72Library.busy=false;$('v72ImportBtn').disabled=false;$('v72Files').value='';
  if(imported){$('v71Source').value='library';$('v71Category').value='all';$('v71Search').value='';}
  v72RenderPacks();v71RefreshCatalog();
 }
 v72Library.lastReport=errors;
 v72Status(`Imported ${imported} motion file(s) containing ${clips} real clips. ${duplicates} already present.${errors.length?' '+errors.length+' skipped; see import report.':''}`,!!errors.length);
 $('v72Errors').textContent=errors.length?errors.slice(0,20).join('\n'):'No import errors.';
}
function v72Canon(input){
 // V7.6: accept common humanoid naming systems (Mixamo, Blender .L/.R,
 // Unreal, biped suffixes). Never guess arbitrary finger or IK controls.
 let raw=String(input||'').replace(/^.*[\\/|:]/,'').trim();
 raw=raw.replace(/\.\d{3}$/,'').replace(/^(?:mixamorig\d*|bip\d*|j[_-]?bip|def[_-]|org[_-]|mch[_-])[_\s-]*/i,'');
 // Common VRM/Unity names: J_Bip_C_Hips, J_Bip_L_UpperArm, etc.
 raw=raw.replace(/^armature[_-]/i,'');
 raw=raw.replace(/^([CLR])[_-](?=[A-Za-z])/i,(match,side)=>side==='L'?'Left_':side==='R'?'Right_':'');
 let side='';
 let m=raw.match(/(?:[._\s-](left|right|l|r))$/i);
 if(m){side=/^(l|left)$/i.test(m[1])?'left':'right';raw=raw.slice(0,m.index)}
 else if((m=raw.match(/([a-z])([LR])$/))){side=m[2]==='L'?'left':'right';raw=raw.slice(0,-1)}
 else if((m=raw.match(/^(left|right)[._\s-]*/i))){side=m[1].toLowerCase();raw=raw.slice(m[0].length)}
 else if((m=raw.match(/^([LR])[_\s-](?=[a-z])/i))){side=m[1].toLowerCase()==='l'?'left':'right';raw=raw.slice(m[0].length)}
 else if((m=raw.match(/^([LR])(?=upper|lower|fore|hand|foot|arm|leg|thigh|calf|shin|toe|clavicle|shoulder)/i))){side=m[1].toLowerCase()==='l'?'left':'right';raw=raw.slice(1)}
 // V7.19: Three.js GLTFLoader may sanitize KayKit's 'upperarm.r' to
 // 'upperarmr' (no separator). Only strip an unseparated lowercase l/r
 // suffix when the preceding name is a known anatomical joint. Doing so
 // avoids mistaking names like 'shoulder', 'collar', or 'finger' for sides.
 if(!side && (m=raw.match(/^(upperarm|lowerarm|upperleg|lowerleg|foot|toes|wrist|hand|handslot|thigh|calf|shin|forearm|toe|clavicle|shoulder)([lr])$/i))){
  side=m[2].toLowerCase()==='l'?'left':'right';raw=m[1];
 }
 const p=raw.replace(/[^a-z0-9]/gi,'').toLowerCase().replace(/^bip\d*/,'');
 if(/^(hips?|pelvis|rootbone|root|cog|hipbone)$/.test(p))return 'hips';
 if(/^(spine|spine0|spine1|spine01|lowerback|lowerbody)$/.test(p))return 'spine1';
 if(/^(spine2|spine02|chest|upperchest|thorax|upperbody|chest1)$/.test(p))return 'spine2';
 if(/^(spine3|spine03|spine4|spine04)$/.test(p))return 'spine3';
 if(/^(neck|neck0?1)$/.test(p))return 'neck';
 if(/^(head|head1)$/.test(p))return 'head';
 if(!side)return p;
 if(/^(shoulder|clavicle|collar)$/.test(p))return side+'shoulder';
 if(/^(upperarm|arm|uparm|armupper)$/.test(p))return side+'upperarm';
 if(/^(forearm|lowerarm|loarm|elbow|armlower)$/.test(p))return side+'forearm';
 if(/^(hand|wrist|palm)$/.test(p))return side+'hand';
 if(/^(upleg|upperleg|thigh|hip|legupper|upperlegbone)$/.test(p))return side+'thigh';
 if(/^(leg|lowerleg|calf|shin|knee|leglower)$/.test(p))return side+'shin';
 if(/^(foot|ankle)$/.test(p))return side+'foot';
 if(/^(toe|toebase|toes|ball)$/.test(p))return side+'toe';
 return side+p;
}
function v72BoneNodes(root){const bones=[];root?.traverse(obj=>{if(obj.isBone&&obj.name)bones.push(obj)});return bones}
function v72TargetRest(){
 v72Library.targetRest.clear();
 // Called once at model load before animation playback. These rest-world quaternions
 // let a source motion rotate the same anatomical joint even when bone axes differ.
 state.model?.updateMatrixWorld(true);
 for(const b of v7AllBones())v72Library.targetRest.set(b.name,{
  quaternion:rigStudio.rest.get(b.name)?.clone()||b.quaternion.clone(),
  position:b.position.clone(), worldQuaternion:b.getWorldQuaternion(new THREE.Quaternion()), worldPosition:b.getWorldPosition(new THREE.Vector3())
 });
}
function v72FindBone(bones,src,consumed){
 const simple=s=>String(s||'').replace(/^.*[:|]/,'').replace(/[^a-z0-9]/gi,'').toLowerCase();
 const label=src.name,exact=bones.find(b=>!consumed.has(b.name)&&b.name===label);
 if(exact)return {bone:exact,match:'exact'};
 const clean=simple(label),same=bones.filter(b=>!consumed.has(b.name)&&simple(b.name)===clean);
 if(same.length===1)return {bone:same[0],match:'normalized'};
 const key=v72Canon(label),equivalent=bones.filter(b=>!consumed.has(b.name)&&v72Canon(b.name)===key);
 if(key&&equivalent.length===1)return {bone:equivalent[0],match:'humanoid'};
 return null;
}
function v72SourceBoneForTrack(bones,node){
 const clean=s=>String(s||'').replace(/^.*[:|]/,'').replace(/[^a-z0-9]/gi,'').toLowerCase();
 const direct=bones.find(b=>b.name===node);if(direct)return direct;
 const normal=bones.filter(b=>clean(b.name)===clean(node));if(normal.length===1)return normal[0];
 const semantic=bones.filter(b=>v72Canon(b.name)===v72Canon(node));return semantic.length===1?semantic[0]:null;
}
function v72TrackInfo(name){
 const dot=name.lastIndexOf('.');if(dot<0)return null;
 let node=name.slice(0,dot),property=name.slice(dot+1);
 if(!['quaternion','position','scale'].includes(property))return null;
 const bracket=/\.bones\[([^\]]+)\]$/.exec(node);
 if(bracket)node=bracket[1];else node=node.replace(/^.*\//,'');
 return {node,property};
}
function v72UniqueClipName(name){
 const base=String(name||'Motion').replace(/[\r\n\t]/g,' ').slice(0,110);
 if(!state.clips.some(c=>c.name===base))return base;
 let i=2;while(state.clips.some(c=>c.name===base+' '+i))i++;
 return base+' '+i;
}
// Quaternion mapping in local bone space: convert the motion relative to the
// source rest pose into motion relative to the target rest pose. This is useful
// for compatible humanoids, but different bone coordinate frames may need a
// dedicated retargeter, so warn for large offsets and never claim universal support.
function v72Retarget(clip,sourceRoot){
 const sb=v72BoneNodes(sourceRoot),tb=v7AllBones();if(!tb.length)throw new Error('Load a rigged humanoid character first.');
 if(!sb.length)throw new Error('This motion has no source skeleton; safe automatic retargeting requires bone rest poses.');
 const auto=v74CurrentAutoMap();
 sourceRoot.updateMatrixWorld(true);
 const sourceGeneric=sb.length>0 && sb.every(b=>/^bone_\d+$/.test(b.name));
 const sourceAuto=sourceGeneric?v74InferGeneric(sb,false):null;
 if(sourceGeneric&&!sourceAuto)throw new Error('The imported file has a generic skeleton whose anatomy cannot be identified safely. Try a named humanoid motion pack.');
 const sourceLabels=new Map();
 if(sourceAuto)for(const [semantic,bone] of sourceAuto.named)sourceLabels.set(bone.name,semantic);
 const used=new Set(),mapped=new Map(),matchTypes={exact:0,normalized:0,humanoid:0,generated:0};
 for(const s of sb){
  let found=null;
  if(sourceAuto){
   // Never match bone_20 to bone_20 across differently numbered skeletons:
   // it can be a finger in one character and a thigh in another.
   const semantic=sourceLabels.get(s.name);
   if(semantic){
    const candidate=auto?.named.get(semantic)||tb.find(b=>v72Canon(b.name)===semantic);
    if(candidate&&!used.has(candidate.name))found={bone:candidate,match:'generated'};
   }
  }else{
   found=v72FindBone(tb,s,used);
   if(!found&&auto){const candidate=auto.named.get(v72Canon(s.name));
    if(candidate&&!used.has(candidate.name))found={bone:candidate,match:'generated'};
   }
  }
  if(found){mapped.set(s.name,found.bone);used.add(found.bone.name);matchTypes[found.match]++}
 }
 const tracks=[],unmatched=new Set(),animated=new Set(),coreAnimated=new Set(),coreMissing=new Set();let offsetWarnings=0,positionSkipped=0;
 for(const track of clip.tracks){
  const info=v72TrackInfo(track.name);if(!info)continue;
  const sourceBone=v72SourceBoneForTrack(sb,info.node),targetBone=sourceBone?mapped.get(sourceBone.name):null;
  const sourceSemantic=sourceBone?(sourceLabels.get(sourceBone.name)||v72Canon(sourceBone.name)):v72Canon(info.node);
  if(!sourceBone||!targetBone){unmatched.add(info.node);if(v74CoreBone(sourceSemantic))coreMissing.add(sourceSemantic);continue}
  const copy=track.clone();copy.name=targetBone.name+'.'+info.property;
  const restTarget=v72Library.targetRest.get(targetBone.name);
  if(info.property==='quaternion'){
   if(!restTarget||!(track.values.length>=4))continue;
   const qs=sourceBone.quaternion.clone().normalize(),qt=restTarget.quaternion.clone().normalize(),inverse=qs.clone().invert();
   if(qs.angleTo(qt)>Math.PI/3)offsetWarnings++;
   // Generated rigs often use rotated local joint axes. Convert the source
   // movement through the rest-world basis instead of blindly copying angles.
   const basis=auto && restTarget.worldQuaternion
    ? restTarget.worldQuaternion.clone().invert().multiply(sourceBone.getWorldQuaternion(new THREE.Quaternion())) : null;
   for(let i=0;i<copy.values.length;i+=4){
    const q=new THREE.Quaternion().fromArray(copy.values,i).normalize();
    if(basis){
     const delta=inverse.clone().multiply(q);
     const aligned=basis.clone().multiply(delta).multiply(basis.clone().invert());
     qt.clone().multiply(aligned).normalize().toArray(copy.values,i);
    }else{q.premultiply(inverse).premultiply(qt).normalize().toArray(copy.values,i)}
   }
  }else if(info.property==='position'){
   // Apply source translation *deltas* about the target's saved rest position.
   // Root X/Z travel is suppressed for in-place game sprite export.
   if(!restTarget)continue;
   const s=sourceBone.position,t=restTarget.position;
   for(let i=0;i<copy.values.length;i+=3){
    const x=copy.values[i]-s.x,y=copy.values[i+1]-s.y,z=copy.values[i+2]-s.z;
    copy.values[i]=t.x+(sourceSemantic==='hips'?0:x);
    copy.values[i+1]=t.y+y;
    copy.values[i+2]=t.z+(sourceSemantic==='hips'?0:z);
   }
  }else{positionSkipped++;continue}
  tracks.push(copy);animated.add(info.node);
  if(v74CoreBone(sourceSemantic))coreAnimated.add(sourceSemantic);
 }
 // Fingers and extra face bones vary dramatically across generated rigs.
 // Require reliable coverage of the animated *body* instead of rejecting an
 // otherwise valid walk merely because the source has more finger joints.
 const total=animated.size+unmatched.size;
 const coreExpected=new Set(['hips','spine1','spine2','leftupperarm','rightupperarm','leftthigh','rightthigh','leftshin','rightshin']);
 const coreTotal=new Set([...coreExpected,...coreAnimated,...coreMissing]).size;
 const coverage=coreTotal?coreAnimated.size/coreTotal:0;
 if(tracks.length===0||animated.size<1||coverage<.70 || (coreTotal>=3&&coreAnimated.size<3))
  throw new Error(`Incompatible skeleton: ${animated.size}/${total} joints mapped; ${Math.round(coverage*100)}% of animated body joints matched. Select another motion or use a rigged humanoid model.`);
 const result=new THREE.AnimationClip(v72UniqueClipName(clip.name),clip.duration,tracks);
 const names=Object.fromEntries([...mapped.entries()].map(([sourceName,targetBone])=>[targetBone.name,sourceName]));
 const sourceHip=sourceAuto?.named.get('hips')?.name || sb.find(b=>v72Canon(b.name)==='hips')?.name || '';
 return {clip:result,report:{mapped:animated.size,total,coverage,offsetWarnings,positionSkipped,types:matchTypes,generic:!!auto,names,sourceHip,unmatched:[...unmatched].slice(0,120)}};
}
// V7.15: Reference-based KinemIQ retargeting.
// Standalone KinemIQ animation GLBs store their FIRST ANIMATED FRAME as node
// defaults. That is NOT the neutral skeleton pose; treating it as bind-rest
// erased the initial full-body movement and left characters near a T-pose.
// KinemIQ supplies KinemIQ_Mannequin.glb in its CC0 ZIP. Resolve the actual
// bind pose from its skin inverse-bind matrices, without modifying the pack.
const v715References=new Map();
async function v715KinemIQReference(pack){
 const group=String(pack.sourceGroup||'').toLowerCase();
 const kinemiq=/kinemiq/i.test(group)||v72Library.packs.some(p=>
  /kinemiq_mannequin\.glb$/i.test(p.name)&&p.sourceGroup===pack.sourceGroup);
 if(!kinemiq)return null; // Other formats retain their proven v7.14 behavior.
 const mannequin=v72Library.packs.find(p=>/kinemiq_mannequin\.glb$/i.test(p.name)&&
  (!group||String(p.sourceGroup||'').toLowerCase()===group)) ||
  v72Library.packs.find(p=>/kinemiq_mannequin\.glb$/i.test(p.name));
 if(!mannequin)throw new Error('KinemIQ needs its KinemIQ_Mannequin.glb bind-pose reference. Reimport the complete CC0 ZIP; no saved animations need to be deleted.');
 if(v715References.has(mannequin.id))return v715References.get(mannequin.id);
 const saved=await v72GetRecord(mannequin.id);
 if(!saved)throw new Error('KinemIQ mannequin reference is unavailable in the saved library. Reimport the complete ZIP.');
 const reference=await v72ParseMotion(saved.name,saved.bytes);
 let skeleton=null;
 reference.root.traverse(o=>{if(!skeleton&&o.isSkinnedMesh&&o.skeleton?.bones?.length)skeleton=o.skeleton});
 if(!skeleton)throw new Error('KinemIQ mannequin has no readable skin bind matrices.');
 const rest=new Map(),mat=new THREE.Matrix4(),pos=new THREE.Vector3(),q=new THREE.Quaternion(),scale=new THREE.Vector3();
 skeleton.bones.forEach((b,i)=>{
  const inv=skeleton.boneInverses[i];if(!inv||!b.name)return;
  mat.copy(inv).invert().decompose(pos,q,scale);
  rest.set(b.name,{quaternion:q.clone().normalize(),position:pos.clone()});
 });
 for(const joint of ['pelvis','upperarm_l','upperarm_r','thigh_l','thigh_r','calf_l','calf_r'])
  if(!rest.has(joint))throw new Error('KinemIQ bind reference missing essential joint '+joint);
 v715References.set(mannequin.id,rest);
 return rest;
}
// V7.17: KayKit ships multiple clips in rigged GLBs, each with its own
// Medium/Large bind pose. Use the actual skin inverse binds rather than
// inferring rest from an animated/default scene node.
function v717KayKitReference(pack,parsed){
 const tag=(String(pack.sourceGroup||'')+' '+String(pack.name||'')).toLowerCase();
 if(!/kaykit|rig_(?:medium|large)/.test(tag))return null;
 const sourceBones=v72BoneNodes(parsed.root);
 if(!sourceBones.length)throw new Error('KayKit GLB contains no readable humanoid bones. Import the GLB files from Animations/gltf, not a mannequin-only file.');
 let skeleton=null;
 parsed.root.traverse(o=>{if(!skeleton&&o.isSkinnedMesh&&o.skeleton?.bones?.length)skeleton=o.skeleton});
 if(!skeleton)throw new Error('KayKit rig bind matrices are unavailable. Use GLB from Animations/gltf/Rig_Medium or Rig_Large.');
 const rest=new Map(),matrix=new THREE.Matrix4(),position=new THREE.Vector3(),rotation=new THREE.Quaternion(),scale=new THREE.Vector3();
 skeleton.bones.forEach((bone,i)=>{
  const inverse=skeleton.boneInverses[i];if(!inverse||!bone?.name)return;
  matrix.copy(inverse).invert().decompose(position,rotation,scale);
  rest.set(bone.name,{position:position.clone(),quaternion:rotation.clone().normalize()});
 });
 const essentials=['hips','leftupperarm','rightupperarm','leftthigh','rightthigh','leftshin','rightshin','leftfoot','rightfoot'];
 const roles=v77SourceRoles(parsed.root);
 const missing=essentials.filter(role=>!roles.get(role)||!rest.has(roles.get(role).name));
 if(missing.length){
  const skeletonNames=skeleton.bones.map(b=>b.name).slice(0,30).join(', ');
  throw new Error('KayKit GLB rig joint mismatch: '+missing.join(', ')+'. Recognized '+[...roles.keys()].join(', ')+'. Skin joints: '+skeletonNames+'.');
 }
 return rest;
}
// V7.21: KayKit walk correction with character-space calibration.
// KayKit's arm/leg bone *local axes* don't match arbitrary generated characters.
// Applying source local quaternion deltas directly (v7.20) preserves motion
// numerically but may leave the target in a T-pose or move about wrong axes.
// Instead, express the source world-space animated offsets in the target's
// anatomical right/up/forward reference frame and solve target local tracks
// down the actual destination hierarchy. Do not touch non-walk animations.
function v721KayKitWalkingPose(result,source,sourceRoot,bindRest){
 const sourceByRole=v77SourceRoles(sourceRoot);
 const targetByRole=v74CurrentAutoMap()?.named;
 if(!targetByRole)throw new Error('KayKit walking requires a loaded humanoid character.');
 const targetRest=v72Library.targetRest;
 const readPos=(role,sourceSide)=>{
  const bone=(sourceSide?sourceByRole:targetByRole).get(role);
  if(!bone)return null;
  const rest=sourceSide?bindRest.get(bone.name):targetRest.get(bone.name);
  return sourceSide?rest?.position:rest?.worldPosition;
 };
 // Build a proper three-axis frame from the shoulders and trunk, then map
 // orientation differences between animation rig and character. Both bases
 // use the same anatomical handedness: x=left-to-right, y=up, z=forward.
 function basis(isSource){
  const left=readPos('leftupperarm',isSource),right=readPos('rightupperarm',isSource);
  const pelvis=readPos('hips',isSource);
  const top=readPos('head',isSource)||readPos('spine2',isSource)||readPos('spine1',isSource);
  if(!left||!right||!pelvis||!top)throw new Error('KayKit walk: shoulder/torso bind reference is missing.');
  const x=right.clone().sub(left).normalize();
  const up=top.clone().sub(pelvis).normalize();
  const z=new THREE.Vector3().crossVectors(x,up).normalize();
  if(z.lengthSq()<0.4)throw new Error('KayKit walk: cannot resolve character anatomy axis.');
  const y=new THREE.Vector3().crossVectors(z,x).normalize();
  return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(x,y,z)).normalize();
 }
 const c=basis(false).multiply(basis(true).invert()).normalize();
 const ci=c.clone().invert();
 const targetBones=v7AllBones(),matching=new Map();
 for(const [role,dst] of targetByRole){
  const src=sourceByRole.get(role);
  if(src&&bindRest.has(src.name)&&targetRest.has(dst.name))matching.set(dst,src);
 }
 const critical=['leftupperarm','rightupperarm','leftthigh','rightthigh','leftshin','rightshin','leftfoot','rightfoot'];
 const missed=critical.filter(r=>!targetByRole.get(r)||!matching.has(targetByRole.get(r)));
 if(missed.length)throw new Error('KayKit walk: missing target/source joint '+missed.join(', '));
 const ordered=targetBones.slice().sort((x,y)=>{
  const depth=n=>{let i=0;while(n?.parent?.isBone&&i<100){i++;n=n.parent;}return i};
  return depth(x)-depth(y);
 });
 const staticParent=new Map();
 for(const b of targetBones){
  const r=targetRest.get(b.name);
  if(r)staticParent.set(b,r.worldQuaternion.clone().multiply(r.quaternion.clone().invert()));
 }
 const tracks=new Map(result.clip.tracks.map(t=>[t.name,t]));
 const pairs=ordered.filter(b=>matching.has(b)&&tracks.has(b.name+'.quaternion'));
 const samples=Math.min(1200,Math.max(2,Math.round(source.duration*60)+1));
 const times=Array.from({length:samples},(_,i)=>i*source.duration/(samples-1));
 const vals=new Map(pairs.map(b=>[b,[]]));
 const maxDeviation={};
 const snapshots=v75SavePose(sourceRoot);
 const mixer=new THREE.AnimationMixer(sourceRoot),action=mixer.clipAction(source);
 try{
  action.play();
  for(const t of times){
   mixer.setTime(Math.min(t,Math.max(0,source.duration-1e-6)));
   sourceRoot.updateMatrixWorld(true);
   const solved=new Map();
   for(const bone of ordered){
    const rest=targetRest.get(bone.name);if(!rest)continue;
    const parent=bone.parent;
    const parentQ=parent?.isBone&&solved.has(parent)?solved.get(parent):staticParent.get(bone);
    if(!parentQ)continue;
    const src=matching.get(bone);let desired;
    if(src){
     const ref=bindRest.get(src.name).quaternion;
     const live=src.getWorldQuaternion(new THREE.Quaternion());
     const sourceDelta=live.multiply(ref.clone().invert());
     const targetDelta=c.clone().multiply(sourceDelta).multiply(ci);
     desired=targetDelta.multiply(rest.worldQuaternion.clone()).normalize();
    }else desired=parentQ.clone().multiply(rest.quaternion).normalize();
    solved.set(bone,desired);
    if(vals.has(bone)){
     const q=parentQ.clone().invert().multiply(desired).normalize();
     vals.get(bone).push(...q.toArray());
     const degrees=THREE.MathUtils.radToDeg(q.angleTo(rest.quaternion));
     const role=[...targetByRole].find(([r,obj])=>obj===bone)?.[0]||bone.name;
     maxDeviation[role]=Math.max(maxDeviation[role]||0,degrees);
    }
   }
  }
 }finally{
  action.stop();mixer.stopAllAction();mixer.uncacheRoot(sourceRoot);
  v75RestorePose(sourceRoot,snapshots);
 }
 for(const bone of pairs){
  const name=bone.name+'.quaternion',old=tracks.get(name);
  const updated=new THREE.QuaternionKeyframeTrack(name,times,vals.get(bone));
  result.clip.tracks[result.clip.tracks.indexOf(old)]=updated;
 }
 result.clip.optimize();
 const armed=Math.max(maxDeviation.leftupperarm||0,maxDeviation.rightupperarm||0);
 const legs=Math.max(maxDeviation.leftthigh||0,maxDeviation.rightthigh||0);
 result.report.kaykitWalkPoseCorrection={method:'anatomy-calibrated-world-v2',
  joints:pairs.length,armDeviationDegrees:Math.round(armed),legDeviationDegrees:Math.round(legs),
  maxDeviationDegrees:Object.fromEntries(Object.entries(maxDeviation).map(([r,d])=>[r,Math.round(d)]))};
 if(pairs.length<8||armed<10||legs<10)
  throw new Error('KayKit gait still collapsed toward a neutral pose (arms '+Math.round(armed)+'°, legs '+Math.round(legs)+'°). Download the compatibility report; attachment canceled.');
}

// V7.18: KayKit ZIPs have parallel FBX and GLB copies of the same action.
// Older imports retained both; prefer the corresponding GLB because its
// inverse-bind skeleton can be read without FBX's importer-specific transforms.
function v718KaykitGlbTwin(pack,clipIndex){
 if(!pack||pack.format!=='fbx'||!/kaykit|rig_(medium|large)/i.test(String(pack.sourceGroup||'')+' '+pack.name))return null;
 const baseName=pack.name.replace(/\.(?:fbx|glb)$/i,'').toLowerCase();
 const wanted=pack.clips?.[clipIndex]?.name;
 for(const alt of v72Library.packs){
  if(alt.id===pack.id||alt.format!=='glb'||alt.name.replace(/\.(?:fbx|glb)$/i,'').toLowerCase()!==baseName)continue;
  if(pack.sourceGroup&&alt.sourceGroup&&pack.sourceGroup!==alt.sourceGroup)continue;
  const i=alt.clips.findIndex(c=>c.name===wanted);
  if(i>=0)return {pack:alt,index:i};
 }
 return null;
}
async function v72Attach(packId,clipIndex){
 if(!state.loaded||!state.rigInfo?.skinnedMeshes){v72Status('Load your rigged 3D character first.',true);return}
 let p=v72Library.packs.find(x=>x.id===packId);if(!p||!p.clips[clipIndex])return;
 const twin=v718KaykitGlbTwin(p,clipIndex);if(twin){p=twin.pack;packId=p.id;clipIndex=twin.index;v72Status('Using KayKit GLB counterpart for '+p.clips[clipIndex].name+'…');}
 const already=v74GetAttached(packId,clipIndex);
 if(already){chooseClip(already.clip);v74ShowRetargetReport(already.clip.name,already.report,true);return}
 if(v72Library.busy)return;v72Library.busy=true;
 try{
  v72Library.lastAttachError=null;
  v72Status('Checking skeleton for '+p.clips[clipIndex].name+'…');
  let parsed=v74State.parsed.get(packId);
  if(!parsed){
   const saved=await v72GetRecord(packId);if(!saved)throw new Error('Pack is missing from browser storage');
   parsed=await v72ParseMotion(saved.name,saved.bytes);
   v74State.parsed.set(packId,parsed);
  }
  const source=parsed.animations?.[clipIndex];if(!source)throw new Error('This clip is missing from its saved motion file');
  v76CaptureReport(source,parsed.root,p.name);
  const bindRest=v717KayKitReference(p,parsed)||await v715KinemIQReference(p);
  const result=v77WorldRetarget(source,parsed.root,bindRest);
  // KayKit authored walking rotations use its T-pose skeleton axes. For walks,
  // transfer local bind-relative joint rotations directly instead of allowing
  // a different character's parent-bone orientation to cancel the pose.
  if(bindRest && /kaykit|rig_(?:medium|large)/i.test(String(p.sourceGroup||'')+' '+p.name) &&
     /^(?:walk|sneak)/i.test(source.name||'')){
   v721KayKitWalkingPose(result,source,parsed.root,bindRest);
  }
  if(bindRest && !result.report.referenceBindPose?.startsWith('KinemIQ'))result.report.referenceBindPose='KayKit GLB inverse-bind matrices';
  await v77VerifyRetarget(result,source,parsed.root);
  v76LastReport.result=result.report;
  result.clip.name=v72UniqueClipName(v72Friendly(source.name)+' · '+p.name.replace(/\.(glb|fbx)$/i,''));
  state.clips.push(result.clip);
  v74SaveAttached(packId,clipIndex,result.clip,result.report);
  if(!state.mixer)state.mixer=new THREE.AnimationMixer(state.model);
  refreshClipUI();updatePipelineUI();chooseClip(result.clip);
  v74ShowRetargetReport(result.clip.name,result.report);
 }catch(e){v72Library.lastAttachError=e.message;if(v76LastReport)v76LastReport.error=e.message;v72Status('Could not attach motion: '+e.message,true)}finally{v72Library.busy=false}
}
let v711VisibleLimit=150;
function v711RefreshPackFilter(){
 const select=$('v711PackFilter');if(!select)return;
 const previous=select.value;
 select.replaceChildren(new Option('All installed motion packs','all'));
 for(const p of v72Library.packs){select.append(new Option(`${p.name} · ${p.clips.length} clips`,p.id))}
 select.value=[...select.options].some(o=>o.value===previous)?previous:'all';
}
function v72RenderPacks(){
 const box=$('v72SavedPacks');if(!box)return;box.replaceChildren();
 let count=0,bytes=0;for(const p of v72Library.packs){count+=p.clips.length;bytes+=p.size}
 $('v72LibraryCount').textContent=`${count} clips · ${v72Library.packs.length} files · ${v72ReadableBytes(bytes)}`;
 v711RefreshPackFilter();
 for(const p of v72Library.packs.slice(0,70)){
  const row=document.createElement('div');row.className='v72Pack';
  const label=document.createElement('span');label.title=p.name;label.textContent=`${p.name} · ${p.clips.length} clips`;
  const remove=document.createElement('button');remove.textContent='Remove';remove.type='button';remove.title='Delete this file from the local motion library';
  remove.addEventListener('click',async()=>{
   if(!confirm('Remove '+p.name+' from your local motion library? This does not delete the source file on your PC.'))return;
   try{await v72Transaction('readwrite',store=>store.delete(p.id));v72Library.packs=v72Library.packs.filter(x=>x.id!==p.id);v74State.parsed.delete(p.id);v72RenderPacks();v71RefreshCatalog();v72Status('Removed '+p.name+'. Clips already attached to the current character remain available until it is unloaded.')}catch(e){v72Status(e.message,true)}
  });row.append(label,remove);box.append(row);
 }
 if(!v72Library.packs.length){const empty=document.createElement('span');empty.className='tiny';empty.textContent='No motion packs imported yet.';box.append(empty)}
}
async function v72Init(){
 $('v72ImportBtn').addEventListener('click',()=>$('v72Files').click());
 $('v72Files').addEventListener('change',e=>v72ImportFiles(e.target.files));
 $('v72ReportBtn').addEventListener('click',()=>{const text=v72Library.lastReport.length?v72Library.lastReport.join('\n'):'No import errors yet.';download(new Blob([text],{type:'text/plain'}),'coremotion_motion_import_report.txt')});
 try{
  v72Library.db=await v72OpenDB();const rows=await v72GetAll();
  v72Library.packs=rows.map(x=>({id:x.id,name:x.name,sourceGroup:x.sourceGroup||'',format:x.format,clips:x.clips||[],added:x.added,size:x.bytes?.byteLength||0}));
  v72Status('Library ready. Import real GLB/FBX animations or a ZIP of motion files.');
 }catch(e){v72Status('Library storage unavailable: '+e.message,true)}
 v72RenderPacks();v71RefreshCatalog();
}
v72Init();

v71Init();


// V7.3: explicit opt-in starter motions, sourced from Quaternius CC0 library.
// Download URL is a public, commit-pinned, optimized copy credited by its host project.
// Never import if checksum differs; never upload character images or animation data.
const V73_SOURCE='https://raw.githubusercontent.com/Seyamalam/blood-league-kickoff/29587c68a11fe7101d89c7df6cca120113c63aa2/public/assets/vendor/quaternius/universal-animation-library.glb';
const V73_EXPECTED_SHA256='4c748767741a3e495d89667b9a218b690ba9810b9517a12e960780e3ca72c4e9';
let v73Busy=false;
function v73Status(message,error=false){
 const el=$('v73InstallStatus');if(!el)return;
 el.textContent=message;el.classList.toggle('error',!!error);
}
async function v73InstallStarter(){
 if(v73Busy||v72Library.busy)return;
 const button=$('v73InstallStarter');
 if(!v72Library.db){v73Status('Local motion library is not ready. Open My Motion Packs and check storage access.',true);return}
 if(v72Library.packs.some(p=>p.id===V73_EXPECTED_SHA256)){
  $('v71Source').value='library';$('v72MotionPacks').open=true;
  v73Status('Starter motions already installed. Choose an imported clip from My motion packs.');
  return;
 }
 v73Busy=true;button.disabled=true;
 try{
  v73Status('Downloading the CC0 starter motion file (2.6 MB)…');
  const response=await fetch(V73_SOURCE,{mode:'cors',cache:'no-store',credentials:'omit'});
  if(!response.ok)throw new Error('Source host returned HTTP '+response.status);
  const size=Number(response.headers.get('content-length')||0);
  if(size>8*1024*1024)throw new Error('Source file exceeds 8 MB');
  const bytes=await response.arrayBuffer();
  if(bytes.byteLength<1024||bytes.byteLength>8*1024*1024)throw new Error('Unexpected download size');
  v73Status('Checking downloaded file checksum…');
  const digest=await v72Digest(bytes);
  if(digest!==V73_EXPECTED_SHA256)throw new Error('File checksum differs from the verified CC0 source. Nothing was imported.');
  v73Status('Verified. Importing real animation clips into your local library…');
  const file=new File([bytes],'Quaternius_CC0_Starter_Motions.glb',{type:'model/gltf-binary'});
  await v72ImportFiles([file]);
  const pack=v72Library.packs.find(p=>p.id===digest);
  if(!pack)throw new Error('Download verified, but Core Motion could not parse the GLB. See import report below.');
  $('v72MotionPacks').open=true;$('v71Source').value='library';v71RefreshCatalog();
  v73Status('Installed '+pack.clips.length+' real animation clips. Load a rigged character, select a motion, and preview it. Compatibility depends on the skeleton.');
  button.textContent='✓ Starter motions installed';
 }catch(e){
  v73Status('Starter install not completed: '+(e?.message||e)+'. Try downloading the original pack from the creator under “Find more free motion packs”, then import its GLB/FBX/ZIP. No existing motions were changed.',true);
 }finally{v73Busy=false;button.disabled=false}
}
function v73Init(){
 const button=$('v73InstallStarter');if(!button)return;
 button.addEventListener('click',v73InstallStarter);
 // IndexedDB initializes asynchronously in V7.2.
 const previous=v72RenderPacks;
 v72RenderPacks=function(...args){
  previous(...args);
  const installed=v72Library.packs.some(p=>p.id===V73_EXPECTED_SHA256);
  button.textContent=installed?'✓ Starter motions installed':'↓ Install free starter motions';
  if(installed && !$('v73InstallStatus')?.classList.contains('error'))v73Status('Starter pack ready. '+v72Library.packs.find(p=>p.id===V73_EXPECTED_SHA256).clips.length+' clips saved locally.');
 };
 // Re-render immediately only when the library has already loaded.
 if(v72Library.db)v72RenderPacks();
}
v73Init();
// V7.11: install instructions + one-click handoff to the proven local import pipeline.
(function v711Init(){
 const packFilter=$('v711PackFilter');
 if(packFilter)packFilter.addEventListener('change',()=>{v711VisibleLimit=150;v71RefreshCatalog()});
 for(const b of document.querySelectorAll('[data-v711-import]'))b.addEventListener('click',()=>{
  const motionPacks=$('v72MotionPacks');if(motionPacks)motionPacks.open=true;
  $('v711ImportHint').textContent='Choose the downloaded .zip containing GLB/FBX, or select its GLB/FBX files. Standalone glTF + .bin pairs are not supported; convert them to a self-contained GLB first.';
  $('v72Files')?.click();
 });
})();



// V7.4 -- automatic recognition of SkinTokens-style generically named humanoid rigs.
// No joint-marker editing is needed. Only well-formed 28/52-bone human structures
// qualify; arbitrary bone_N rigs are not forced into a potentially harmful map.
const v74State={swapSides:false,byModel:new WeakMap(),attached:new WeakMap(),parsed:new Map()};
function v74BoneChildren(b){return (b?.children||[]).filter(x=>x.isBone)}
function v74SingleChain(b,limit=24){const result=[];let node=b;
 while(node && result.length<limit){result.push(node);const next=v74BoneChildren(node);if(next.length!==1)break;node=next[0]}
 return result;
}
function v74InferGeneric(bones,swapSides=false){
 if(!Array.isArray(bones)||![28,52].includes(bones.length)||!bones.every(b=>/^bone_\d+$/.test(b.name)))return null;
 const set=new Set(bones),roots=bones.filter(b=>!set.has(b.parent));
 if(roots.length!==1)return null;
 const hip=roots[0],hipChildren=v74BoneChildren(hip);
 if(hipChildren.length!==3)return null;
 let torso=null,legs=[];
 for(const child of hipChildren){
  let node=child,branch=null;
  for(let i=0;i<7;i++){
   const sub=v74BoneChildren(node);
   if(sub.length>=3){branch=node;break}
   if(sub.length!==1)break;node=sub[0];
  }
  if(branch){if(torso)return null;torso={start:child,chest:branch}}
  else legs.push(child);
 }
 if(!torso||legs.length!==2)return null;
 const torsoChain=v74SingleChain(torso.start); // stops at branching chest
 if(torsoChain.at(-1)!==torso.chest || torsoChain.length<2 || torsoChain.length>4)return null;
 const chestBranches=v74BoneChildren(torso.chest);
 if(chestBranches.length!==3)return null;
 const branches=chestBranches.map(start=>({start,chain:v74SingleChain(start)}));
 branches.sort((a,b)=>a.chain.length-b.chain.length);
 const neckBranch=branches[0],arms=branches.slice(1);
 if(neckBranch.chain.length<2 || neckBranch.chain.length>3||arms.some(a=>a.chain.length<4))return null;
 if(legs.some(l=>v74SingleChain(l).length<3))return null;
 const named=new Map();const put=(semantic,bone)=>{if(bone)named.set(semantic,bone)};
 put('hips',hip);
 torsoChain.forEach((bone,i)=>put('spine'+(i+1),bone));
 put('neck',neckBranch.chain[0]);put('head',neckBranch.chain[1]);
 // In the currently supported SkinTokens generated GLBs, positive X is
 // anatomical left; the user can switch sides if a different facing is used.
 function assignPair(pair,isArm){
  const sorted=[...pair].sort((a,b)=>a.start.position.x-b.start.position.x);
  if(Math.abs(sorted[0].start.position.x-sorted[1].start.position.x)<.005)return false;
  const positiveIsLeft=!swapSides;
  for(const part of sorted){
   const side=(part===sorted[1])==positiveIsLeft?'left':'right';
   const chain=part.chain||v74SingleChain(part.start);
   const kinds=isArm?['shoulder','upperarm','forearm','hand']:['thigh','shin','foot','toe'];
   kinds.forEach((kind,i)=>put(side+kind,chain[i]));
  }
  return true;
 }
 if(!assignPair(arms,true) || !assignPair(legs.map(l=>({start:l,chain:v74SingleChain(l)})),false))return null;
 if(!['hips','spine1','spine2','neck','head','leftupperarm','rightupperarm','leftthigh','rightthigh','leftfoot','rightfoot'].every(n=>named.has(n)))return null;
 return {named,size:bones.length,kind:'SkinTokens-style generated humanoid',side:swapSides?'reversed':'standard'};
}
function v74CurrentAutoMap(){
 if(!state.model)return null;
 const bones=v7AllBones();return v74InferGeneric(bones,v74State.swapSides);
}
function v74UpdateRigStatus(){
 const el=$('v74RigStatus');if(!el)return;
 if(!state.loaded){el.textContent='Load a rigged character to check compatibility.';return}
 const bones=v7AllBones(),auto=v74CurrentAutoMap();
 if(auto){el.textContent=`Automatic humanoid mapping ready · ${auto.size} generic joints detected. Select a saved animation and preview it (no bone editing).`}
 else if(bones.length){el.textContent=`Character has ${bones.length} bones. Named humanoid bones are matched automatically; other rigs may need a compatible motion pack.`}
 else{el.textContent='This character has no recognized skeleton. Generate or load a rigged 3D model before selecting imported motions.'}
}
function v74CoreBone(name){
 return new Set(['hips','spine1','spine2','spine3','neck','head',
 'leftshoulder','leftupperarm','leftforearm','lefthand','leftthigh','leftshin','leftfoot','lefttoe',
 'rightshoulder','rightupperarm','rightforearm','righthand','rightthigh','rightshin','rightfoot','righttoe']).has(v72Canon(name));
}
function v74GetAttached(packId,clipIndex){
 const bucket=state.model&&v74State.attached.get(state.model);
 const key=packId+'|'+clipIndex+'|'+Number(v74State.swapSides);
 const found=bucket?.get(key);
 return found&&state.clips.includes(found.clip)?found:null;
}
function v74SaveAttached(packId,clipIndex,clip,report){
 if(!state.model)return;
 let bucket=v74State.attached.get(state.model);if(!bucket){bucket=new Map();v74State.attached.set(state.model,bucket)}
 bucket.set(packId+'|'+clipIndex+'|'+Number(v74State.swapSides),{clip,report});
}
function v74ShowRetargetReport(name,report,reused=false){
 const generic=report.generic?' · Automatic generic-rig mapping':' · Named-bone matching';
 const health=report.motionQuality?` · Body movement: ${report.motionQuality.target}% (source ${report.motionQuality.source}%)${report.motionQuality.method==='skeleton-utils'?' · corrected with full-skeleton retargeting':''}`:'';
 const text=report.method==='world-space-v2' ? `${reused?'Replaying':'Previewing'} ${name}: anatomical retarget · ${report.mapped} mapped body joints · ${Math.round(report.coverage*100)}% essential coverage${health}. Rest-pose rotations and source pelvis motion transferred. Preview alignment before export.` : `${reused?'Replaying':'Previewing'} ${name}: ${report.mapped}/${report.total} joints matched (${Math.round(report.coverage*100)}% core)${generic}${health}. Check character orientation before exporting.`;
 v72Status(text);const el=$('v74LastResult');if(el)el.textContent=text;
}
function v74Init(){
 const checkbox=$('v74SwapSides');if(checkbox)checkbox.addEventListener('change',e=>{
  v74State.swapSides=!!e.target.checked;
  v74UpdateRigStatus();
  v72Status('Left/right mapping changed. Click Use & preview on a motion again to check the corrected direction. Existing clips are unchanged.');
 });
 const preset=$('v74ExportPreset');if(preset)preset.addEventListener('click',()=>{
  if(!state.loaded||!state.clips.length){v72Status('Load a character and select an animation first.',true);return}
  $('sizeSelect').value='1024';$('countSelect').value='16';$('colSelect').value='8';
  $('v71ExportSection')?.scrollIntoView({block:'start',behavior:'smooth'});
  v72Status('Your tested export settings are selected: 1024 px, 16 frames, 8 columns. Choose a direction or all 8 directions to export.');
 });
 v74UpdateRigStatus();
}
v74Init();



// V7.6 — Diagnose source motion, validate left/right gait independently, and
// avoid false-success claims when a tiny subset of joints is retargeted.
let v76LastReport=null;
function v76RotationRange(track){
 if(!track||!track.values||track.values.length<8||!track.name.endsWith('.quaternion'))return 0;
 const first=new THREE.Quaternion().fromArray(track.values,0).normalize();let peak=0;
 for(let i=4;i+3<track.values.length;i+=4){const next=new THREE.Quaternion().fromArray(track.values,i).normalize();peak=Math.max(peak,first.angleTo(next))}
 return Math.round(peak*1000)/1000;
}
function v76SemanticReport(clip,root){
 const bones=v72BoneNodes(root);
 return (clip.tracks||[]).map(t=>{
  const info=v72TrackInfo(t.name),bone=info?v72SourceBoneForTrack(bones,info.node):null;
  return {track:t.name,sourceBone:bone?.name||null,semantic:v72Canon(bone?.name||info?.node||''),rotationRadians:v76RotationRange(t)};
 });
}
function v76CaptureReport(clip,sourceRoot,pack){
 const source=v72BoneNodes(sourceRoot),target=v7AllBones(),targetAuto=v74CurrentAutoMap();
 v76LastReport={version:'7.15.0',created:new Date().toISOString(),pack,clip:clip.name,duration:clip.duration,
  sourceBones:source.map(b=>({name:b.name,parent:b.parent?.isBone?b.parent.name:null,role:v72Canon(b.name)})),
  targetBones:target.map(b=>({name:b.name,parent:b.parent?.isBone?b.parent.name:null})),
  targetRoles:targetAuto?Object.fromEntries([...targetAuto.named].map(([k,b])=>[k,b.name])):null,
  sourceTracks:v76SemanticReport(clip,sourceRoot)};
}
function v76LimbTracks(clip,root,isTarget){
 const roles=new Map();
 if(isTarget){const automatic=v74CurrentAutoMap();if(automatic)for(const [sem,b] of automatic.named)roles.set(b.name,sem)}
 const bones=v72BoneNodes(root),ranges=new Map();
 for(const track of clip.tracks||[]){
  const info=v72TrackInfo(track.name);if(!info||info.property!=='quaternion')continue;
  const bone=v72SourceBoneForTrack(bones,info.node);
  const role=bone?(roles.get(bone.name)||v72Canon(bone.name)):v72Canon(info.node);
  if(!role)continue;
  ranges.set(role,Math.max(ranges.get(role)||0,v76RotationRange(track)));
 }
 return ranges;
}
function v76ValidateWalk(result,source,sourceRoot){
 const sourceAngles=v76LimbTracks(source,sourceRoot,false);
 const targetAngles=v76LimbTracks(result.clip,state.model,true);
 const limbs=['leftthigh','rightthigh','leftshin','rightshin'];
 const targetStatus=Object.fromEntries(limbs.map(k=>[k,targetAngles.get(k)||0]));
 const sourceStatus=Object.fromEntries(limbs.map(k=>[k,sourceAngles.get(k)||0]));
 result.report.legMotion={source:sourceStatus,target:targetStatus};
 // A genuine walk has movement on both sides. Do not pass simply because
 // fingers and the spine moved; this is what V7.5 falsely allowed.
 const active=(prefix,values)=>Math.max(values.get(prefix+'thigh')||0,values.get(prefix+'shin')||0);
 const left=active('left',targetAngles),right=active('right',targetAngles);
 if(left<.07 || right<.07){
  const missing=limbs.filter(k=>!targetAngles.has(k));
  throw new Error(`Walk retarget incomplete: only ${result.report.mapped}/${result.report.total} source joints matched. `+
    `Left leg ${left.toFixed(2)} rad, right leg ${right.toFixed(2)} rad (minimum 0.07 each). `+
    `${missing.length?'Unmapped leg joints: '+missing.join(', ')+'. ':''}`+
    `Download the Compatibility Report and share it for exact source-bone correction. Nothing was changed on your character.`);
 }
 // Verification must also have meaningful geometry movement from each foot;
 // per-leg rotation is the first gate, not sufficient proof on its own.
 const targetFeet=v76FootTravel(state.model,result.clip,v75TargetParts());
 result.report.legMotion.feet=targetFeet;
 if(!targetFeet)throw new Error('Cannot verify both feet on this rig. Download the Compatibility Report for a rig-specific mapping fix.');
 if(targetFeet.left<.018||targetFeet.right<.018){
  throw new Error(`Walk produces almost no movement in ${targetFeet.left<.018?'left':'right'} foot `+
   `(left ${Math.round(targetFeet.left*100)}%, right ${Math.round(targetFeet.right*100)}% of body height). `+
   `Download the Compatibility Report to identify the missing motion channels.`);
 }
}
function v76FootTravel(root,clip,parts){
 const hip=parts.get('hips'),left=parts.get('leftfoot'),right=parts.get('rightfoot');
 if(!hip||!left||!right||!clip?.tracks?.length)return null;
 const head=parts.get('head'),snap=v75SavePose(root),mixer=new THREE.AnimationMixer(root),action=mixer.clipAction(clip);
 try{
  root.updateMatrixWorld(true);
  const height=head?Math.max(.1,head.getWorldPosition(new THREE.Vector3()).distanceTo(left.getWorldPosition(new THREE.Vector3()))):1;
  action.play();let initial=null,maxL=0,maxR=0;
  for(const f of [0,.125,.25,.375,.5,.625,.75,.875]){
   mixer.setTime(clip.duration*f);root.updateMatrixWorld(true);
   const h=hip.getWorldPosition(new THREE.Vector3());
   const l=left.getWorldPosition(new THREE.Vector3()).sub(h),r=right.getWorldPosition(new THREE.Vector3()).sub(h);
   if(!initial)initial=[l,r];else{maxL=Math.max(maxL,l.distanceTo(initial[0]));maxR=Math.max(maxR,r.distanceTo(initial[1]))}
  }
  return {left:Math.round(maxL/height*1000)/1000,right:Math.round(maxR/height*1000)/1000};
 }finally{action.stop();mixer.uncacheRoot(root);v75RestorePose(root,snap)}
}
function v76Init(){
 const btn=document.getElementById('v76ExportReport');if(!btn)return;
 btn.addEventListener('click',()=>{
  if(!v76LastReport){v72Status('Preview an imported motion first; then download its compatibility report.',true);return}
  const url=URL.createObjectURL(new Blob([JSON.stringify(v76LastReport,null,2)],{type:'application/json'}));
  const a=document.createElement('a');a.href=url;a.download='CoreMotion_Retarget_Report.json';a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1500);
  v72Status('Downloaded the bone-name compatibility report. It contains joint names and track metadata, not character textures or model geometry.');
 });
}
v76Init();


// V7.7: Anatomical WORLD-SPACE retargeting. Source rigs like Quaternius include
// BOTH a non-deforming root (axis conversion, -90deg X) and a moving pelvis.
// The old local-rotation mapper mistook root for hips, dropped pelvis, and then
// applied local bone changes without reconstructing animated parent transforms.
// This version samples the original motion hierarchy in world coordinates,
// converts bone WORLD deltas into target WORLD deltas, and reconstructs target
// LOCAL rotations in parent-to-child order. No manual bone positioning is used.
function v77SourceRoles(sourceRoot){
 const bones=v72BoneNodes(sourceRoot); const named=new Map();
 const generic=bones.length>0&&bones.every(b=>/^bone_\d+$/.test(b.name));
 if(generic){const inferred=v74InferGeneric(bones,false);
  if(!inferred)throw new Error('Source pack has an unidentified generic skeleton; cannot retarget safely.');
  return inferred.named;
 }
 // Hips and pelvis are not interchangeable if both exist. Prefer the pelvis:
 // it carries the actual anatomical body rotation and gait bob in Quaternius.
 const priority=b=>/^(?:pelvis|hips?)$/i.test(b.name.trim())?5:
  /^(?:root|rootbone)$/i.test(b.name.trim())?1:3;
 for(const b of bones){const role=v72Canon(b.name);if(!role)continue;
  if(!named.has(role)||priority(b)>priority(named.get(role)))named.set(role,b);
 }
 return named;
}
function v77WorldRetarget(source,sourceRoot,bindRest=null){
 if(!state.model||!source?.tracks?.length)throw new Error('Load a rigged character and a real motion clip.');
 const targetBones=v7AllBones(),auto=v74CurrentAutoMap(),targetByRole=new Map();
 if(auto)for(const [role,bone] of auto.named)targetByRole.set(role,bone);
 else for(const b of targetBones){const role=v72Canon(b.name);if(role&&!targetByRole.has(role))targetByRole.set(role,b);}
 const sourceByRole=v77SourceRoles(sourceRoot);
 // Bone hierarchy may have been reconstructed from a motion-only GLB.
 // Its named joints retain their original rest transforms and track bindings.
 // Rigs legitimately omit intermediate spine, head, shoulder, or toe bones.
 // Require the core locomotive chain, then report which extra joints can be copied.
 const essential=['hips','leftupperarm','rightupperarm','leftthigh','rightthigh',
   'leftshin','rightshin','leftfoot','rightfoot'];
 const missingSource=essential.filter(role=>!sourceByRole.has(role));
 const missingTarget=essential.filter(role=>!targetByRole.has(role));
 if(missingSource.length||missingTarget.length)
  throw new Error('Cannot safely retarget this rig. Source missing: '+(missingSource.join(', ')||'none')+
   '; character missing: '+(missingTarget.join(', ')||'none')+'. Check that both files contain a weighted humanoid skeleton.');
 // Use available torso/head landmarks for body-height estimation.
 const heightTopRole=['head','neck','spine3','spine2','spine1','hips']
  .find(role=>sourceByRole.has(role)&&targetByRole.has(role));
 const mapping=new Map(),names={};
 for(const [role,target] of targetByRole){const src=sourceByRole.get(role);
  if(src&&target){mapping.set(target,src);names[target.name]=src.name;}
 }
 if(mapping.size<9)throw new Error('Too few shared body joints for reliable motion transfer ('+mapping.size+').');
 const snapshots=v75SavePose(sourceRoot);
 sourceRoot.updateMatrixWorld(true);
 const sourceRest=new Map();
 for(const src of new Set(mapping.values())){
  const canonical=bindRest?.get(src.name);
  sourceRest.set(src,canonical?{
   quaternion:canonical.quaternion.clone(),position:canonical.position.clone()
  }:{
   quaternion:src.getWorldQuaternion(new THREE.Quaternion()),
   position:src.getWorldPosition(new THREE.Vector3())
  });
 }
 // Scale vertical pelvis motion to the current character's height; never copy
 // world-sized root translations directly onto a smaller generated model.
 const sourceHead=sourceRest.get(sourceByRole.get(heightTopRole))?.position;
 const sourceFootL=sourceRest.get(sourceByRole.get('leftfoot'))?.position;
 const sourceFootR=sourceRest.get(sourceByRole.get('rightfoot'))?.position;
 const targetHead=v72Library.targetRest.get(targetByRole.get(heightTopRole)?.name)?.worldPosition;
 const targetFootL=v72Library.targetRest.get(targetByRole.get('leftfoot').name)?.worldPosition;
 const targetFootR=v72Library.targetRest.get(targetByRole.get('rightfoot').name)?.worldPosition;
 const middle=(a,b)=>a.clone().add(b).multiplyScalar(.5);
 const sourceHeight=sourceHead&&sourceFootL&&sourceFootR?
  sourceHead.distanceTo(middle(sourceFootL,sourceFootR)):1;
 const targetHeight=targetHead&&targetFootL&&targetFootR?
  targetHead.distanceTo(middle(targetFootL,targetFootR)):1;
 const scale=THREE.MathUtils.clamp(targetHeight/Math.max(.0001,sourceHeight),.07,8);
 const hipTarget=targetByRole.get('hips'),hipSource=sourceByRole.get('hips');
 const hipOriginal=v72Library.targetRest.get(hipTarget.name);
 if(!hipOriginal?.worldQuaternion||!hipOriginal?.position||!hipOriginal?.worldPosition)
  throw new Error('Target rest pose was not captured; reload the character and retry.');
 // Static non-bone parent transforms must NOT be taken from the active preview
 // pose; use the bind-rest matrices captured when the model first loaded.
 const staticParentWorld=new Map();
 for(const b of targetBones){const rest=v72Library.targetRest.get(b.name);if(!rest)continue;
  staticParentWorld.set(b,rest.worldQuaternion.clone().multiply(rest.quaternion.clone().invert()));
 }
 const hipParentWorldQ=hipOriginal.worldQuaternion.clone().multiply(hipOriginal.quaternion.clone().invert());
 const hipParentScale=hipTarget.parent.getWorldScale(new THREE.Vector3());
 const body=targetBones.filter(b=>mapping.has(b));
 const ordered=targetBones.slice().sort((a,b)=>{
  const depth=node=>{let d=0;while(node?.parent?.isBone&&d<100){d++;node=node.parent;}return d};
  return depth(a)-depth(b);
 });
 const fps=60,nFrames=Math.min(1200,Math.max(2,Math.round(source.duration*fps)+1));
 if(nFrames>1200)throw new Error('Motion clip is too long to safely retarget.');
 const times=Array.from({length:nFrames},(_,i)=>i*source.duration/(nFrames-1));
 const values=new Map(body.map(b=>[b,[]])),hipPositions=[];
 const mixer=new THREE.AnimationMixer(sourceRoot),action=mixer.clipAction(source);
 try{
  action.play();
  for(const t of times){
   mixer.setTime(Math.min(t,Math.max(0,source.duration-1e-6)));sourceRoot.updateMatrixWorld(true);
   const desiredWorld=new Map(),targetLocal=new Map();
   for(const bone of ordered){
    const rest=v72Library.targetRest.get(bone.name);if(!rest)continue;
    const parent=bone.parent;
    const parentWorld=parent?.isBone&&desiredWorld.has(parent)?desiredWorld.get(parent):
       staticParentWorld.get(bone);
    if(!parentWorld)continue;
    const sourceBone=mapping.get(bone);
    let wanted;
    if(sourceBone){
     const old=sourceRest.get(sourceBone);
     const current=sourceBone.getWorldQuaternion(new THREE.Quaternion());
     const deltaWorld=current.multiply(old.quaternion.clone().invert());
     wanted=deltaWorld.multiply(rest.worldQuaternion.clone()).normalize();
    }else{
     wanted=parentWorld.clone().multiply(rest.quaternion).normalize();
    }
    const local=parentWorld.clone().invert().multiply(wanted).normalize();
    targetLocal.set(bone,local);desiredWorld.set(bone,wanted);
    if(sourceBone)values.get(bone).push(...local.toArray());
   }
   // Hip POSITION comes from the moving pelvis, not Quaternius's global root.
   // Keep locomotion in place; vertical body bob/duck/jump is retained.
   const sourceHipRest=sourceRest.get(hipSource).position;
   const sourceHipNow=hipSource.getWorldPosition(new THREE.Vector3());
   const worldBob=new THREE.Vector3(0,(sourceHipNow.y-sourceHipRest.y)*scale,0);
   // The model preview uses a parent fit-scale (often 3–5x). Convert the
   // desired world-space bob back to the target bone's *local* units.
   const localBob=worldBob.applyQuaternion(hipParentWorldQ.clone().invert());
   localBob.divide(new THREE.Vector3(Math.max(.00001,Math.abs(hipParentScale.x)),
    Math.max(.00001,Math.abs(hipParentScale.y)),Math.max(.00001,Math.abs(hipParentScale.z))));
   const restHipP=hipOriginal.position;
   // No source XZ travel: the game engine controls the character's location.
   hipPositions.push(restHipP.x+localBob.x,restHipP.y+localBob.y,restHipP.z+localBob.z);
  }
 }finally{
  action.stop();mixer.stopAllAction();mixer.uncacheRoot(sourceRoot);
  v75RestorePose(sourceRoot,snapshots);
 }
 const tracks=body.map(b=>new THREE.QuaternionKeyframeTrack(b.name+'.quaternion',times,values.get(b)));
 tracks.push(new THREE.VectorKeyframeTrack(hipTarget.name+'.position',times,hipPositions));
 const out=new THREE.AnimationClip(v72UniqueClipName(source.name),source.duration,tracks);
 out.optimize();
 const report={mapped:body.length,total:sourceByRole.size,coverage:essential.filter(r=>sourceByRole.has(r)&&targetByRole.has(r)).length/essential.length,
  method:'world-space-v3',offsetWarnings:0,positionSkipped:0,types:{generated:body.length},generic:!!auto,
  names,sourceHip:hipSource.name,
  scale:Number(scale.toFixed(3)),unmatched:[...sourceByRole.keys()].filter(r=>!targetByRole.has(r)),
  sourcePelvisMapped:hipSource.name,
  referenceBindPose:bindRest?'KinemIQ mannequin inverse-bind matrices':'per-clip default pose',
  startPoseCorrectionDegrees:bindRest?Object.fromEntries(
   ['leftupperarm','rightupperarm','leftthigh','rightthigh'].map(role=>{
    const bone=sourceByRole.get(role),ref=bone&&sourceRest.get(bone);
    return [role,bone&&ref?Math.round(bone.getWorldQuaternion(new THREE.Quaternion()).angleTo(ref.quaternion)*180/Math.PI):null];
   })):null};
 return {clip:out,report};
}
async function v77VerifyRetarget(result,source,sourceRoot){
 if(result.report.referenceBindPose?.startsWith('KinemIQ')){
  const target=v74CurrentAutoMap()?.named;
  const roles=['leftupperarm','rightupperarm'];
  const deviations=[];
  for(const role of roles){
   const bone=target?.get(role),rest=bone&&v72Library.targetRest.get(bone.name);
   const track=bone&&result.clip.tracks.find(t=>t.name===bone.name+'.quaternion');
   if(bone&&rest&&track?.values?.length>=4){
    const q=new THREE.Quaternion().fromArray(track.values,0).normalize();
    deviations.push(q.angleTo(rest.quaternion)*180/Math.PI);
   }
  }
  result.report.initialArmPoseDegrees=deviations.map(d=>Math.round(d));
  const sourceOffsets=Object.values(result.report.startPoseCorrectionDegrees||{}).filter(Number.isFinite);
  if(deviations.length===2&&sourceOffsets.length&&Math.max(...sourceOffsets)>30&&Math.max(...deviations)<5)
   throw new Error('Retargeted character still remains in its neutral arm pose. KinemIQ bind calibration did not transfer; please export the compatibility report.');
 }

 const sourceScore=v75MotionScore(sourceRoot,source,v75RigForSource(sourceRoot));
 const targetScore=v75MotionScore(state.model,result.clip,v75TargetParts());
 result.report.motionQuality={source:Number.isFinite(sourceScore)?Math.round(sourceScore*100):'unknown',
  target:Number.isFinite(targetScore)?Math.round(targetScore*100):'unknown',method:'world-space-v2'};
 const moving=/(?:walk|run|jog|sprint)/i.test(source.name||'');
 if(moving){
  v76ValidateWalk(result,source,sourceRoot);
  if(!Number.isFinite(targetScore)||targetScore<.025)
   throw new Error('Retargeted gait lacks sufficient foot and hand movement; the clip was not attached.');
 }
 // Distinguish coherent movement from huge, broken joint motion.
 if(Number.isFinite(sourceScore)&&Number.isFinite(targetScore)&&sourceScore>.03&&targetScore>Math.max(.8,sourceScore*4))
  throw new Error('Retargeted body displacement exceeds safe range; clip not attached.');
}

// V7.5 — Retargeting that checks actual anatomical movement, not just bone names.
// The source pack is retained in IndexedDB exactly as installed. This function
// runs in the browser, and neither uploads characters nor alters original GLBs.
function v75RigParts(root,autoSource=null){
 const bones=v72BoneNodes(root),bySemantic=new Map();
 if(autoSource)for(const [sem,b] of autoSource.named)bySemantic.set(sem,b);
 for(const bone of bones){const sem=v72Canon(bone.name);if(!bySemantic.has(sem))bySemantic.set(sem,bone)}
 return bySemantic;
}
function v75SavePose(root){
 const snap=[];root.traverse(o=>{if(o.isBone)snap.push({bone:o,p:o.position.clone(),q:o.quaternion.clone(),s:o.scale.clone()})});return snap;
}
function v75RestorePose(root,snap){
 for(const b of snap){b.bone.position.copy(b.p);b.bone.quaternion.copy(b.q);b.bone.scale.copy(b.s)}
 root.updateMatrixWorld(true);
}
// Mean peak displacement of wrists and ankles relative to hips, normalized to
// body height. Root movement alone cannot make a broken T-pose pass this check.
function v75MotionScore(root,clip,parts){
 const rootBone=parts.get('hips');if(!rootBone)return null;
 const ends=['lefthand','righthand','leftfoot','rightfoot']
  .map(k=>parts.get(k)).filter(b=>b&&b!==rootBone);
 if(ends.length<2||!clip?.tracks?.length||!(clip.duration>0))return null;
 const head=parts.get('head');const feet=[parts.get('leftfoot'),parts.get('rightfoot')].filter(Boolean);
 const center=new THREE.Vector3();
 root.updateMatrixWorld(true);
 const measureHeight=()=>{
  if(head&&feet.length){const top=head.getWorldPosition(new THREE.Vector3());
   const bottom=new THREE.Vector3();feet.forEach(b=>bottom.add(b.getWorldPosition(new THREE.Vector3())));bottom.multiplyScalar(1/feet.length);
   return top.distanceTo(bottom)}
  return 1;
 };
 const height=Math.max(.1,measureHeight());
 const snap=v75SavePose(root),mixer=new THREE.AnimationMixer(root),action=mixer.clipAction(clip);
 try{
  action.play();
  const samples=[];
  for(const f of [0,.18,.36,.54,.72,.9]){
   mixer.setTime(f*clip.duration);root.updateMatrixWorld(true);
   const hip=rootBone.getWorldPosition(center).clone();
   samples.push(ends.map(b=>b.getWorldPosition(new THREE.Vector3()).sub(hip)));
  }
  const start=samples[0];
  const peaks=start.map((p,i)=>Math.max(...samples.slice(1).map(frame=>p.distanceTo(frame[i])))/height);
  return peaks.reduce((x,y)=>x+y,0)/peaks.length;
 }finally{action.stop();mixer.uncacheRoot(root);v75RestorePose(root,snap)}
}
function v75RigForSource(sourceRoot){
 const bones=v72BoneNodes(sourceRoot);
 return v75RigParts(sourceRoot,bones.length&&bones.every(b=>/^bone_\d+$/.test(b.name))?v74InferGeneric(bones,false):null);
}
function v75TargetParts(){return v75RigParts(state.model,v74CurrentAutoMap())}
async function v75VerifyRetarget(result,source,sourceRoot){
 const locomotion=/(walk|run|sprint|jog)/i.test(source.name||'');
 const sourceScore=v75MotionScore(sourceRoot,source,v75RigForSource(sourceRoot));
 let targetScore=v75MotionScore(state.model,result.clip,v75TargetParts());
 let method='bone-space';
 // Walk/Run should visibly move both hands or feet. SkeletonUtils independently
 // handles source and target world transforms by sampling animated poses.
 const insufficient=Number.isFinite(targetScore) && targetScore<Math.max(.027,(sourceScore||0)*.38);
 if(insufficient && Number.isFinite(sourceScore) && sourceScore>.04){
  const sourceSkin=(()=>{let found=null;sourceRoot.traverse(o=>{if(!found&&o.isSkinnedMesh&&o.skeleton?.bones?.length)found=o});return found})();
  const targetSkin=(()=>{let found=null;state.model.traverse(o=>{if(!found&&o.isSkinnedMesh&&o.skeleton?.bones?.length)found=o});return found})();
  if(sourceSkin&&targetSkin){
   const snapshot=v75SavePose(state.model),sourceSnap=v75SavePose(sourceRoot);
   try{
    const {retargetClip}=await import('three/addons/utils/SkeletonUtils.js');
    const alternate=retargetClip(targetSkin,sourceSkin,source,{names:result.report.names,hip:result.report.sourceHip||'hips',fps:30,preserveBoneMatrix:true,preserveBonePositions:true,useFirstFramePosition:false,hipInfluence:new THREE.Vector3(0,1,0)});
    // SkeletonUtils emits .bones[Joint].quaternion. Our mixer is rooted at the
    // entire imported GLTF scene, so address each uniquely named bone directly.
    for(const track of alternate.tracks){
     track.name=track.name.replace(/^\.bones\[([^\]]+)\]\.(quaternion|position)$/,(_,name,prop)=>name+'.'+prop);
    }
    const candidate=v75MotionScore(state.model,alternate,v75TargetParts());
    // Never substitute a retarget producing huge uncontrolled limb movement.
    if(Number.isFinite(candidate)&&candidate>targetScore*1.3&&candidate>.035&&candidate<Math.max(.8,sourceScore*4)){
     result.clip=alternate;targetScore=candidate;method='skeleton-utils';
    }
   }catch(err){console.warn('[Core Motion] alternate skeleton retarget unavailable:',err)}
   finally{v75RestorePose(state.model,snapshot);v75RestorePose(sourceRoot,sourceSnap)}
  }
 }
 result.report.motionQuality={source:Number.isFinite(sourceScore)?Math.round(sourceScore*100):'unknown',target:Number.isFinite(targetScore)?Math.round(targetScore*100):'unknown',method};
 if(locomotion)v76ValidateWalk(result,source,sourceRoot);
 if(locomotion&&Number.isFinite(sourceScore)&&sourceScore<.018){
  throw new Error('The imported Walk/Run clip itself barely moves its hands or feet. It is not a usable full-body gait. Try a different motion from the pack.');
 }
 if(locomotion&&Number.isFinite(targetScore)&&targetScore<.027){
  throw new Error(`Retargeting produced almost no full-body gait (hands/feet moved ${Math.round(targetScore*100)}% of body height; source ${Number.isFinite(sourceScore)?Math.round(sourceScore*100)+'%':'not measurable'}). The clip was not attached as a valid Walk/Run. Use another compatible animation pack or send the original source GLB for a rig-specific fix.`);
 }
}



// V7.8 — AI Motion Director. This is a NON-DESTRUCTIVE procedural motion-style
// layer applied after sampled animation; it is also used by existing exports.
// A local Ollama LLM translates natural-language prompts into bounded parameters.
// Without Ollama, clearly labeled offline style buttons/sliders still work.
const V78_DEFAULT={armSwing:0,hipSway:0,shoulderRoll:0,armWidth:0,lean:0,bounce:0,exaggeration:0};
const V78_KEYS=Object.keys(V78_DEFAULT);
const v78State={values:{...V78_DEFAULT},storageKey:null,model:'',busy:false,connected:false,bones:null,boneModel:null,lastBounce:null};
const V78_SLIDERS={armSwing:['v78Arm','v78ValArm'],hipSway:['v78Hip','v78ValHip'],shoulderRoll:['v78Shoulder','v78ValShoulder'],armWidth:['v78Width','v78ValWidth'],lean:['v78Lean','v78ValLean'],bounce:['v78Bounce','v78ValBounce'],exaggeration:['v78Bold','v78ValBold']};
function v78Bounded(obj){const out={};for(const k of V78_KEYS){let v=Number(obj?.[k]);if(!Number.isFinite(v))v=0;out[k]=THREE.MathUtils.clamp(v,k==='lean'?-1:0,1)}return out}
function v78Key(){const selected=state.selection.startsWith('clip::')?state.selection.slice(6):'';return selected&&state.calibrationKey?'coremotion-motion-director-v1::'+state.calibrationKey+'::'+selected:null}
function v78Message(msg,error=false){const el=$('v78Status');if(!el)return;el.textContent=msg;el.classList.toggle('error',error)}
function v78RefreshSliders(){for(const [k,[id,label]] of Object.entries(V78_SLIDERS)){$(id).value=Math.round(v78State.values[k]*100);$(label).textContent=Math.round(v78State.values[k]*100)+'%'}
 const clip=state.selection.startsWith('clip::')?state.selection.slice(6):null;
 $('v78Editing').textContent=clip?'Editing: '+clip+' · changes included in sprite export':'Choose an animation to edit its motion.';
}
function v78LoadForClip(){const key=v78Key();if(key===v78State.storageKey)return;
 v78State.storageKey=key;v78State.values={...V78_DEFAULT};
 if(key)try{v78State.values=v78Bounded(JSON.parse(localStorage.getItem(key)||'{}'))}catch{}
 v78RefreshSliders();
}
let v79UndoSnapshot=null;
function v78SetProfile(profile,label='Motion style updated.'){
 v79UndoSnapshot={...v78State.values};
 if(!v78Key()){v78Message('Select a real animation on a loaded character first.',true);return false}
 v78State.values=v78Bounded(profile);v78RefreshSliders();
 try{localStorage.setItem(v78Key(),JSON.stringify({ ...v78State.values }))}catch{v78Message('Preview works, but browser storage is blocked. Export the motion recipe to save it.',true)}
 if(state.loaded){updateAnimation(state.time);state.model?.updateMatrixWorld(true)}
 v78Message(label);return true;
}
function v78DetectBones(){if(!state.model)return null;if(v78State.boneModel===state.model)return v78State.bones;
 v78State.boneModel=state.model;v78State.lastBounce=null;const mapped=v74CurrentAutoMap()?.named;
 const named=new Map(mapped||[]);
 for(const b of v72BoneNodes(state.model)){const semantic=v72Canon(b.name);if(!named.has(semantic))named.set(semantic,b)}
 v78State.bones=named;return named;
}
const v78X=new THREE.Vector3(1,0,0),v78Y=new THREE.Vector3(0,1,0),v78Z=new THREE.Vector3(0,0,1);
function v78Rotate(bone,axis,radians){if(!bone||!Number.isFinite(radians)||Math.abs(radians)<.0000001)return;
 const q=state.face?.getWorldQuaternion(new THREE.Quaternion())||new THREE.Quaternion();
 const rotated=axis.clone().applyQuaternion(q).normalize();
 applyWorldRotation(bone,new THREE.Quaternion().setFromAxisAngle(rotated,THREE.MathUtils.clamp(radians,-.65,.65)));
}
function v78ApplyMotionStyle(time){
 if(!state.model||!state.selection.startsWith('clip::'))return;
 const x=v78State.values;if(!V78_KEYS.some(k=>Math.abs(x[k])>.00001))return;
 const bones=v78DetectBones();if(!bones?.size)return;
 const isLocomotion=/walk|run|sprint|jog|sneak|march|strafe|backpedal/i.test(state.selection);
 const period=Math.max(.001,currentPeriod());
 const normalized=((time%period)+period)%period/period;
 // Motion styles must agree at the start and end of looping clips. Blend into
 // the modified gait at either end rather than snapping shoulders into a pose.
 const ramp=Math.min(1,normalized/.14,(1-normalized)/.14);
 const smoothRamp=THREE.MathUtils.smoothstep(Math.max(0,ramp),0,1);
 const smooth=(isLocomotion?smoothRamp:Math.sin(Math.PI*normalized)**2);
 if(smooth<=0)return;
 const lThigh=bones.get('leftthigh'),rThigh=bones.get('rightthigh');
 // Reuse the current *animated* thigh rotations as the gait clock instead of
 // inventing an independent sine wave. The source clip is sampled just before
 // this non-destructive layer, so foot/arm timing stays tied to actual motion.
 const restOf=b=>rigStudio.rest?.get(b?.name);
 const pitch=b=>{if(!b)return 0;const rest=restOf(b);
  if(!rest)return 0;
  const local=rest.clone().invert().multiply(b.quaternion);
  return THREE.MathUtils.clamp(new THREE.Euler().setFromQuaternion(local,'XYZ').x,-1.1,1.1);
 };
 const leftPitch=pitch(lThigh),rightPitch=pitch(rThigh);
 const gait=THREE.MathUtils.clamp((leftPitch-rightPitch)*1.3,-1,1);
 // If the source clip has no meaningful leg motion, don't synthesize a fake
 // gait; preserve the imported animation instead of spreading the arms.
 const gaitStrength=isLocomotion?Math.min(1,Math.abs(gait)*2.3):0;
 const armAmp=(.28*x.armSwing+.075*x.exaggeration)*smooth;
 const shoulderAmp=.075*x.shoulderRoll*smooth;
 const hipAmp=.08*x.hipSway*smooth;
 const active=gaitStrength>.025?gait:0;
 v78Rotate(bones.get('leftupperarm'),v78X,-armAmp*active);
 v78Rotate(bones.get('rightupperarm'),v78X,armAmp*active);
 // Arm-width is bounded to subtle adjustment: larger independent shoulder
 // abduction was responsible for the partial T-pose at cycle boundaries.
 v78Rotate(bones.get('leftupperarm'),v78Z,.055*x.armWidth*smooth);
 v78Rotate(bones.get('rightupperarm'),v78Z,-.055*x.armWidth*smooth);
 v78Rotate(bones.get('leftshoulder'),v78Z,shoulderAmp*active);
 v78Rotate(bones.get('rightshoulder'),v78Z,-shoulderAmp*active);
 v78Rotate(bones.get('hips'),v78Y,hipAmp*active);
 v78Rotate(bones.get('spine2')||bones.get('spine1'),v78Z,.065*x.hipSway*active*smooth);
 v78Rotate(bones.get('spine3')||bones.get('spine2'),v78X,.11*x.lean*smooth);
 const stride=.095*x.exaggeration*smooth;
 v78Rotate(lThigh,v78X,stride*leftPitch);
 v78Rotate(rThigh,v78X,stride*rightPitch);
 if(x.bounce>0&&isLocomotion){
  // Tiny, grounded bounce derived from stride, not independent loop phase.
  const lift=.016*x.bounce*gaitStrength*smooth;
  state.model.position.y+=lift;
  v78State.lastBounce={root:state.model,offset:lift};
 }
 state.model.updateMatrixWorld(true);
}
const V78_PRESETS={
 swag:{armSwing:.74,hipSway:.66,shoulderRoll:.64,armWidth:.28,lean:.32,bounce:.56,exaggeration:.30},
 heroic:{armSwing:.51,hipSway:.13,shoulderRoll:.28,armWidth:.24,lean:.35,bounce:.25,exaggeration:.45},
 sneaky:{armSwing:.12,hipSway:.15,shoulderRoll:.08,armWidth:.08,lean:.52,bounce:.02,exaggeration:.04},
 punchy:{armSwing:.78,hipSway:.27,shoulderRoll:.39,armWidth:.30,lean:.25,bounce:.32,exaggeration:.86}
};
async function v78CheckAI(){const select=$('v78Model');try{
 const resp=await fetch('/api/furnace/motion-director/models',{cache:'no-store'});
 const data=await resp.json();if(!resp.ok)throw Error(data.detail||'Could not check local AI');
 const saved=select.value||v78State.model;select.replaceChildren();
 for(const model of (data.models||[])){const opt=document.createElement('option');opt.value=model;opt.textContent=model;select.append(opt)}
 if(saved&&(data.models||[]).includes(saved))select.value=saved;
 v78State.connected=!!(data.models||[]).length;v78State.model=select.value;
 v78Message(v78State.connected?'Local AI connected. Select a motion, describe a style, and click Apply AI prompt.':'Ollama is running but has no installed models. Run: ollama pull llama3.2:3b');
 }catch(e){v78State.connected=false;v78Message('Local AI not connected. Install Ollama for Windows, then run: ollama pull llama3.2:3b. Offline motion-style buttons still work. ('+e.message+')',true)}
}
async function v78AskAI(){if(v78State.busy)return;if(!v78Key()){v78Message('Load a character and select an animation before prompting.',true);return}
 const prompt=$('v78Prompt').value.trim();if(!prompt){v78Message('Describe how you want this animation to change.',true);return}
 const model=$('v78Model').value;if(!model){v78Message('Click Check AI first. Install Ollama and a small language model if none are listed.');return}
 v78State.busy=true;$('v78Ask').disabled=true;v78Message('Asking local AI to interpret your motion edit…');
 try{const response=await fetch('/api/furnace/motion-director/edit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt,clip:state.selection.slice(6),model,current:v78State.values})});
 const data=await response.json();if(!response.ok)throw Error(data.detail||'AI request failed');
 v78SetProfile(data.profile,'AI edit applied to '+state.selection.slice(6)+'. '+(data.summary||'Preview or export to see the change.')+' · Model: '+data.model);
 }catch(e){v78Message('Could not apply AI edit: '+e.message+' Try Check AI or an offline style button.',true)}finally{v78State.busy=false;$('v78Ask').disabled=false}
}
function v78Init(){if(!$('v78Director'))return;
 for(const [key,[id]] of Object.entries(V78_SLIDERS))$(id).addEventListener('input',e=>v78SetProfile({...v78State.values,[key]:Number(e.target.value)/100},'Custom motion settings applied.'));
 document.querySelectorAll('[data-v78-style]').forEach(b=>b.addEventListener('click',()=>v78SetProfile(V78_PRESETS[b.dataset.v78Style],'Offline style applied: '+b.textContent.trim()+'. For AI interpretation, connect Ollama.')));
 $('v78Reset').addEventListener('click',()=>v78SetProfile(V78_DEFAULT,'Restored the original motion with no style overrides.'));
 $('v78Connect').addEventListener('click',v78CheckAI);
 $('v78Ask').addEventListener('click',v78AskAI);
 $('v78Model').addEventListener('change',()=>{v78State.model=$('v78Model').value});
 $('v78SaveRecipe').addEventListener('click',()=>{
  if(!v78Key()){v78Message('Choose an animation before exporting its recipe.',true);return}
  const recipe={schema:'coremotion-ai-motion-style-v1',clip:state.selection.slice(6),profile:v78State.values,prompt:$('v78Prompt').value.trim(),note:'Non-destructive motion-style parameters; not an AI-generated 3D animation file.'};
  download(new Blob([JSON.stringify(recipe,null,2)],{type:'application/json'}),'CoreMotion_'+filename(recipe.clip)+'_motion_style.json');
 });
 v78RefreshSliders();v78CheckAI();
}
v78Init();

// V7.9 additive controls: existing AI sliders, motion engine and loader remain unchanged.
(function v79EnhanceDirector(){
 const panel=document.getElementById('v78Director');
 if(!panel)return;
 const actions=panel.querySelector('.v78PromptActions');
 if(!actions)return;
 const compare=document.createElement('button');
 compare.id='v79Compare';compare.type='button';compare.textContent='Hold to compare original';
 const undo=document.createElement('button');
 undo.id='v79Undo';undo.type='button';undo.textContent='Undo last edit';
 actions.append(compare,undo);
 let held=null;
 const redraw=()=>{v78RefreshSliders();if(state.loaded)updateAnimation(state.time)};
 const start=e=>{if(held||!v78Key())return;if(e)e.preventDefault();held={...v78State.values};
  v78State.values={...V78_DEFAULT};redraw()};
 const stop=()=>{if(!held)return;v78State.values=held;held=null;redraw()};
 compare.addEventListener('pointerdown',start);
 window.addEventListener('pointerup',stop);
 window.addEventListener('pointercancel',stop);
 compare.addEventListener('keydown',e=>{if(e.key===' '||e.key==='Enter')start(e)});
 compare.addEventListener('keyup',e=>{if(e.key===' '||e.key==='Enter')stop()});
 undo.addEventListener('click',()=>{if(!v79UndoSnapshot){v78Message('No previous edit to undo.');return}
  const previous=v79UndoSnapshot;v79UndoSnapshot=null;
  v78SetProfile(previous,'Restored previous motion settings.');
  v79UndoSnapshot=null;
 });
 const badge=panel.querySelector('.v78Pill');if(badge)badge.textContent='V7.10 · Motion edits';
})();



// V7.12: browser-only, non-destructive visual browser for imported real clips.
// Does not generate fake motions; thumbnails of actual models appear only after preview.
const v712={folder:'all',limit:100,images:new Map(),names:new Map(),groups:[],lastFocus:null};
const v713={generating:false,cancel:false,activeGeneration:0};
try{v712.names=new Map(JSON.parse(localStorage.getItem('coremotion-v712-folder-names')||'[]'))}catch{}
function v712FolderId(pack){
 if(pack.sourceGroup)return 'source:'+pack.sourceGroup;
 const date=Date.parse(pack.added||'');
 // Older ZIP imports did not retain archive names. Group files added in a 2-minute window.
 if(Number.isFinite(date))return 'legacy:'+Math.floor(date/120000);
 return 'file:'+pack.id;
}
function v712FolderGroups(){
 const groups=new Map();
 for(const pack of v72Library.packs){const id=v712FolderId(pack);
  if(!groups.has(id))groups.set(id,{id,title:pack.sourceGroup||('Imported batch · '+new Date(pack.added||Date.now()).toLocaleString()),packs:[],count:0});
  const group=groups.get(id);group.packs.push(pack);group.count+=pack.clips.length;
 }
 return [...groups.values()].map(g=>({...g,title:v712.names.get(g.id)||g.title})).sort((a,b)=>a.title.localeCompare(b.title));
}
function v712Svg(category){
 // This is an illustration, never an invented frame from an unavailable GLB.
 const angles=category==='Combat'?[-26,50]:category==='Movement'?[-15,33]:category==='Actions'?[35,-35]:[8,-8];
 return `<svg aria-hidden="true" viewBox="0 0 100 130" fill="none" stroke="#75b7db" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"><circle cx="50" cy="20" r="10" fill="#376f93"/><path d="M50 33 L50 78 M50 45 l${angles[0]} 27 M50 45 l${angles[1]} 22 M50 78 L29 111 M50 78 L70 113"/></svg>`;
}
function v712Entries(){
 const folder=v712.folder,category=$('v712Category').value,query=$('v712Search').value.trim().toLowerCase();
 const data=v71CatalogData().filter(m=>{
  if(m.source==='loaded')return true;
  if(m.source!=='library')return false;
  const p=v72Library.packs.find(p=>p.id===m.packId);
  // Show a single copy per KayKit action. Existing FBX packs remain stored
  // and can be used from legacy interfaces, but the GLB counterpart wins.
  return !v718KaykitGlbTwin(p,m.clipIndex);
 });
 const packLookup=new Map(v72Library.packs.map(p=>[p.id,v712FolderId(p)]));
 const result=data.filter(m=>{
  if(folder==='loaded'&&m.source!=='loaded')return false;
  if(folder==='favorites'&&!v71Favorites.has(m.key))return false;
  if(folder!=='all'&&folder!=='loaded'&&folder!=='favorites'&&(m.source!=='library'||packLookup.get(m.packId)!==folder))return false;
  if(category!=='all'&&m.category!==category)return false;
  return !query||[m.label,m.category,m.packName||''].some(x=>x.toLowerCase().includes(query));
 });
 result.sort((a,b)=>Number(v71Favorites.has(b.key))-Number(v71Favorites.has(a.key))||a.label.localeCompare(b.label));
 return result;
}
function v712Render(){
 const folders=$('v712Folders');if(!folders)return;
 v712.groups=v712FolderGroups();
 if(!['all','loaded','favorites',...v712.groups.map(g=>g.id)].includes(v712.folder))v712.folder='all';
 const total=v712.groups.reduce((sum,g)=>sum+g.packs.reduce((n,p)=>n+p.clips.filter((c,i)=>!v718KaykitGlbTwin(p,i)).length,0),0);
 $('v712Total').textContent=`${total} saved clips · ${v712.groups.length} imported folders`;
 folders.replaceChildren();
 const buttons=[{id:'all',title:'All imported packs',count:total},{id:'loaded',title:'Current character',count:state.clips.length},{id:'favorites',title:'★ Favorites',count:v71Favorites.size},...v712.groups.map(g=>({id:g.id,title:g.title,count:g.count}))];
 for(const g of buttons){const b=document.createElement('button');b.type='button';b.className='v712Folder'+(v712.folder===g.id?' active':'');
  const name=document.createElement('span');name.textContent='▸ '+g.title;const n=document.createElement('b');n.textContent=String(g.count);b.append(name,n);
  b.addEventListener('click',()=>{v712.folder=g.id;v712.limit=100;v712Render()});folders.append(b);
  if(g.id!=='all'&&g.id!=='loaded'&&g.id!=='favorites'){b.title='Double-click to rename folder';b.addEventListener('dblclick',()=>{
   const next=prompt('Folder name (only changes its display name):',g.title);
   if(next&&next.trim()){v712.names.set(g.id,next.trim().slice(0,90));try{localStorage.setItem('coremotion-v712-folder-names',JSON.stringify([...v712.names]))}catch{}v712Render()}
  })}
 }
 const selected=buttons.find(x=>x.id===v712.folder);
 $('v712FolderHeading').textContent=(selected?.title||'All animations')+' · '+v712Entries().length+' matching animations';
 const list=$('v712Cards');list.replaceChildren();
 const entries=v712Entries();
 for(const m of entries.slice(0,v712.limit)){
  const card=document.createElement('article');card.className='v712Card';
  const thumb=document.createElement('div');thumb.className='v712Thumb';
  const screenshot=v712.images.get(m.key);
  if(screenshot){const im=new Image();im.src=screenshot;im.alt='Actual 3D preview of '+m.label;thumb.append(im)}
  else{const placeholder=document.createElement('div');placeholder.className='v713Pending';
   const icon=document.createElement('span');icon.textContent='▣';
   const word=document.createElement('span');word.textContent='Preview not generated';
   placeholder.append(icon,word);thumb.append(placeholder)}
  const label=document.createElement('span');label.className='v712Tag';label.textContent=screenshot?'Real character':'Not rendered';thumb.append(label);
  const title=document.createElement('div');title.className='v712CardTitle';title.textContent=m.label;
  const meta=document.createElement('div');meta.className='v712CardMeta';
  const sourcePack=m.source==='library'?v72Library.packs.find(p=>p.id===m.packId):null;
  meta.textContent=m.category+' · '+(m.seconds||0).toFixed(1)+' s'+(sourcePack?' · '+sourcePack.format.toUpperCase()+' · '+sourcePack.name.replace(/\.(glb|fbx)$/i,''):'');
  const actions=document.createElement('div');actions.className='v712CardActions';
  const play=document.createElement('button');play.type='button';play.className='primary';play.textContent='▶ Preview';
  const fav=document.createElement('button');fav.type='button';fav.className='v712Fav';fav.textContent=v71Favorites.has(m.key)?'★':'☆';fav.title='Toggle favorite';
  fav.addEventListener('click',()=>{if(v71Favorites.has(m.key))v71Favorites.delete(m.key);else v71Favorites.add(m.key);try{localStorage.setItem(v71FavoritesKey,JSON.stringify([...v71Favorites]))}catch{}v712Render();v71RefreshCatalog()});
  play.addEventListener('click',async()=>{
   if(!state.loaded){$('v712Status').textContent='Load a rigged character first. Motion preview uses your currently loaded model.';return}
   $('v712Status').textContent='Loading '+m.label+' on your character…';play.disabled=true;
   const before=state.selection;
   try{
    if(m.source==='loaded')chooseClip(state.clips[m.index]);
    else await v72Attach(m.packId,m.clipIndex);
    const ok=m.source==='loaded'||!!v74GetAttached(m.packId,m.clipIndex);
    if(ok){$('v712Status').textContent='Playing '+m.label+'. You can close this gallery to watch the animation on your character.';
     setTimeout(()=>{try{if(!state.loaded||!state.selection.startsWith('clip::'))return;
      // Stage snapshot reflects the *actual currently animated character*. Never claim it is a source-pack preview.
      v7RenderScene();const png=renderer.domElement.toDataURL('image/png');
      if(v712.images.size>=120)v712.images.delete(v712.images.keys().next().value);
      v712.images.set(m.key,png);if(!$('v712Gallery').hidden)v712Render();
     }catch{}},350);
    }else $('v712Status').textContent='Preview could not be attached. See the compatibility message in My Motion Packs.';
   }catch(e){$('v712Status').textContent='Preview unavailable: '+e.message}finally{play.disabled=false}
  });
  actions.append(play,fav);card.append(thumb,title,meta,actions);list.append(card);
 }
 const more=$('v712MoreArea');more.replaceChildren();
 if(entries.length>v712.limit){const b=document.createElement('button');b.textContent=`Show next ${Math.min(100,entries.length-v712.limit)} animations`;b.addEventListener('click',()=>{v712.limit+=100;v712Render()});more.append(b)}
 v713UpdateControls();
}

// V7.13: never present stick figures as animation thumbnails.
// Render thumbnails from the user's *actual* current 3D character, on demand.
// Retargeted motions may take time to attach; generation is batched and cancelable.
function v713UpdateControls(){
 const rename=$('v713Rename'),render=$('v713Generate'),cancel=$('v713Cancel');
 if(!rename||!render||!cancel)return;
 rename.disabled=!v712.groups.some(g=>g.id===v712.folder)||v713.generating;
 render.disabled=v713.generating||!state.loaded||!state.rigInfo?.skinnedMeshes;
 cancel.hidden=!v713.generating;
 const missing=v712Entries().filter(m=>!v714.frames.has(m.key)).length;
 render.textContent='▶ Generate moving previews (next '+Math.min(8,missing)+')';
 if(!missing)render.disabled=true;
}
async function v713AttachForPreview(m){
 if(m.source==='loaded'){
  const clip=state.clips[m.index]||state.clips.find(c=>c.name===m.label);
  if(!clip)throw new Error('This animation is no longer loaded.');
  chooseClip(clip);return;
 }
 if(m.source==='library'){
  await v72Attach(m.packId,m.clipIndex);
  if(!v74GetAttached(m.packId,m.clipIndex))throw new Error(v72Library.lastAttachError||('Rig not compatible with '+m.label));
  return;
 }
 throw new Error('No saved animation clip is available for preview');
}
function v713CaptureFrame(m){
 // Apply the motion at a point away from the potentially unstable opening pose.
 const seconds=currentPeriod();state.playing=false;
 state.time=Math.max(0,seconds*.37);
 updateAnimation(state.time);
 v7RenderScene();
 const src=renderer.domElement;
 const target=document.createElement('canvas');target.width=220;target.height=165;
 const ctx=target.getContext('2d');
 // Capture actual rendered model. No synthetic poses or stick-figure fallback.
 ctx.drawImage(src,0,0,target.width,target.height);
 const pixels=ctx.getImageData(0,0,target.width,target.height).data;
 let visible=false;for(let i=3;i<pixels.length;i+=16){if(pixels[i]>8){visible=true;break}}
 if(!visible)throw new Error('3D preview is blank for '+m.label);
 return target.toDataURL('image/png');
}
async function v713Generate(){
 if(v713.generating)return;
 if(!state.loaded||!state.rigInfo?.skinnedMeshes){$('v712Status').textContent='Load a rigged 3D character before generating previews.';return}
 const selected=v712Entries().filter(m=>!v712.images.has(m.key)).slice(0,12);
 if(!selected.length){$('v712Status').textContent='This folder already has its available previews.';return}
 v713.generating=true;v713.cancel=false;v713.activeGeneration++;
 const original={clip:state.clips.find(c=>state.selection==='clip::'+c.name),time:state.time,playing:state.playing,dir:state.dir};
 let done=0,errors=[];
 v713UpdateControls();
 try{
  for(const m of selected){
   if(v713.cancel)break;
   $('v712Status').textContent='Generating real character preview '+(done+1)+'/'+selected.length+': '+m.label;
   await v713AttachForPreview(m);
   await new Promise(resolve=>requestAnimationFrame(resolve));
   try{const image=v713CaptureFrame(m);
    if(v712.images.size>=250)v712.images.delete(v712.images.keys().next().value);
    v712.images.set(m.key,image);
   }catch(e){errors.push(m.label+': '+e.message)}
   done++;
   // Yield to the UI between previews and let the user cancel.
   if(!$('v712Gallery').hidden)v712Render();
   await new Promise(resolve=>setTimeout(resolve,0));
  }
 }catch(e){errors.push(e.message||String(e))}
 finally{
  try{if(original.clip&&state.clips.includes(original.clip)){
   chooseClip(original.clip);state.time=original.time;updateAnimation(original.time);state.playing=original.playing;
   $('playBtn').textContent=original.playing?'❚❚ Pause':'▶ Play';
  }setDirection(original.dir);updateProgressUI();}catch(e){errors.push('Restore playback: '+e.message)}
  v713.generating=false;v713UpdateControls();
  $('v712Status').textContent=(v713.cancel?'Stopped. ':'')+'Processed '+done+' animation(s), '+(done-errors.length)+' preview(s) captured.'+(errors.length?' Some clips could not be rendered: '+errors.slice(0,2).join(' | '):'');
  if(!$('v712Gallery').hidden)v712Render();
 }
}
(function v713Init(){
 $('v713Rename').addEventListener('click',()=>{
  const group=v712.groups.find(g=>g.id===v712.folder);if(!group)return;
  const name=prompt('Enter a name for this imported animation pack:',group.title);
  if(!name||!name.trim())return;
  v712.names.set(group.id,name.trim().slice(0,90));
  try{localStorage.setItem('coremotion-v712-folder-names',JSON.stringify([...v712.names]))}catch{}
  v712Render();
 });
 $('v713Generate').addEventListener('click',v713Generate);
 $('v713Cancel').addEventListener('click',()=>{v713.cancel=true;$('v712Status').textContent='Stopping after current animation…'});
})();

(function v712Init(){
 $('v712OpenGallery').addEventListener('click',()=>{v712.lastFocus=document.activeElement;v712.folder='all';v712.limit=100;$('v712Gallery').hidden=false;v712Render();$('v712Search').focus()});
 const close=()=>{$('v712Gallery').hidden=true;v712.lastFocus?.focus?.()};
 $('v712Close').addEventListener('click',close);
 $('v712Gallery').addEventListener('pointerdown',e=>{if(e.target===$('v712Gallery'))close()});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('v712Gallery').hidden)close()});
 $('v712Search').addEventListener('input',()=>{v712.limit=100;v712Render()});
 $('v712Category').addEventListener('change',()=>{v712.limit=100;v712Render()});
 $('v712Import').addEventListener('click',()=>{$('v72MotionPacks').open=true;$('v72Files').click()});
 const previous=v72RenderPacks;
 v72RenderPacks=function(...args){previous(...args);if(!$('v712Gallery').hidden)v712Render()};
})();


// V7.14 — Animated gallery previews (on-demand, generated from real model motion).
// All preview frames are sampled from the existing, verified retargeted animation.
// No procedural stand-ins, stock animations or fake preview videos.
const v714={frames:new Map(),busy:false,active:null,timer:null,pending:new Set(),model:null};
function v714Stop(){if(v714.timer){clearInterval(v714.timer);v714.timer=null}v714.active=null;v717HideZoom()}
function v714Start(card,key){
 v714Stop();const frames=v714.frames.get(key);
 if(!frames?.length)return;
 const im=card.querySelector('.v712Thumb img');if(!im)return;
 let frame=0;im.src=frames[0];v714.active=key;v717ZoomFrame(key,frames[0]);
 v714.timer=setInterval(()=>{
  if(v714.active!==key||!card.isConnected){v714Stop();return}
  im.src=frames[(++frame)%frames.length];v717ZoomFrame(key,im.src);
 },85);
}
function v714VisibleThumb(m,card){
 const frames=v714.frames.get(m.key);if(!frames?.length)return;
 const thumb=card.querySelector('.v712Thumb');if(!thumb)return;
 thumb.replaceChildren();const img=new Image();img.src=frames[0];img.alt='Real looping 3D animation preview: '+m.label;thumb.append(img);
 const badge=document.createElement('span');badge.className='v712Tag';badge.textContent='Hover to animate';thumb.append(badge);
}
async function v714MakeFrames(m){
 if(v714.frames.has(m.key))return true;
 if(v714.busy||!state.loaded||!state.rigInfo?.skinnedMeshes)return false;
 v714.busy=true;
 const previous={clip:state.clips.find(c=>state.selection==='clip::'+c.name),time:state.time,playing:state.playing,dir:state.dir};
 try{
  $('v712Status').textContent='Building moving preview of '+m.label+' from your actual 3D character…';
  await v713AttachForPreview(m);
  const seconds=currentPeriod(),frames=[];
  state.playing=false;
  for(let i=0;i<16;i++){
   state.time=seconds*i/16;updateAnimation(state.time);v7RenderScene();
   const canvas=document.createElement('canvas');canvas.width=192;canvas.height=152;
   canvas.getContext('2d').drawImage(renderer.domElement,0,0,192,152);
   frames.push(canvas.toDataURL('image/png'));
   if(i%4===3)await new Promise(resolve=>setTimeout(resolve,0));
  }
  if(v714.frames.size>=24)v714.frames.delete(v714.frames.keys().next().value);
  v714.frames.set(m.key,frames);
  $('v712Status').textContent='Moving preview ready: '+m.label+'. Hover over its card to watch.';
  return true;
 }catch(e){$('v712Status').textContent='Preview not available: '+(e?.message||e)+'. Check the compatibility report.';return false}
 finally{
  try{if(previous.clip&&state.clips.includes(previous.clip)){chooseClip(previous.clip);state.time=previous.time;updateAnimation(previous.time)}
   setDirection(previous.dir);state.playing=previous.playing;
   $('playBtn').textContent=previous.playing?'❚❚ Pause':'▶ Play';updateProgressUI();
  }catch(e){console.warn('Preview restore:',e)}
  v714.busy=false;
 }
}
// Wrap the existing gallery render so every card uses the real animated frame
// cache. A card loads its frames the first time the user hovers or focuses it.
const v714OriginalRender=v712Render;
v712Render=function(...args){
 v714Stop();if(v714.model!==state.model){v714.frames.clear();v714.model=state.model;}
 v714OriginalRender(...args);
 const entries=v712Entries().slice(0,v712.limit);
 const cards=[...$('v712Cards').children];
 for(let i=0;i<cards.length;i++){
  const card=cards[i],m=entries[i];if(!m)continue;
  v714VisibleThumb(m,card);
  const hover=async()=>{
   v717ShowZoom(card,m);
   if(v714.frames.has(m.key)){v714Start(card,m.key);v717ShowZoom(card,m);v717ZoomFrame(m.key,v714.frames.get(m.key)[0]);return}
   if(v714.busy||v714.pending.has(m.key)||v716.batch)return;
   v714.pending.add(m.key);
   const stillHere=()=>card.isConnected && card.matches(':hover');
   try{const ok=await v714MakeFrames(m);
    if(ok&&card.isConnected){v714VisibleThumb(m,card);if(stillHere()){v714Start(card,m.key);v717ShowZoom(card,m);v717ZoomFrame(m.key,v714.frames.get(m.key)[0])}}
   }finally{v714.pending.delete(m.key)}
  };
  card.addEventListener('pointerenter',hover);
  card.addEventListener('pointerleave',()=>{v717HideZoom();if(v714.active===m.key)v714Stop()});
  card.addEventListener('focusin',hover);
  card.addEventListener('focusout',()=>{v717HideZoom();if(v714.active===m.key)v714Stop()});
 }
};
// Stop previews if the gallery is closed or the character changes.
$('v712Close').addEventListener('click',v714Stop);


// V7.17: true hover magnifier. Portal outside the scroll-clipped gallery.
const v717Zoom={root:null,img:null,caption:null,key:null};
function v717HideZoom(){if(v717Zoom.root)v717Zoom.root.hidden=true;v717Zoom.key=null}
function v717EnsureZoom(){
 if(v717Zoom.root)return;
 const pane=document.createElement('div');pane.className='v717Zoom';pane.hidden=true;
 pane.setAttribute('aria-hidden','true');
 const img=new Image();img.alt='Enlarged animation preview';
 const caption=document.createElement('div');caption.className='v717ZoomLabel';
 pane.append(img,caption);document.body.append(pane);
 v717Zoom.root=pane;v717Zoom.img=img;v717Zoom.caption=caption;
}
function v717ShowZoom(card,m){
 v717EnsureZoom();const r=card.getBoundingClientRect();
 const width=Math.min(380,Math.max(240,window.innerWidth*.25));
 const height=Math.min(380,Math.max(275,window.innerHeight*.47));
 const x=r.right+width+12<window.innerWidth?r.right+10:Math.max(8,r.left-width-10);
 const y=Math.max(8,Math.min(r.top,window.innerHeight-height-12));
 Object.assign(v717Zoom.root.style,{left:Math.round(x)+'px',top:Math.round(y)+'px',width:Math.round(width)+'px',height:Math.round(height)+'px'});
 v717Zoom.key=m.key;v717Zoom.caption.textContent=m.label+' · '+(v714.frames.has(m.key)?'Live motion':'Generating live motion…');
 const frames=v714.frames.get(m.key),image=v712.images.get(m.key);
 v717Zoom.img.style.display=frames?.length||image?'block':'none';
 if(frames?.length)v717Zoom.img.src=frames[0];else if(image)v717Zoom.img.src=image;
 v717Zoom.root.hidden=false;
}
function v717ZoomFrame(key,src){
 if(v717Zoom.key!==key||!v717Zoom.root||v717Zoom.root.hidden)return;
 v717Zoom.img.style.display='block';v717Zoom.img.src=src;
 v717Zoom.caption.textContent='Playing real animation · Hover to inspect';
}
$('v712Close').addEventListener('click',v717HideZoom);
// V7.16 — Batch REAL animated thumbnails and stable hover gallery.
// Motion data comes exclusively from already imported, successfully retargeted clips.
// No procedural motion is substituted. All frames belong to the loaded character.
const v716={batch:false,cancel:false,generated:0};
async function v716BuildMotionPreviewBatch(){
 if(v716.batch)return;
 if(!state.loaded||!state.rigInfo?.skinnedMeshes){$('v712Status').textContent='Load a rigged character before generating moving previews.';return;}
 if(v714.busy){$('v712Status').textContent='Another preview is being prepared. Try again when it finishes.';return;}
 const available=v712Entries().filter(m=>!v714.frames.has(m.key)).slice(0,8);
 if(!available.length){$('v712Status').textContent='All visible animations already have moving previews.';return;}
 v716.batch=true;v716.cancel=false;
 const button=$('v713Generate'),stop=$('v713Cancel');
 button.disabled=true;stop.hidden=false;
 const originalModel=state.model;
 let success=0,errors=0;
 try{
  for(let i=0;i<available.length;i++){
   if(v716.cancel||state.model!==originalModel||$('v712Gallery').hidden)break;
   const m=available[i];
   $('v712Status').textContent='Rendering real animation '+(i+1)+'/'+available.length+': '+m.label;
   const ok=await v714MakeFrames(m);
   if(ok)success++;else errors++;
   if(!$('v712Gallery').hidden)v712Render();
   await new Promise(resolve=>setTimeout(resolve,0));
  }
 }finally{
  v716.batch=false;
  stop.hidden=true;
  v713UpdateControls();
  $('v712Status').textContent=(v716.cancel?'Preview generation stopped. ':'')+
   success+' moving previews generated'+(errors?' · '+errors+' unavailable':'')+'. Hover over a card to watch its real motion.';
 }
}
$('v713Generate').addEventListener('click',e=>{
 e.preventDefault();e.stopImmediatePropagation();v716BuildMotionPreviewBatch();
},true);
$('v713Cancel').addEventListener('click',()=>{v716.cancel=true},true);
// Model-specific thumbnail images must never be shown as another character.
const v716OriginalClear=clearModel;
clearModel=function(...args){v714Stop();v714.frames.clear();v712.images.clear();v714.model=null;return v716OriginalClear(...args)};


// V7.22 — Focused workspaces. Existing section nodes are moved (not cloned),
// keeping all original event listeners, animation state and export tools intact.
(function v722Workspaces(){
 function init(){
  const right=document.querySelector('.sidebar.right');
  const art=document.getElementById('v71StylesSection');
  const animation=document.getElementById('v71AnimationsSection');
  const ai=document.getElementById('v78Director');
  const exportSection=document.getElementById('v71ExportSection');
  if(!right||!art||!animation||!ai||!exportSection||document.getElementById('v722Tabs'))return;
  const tabs=document.createElement('nav');tabs.id='v722Tabs';tabs.className='v722Tabs';tabs.setAttribute('aria-label','CoreMotion workspaces');
  const defs=[['character','Character'],['animations','Animations'],['ai','AI Director'],['export','Export']];
  const panels=new Map();
  for(const [key,label] of defs){
   const button=document.createElement('button');button.type='button';button.dataset.v722Tab=key;button.textContent=label;
   button.setAttribute('aria-controls','v722Panel-'+key);tabs.append(button);
   const pane=document.createElement('div');pane.id='v722Panel-'+key;pane.className='v722Pane';pane.setAttribute('role','region');pane.setAttribute('aria-label',label+' tools');
   panels.set(key,pane);
  }
  right.insertBefore(tabs,right.firstChild);
  for(const pane of panels.values())right.append(pane);
  panels.get('character').append(art);
  panels.get('animations').append(animation);
  const aiHeader=document.createElement('div');aiHeader.className='v722PaneIntro';
  aiHeader.innerHTML='<strong>Animate with instructions</strong><span>Select a working animation, then describe a motion style. The local AI uses Ollama; offline prompting is a separate rule-based fallback.</span>';
  panels.get('ai').append(aiHeader,ai);
  panels.get('export').append(exportSection);
  // Other legacy tools keep their original DOM objects and are grouped
  // with their original sections; the export/info footer remains accessible.
  const extra=[...right.children].filter(n=>n!==tabs && ![...panels.values()].includes(n));
  for(const node of extra){if(node.classList?.contains('note'))panels.get('export').append(node);else panels.get('character').append(node)}
  const status=document.createElement('div');status.className='v722ActiveMotion';status.id='v722ActiveMotion';
  tabs.after(status);
  const updateStatus=()=>{
   const clip=state.selection?.startsWith('clip::')?state.selection.slice(6):null;
   status.textContent=clip?'Active animation: '+clip:'No animation selected · choose a working motion in Animations';
  };
  const apply=(key,save=true)=>{
   if(!panels.has(key))key='animations';
   for(const [k,p] of panels){p.hidden=k!==key}
   tabs.querySelectorAll('button').forEach(b=>{const active=b.dataset.v722Tab===key;b.classList.toggle('active',active);b.setAttribute('aria-current',active?'page':'false')});
   updateStatus();if(save)try{localStorage.setItem('coremotion-v722-tab',key)}catch{}
   right.scrollTop=0;
  };
  tabs.addEventListener('click',e=>{const b=e.target.closest('button[data-v722-tab]');if(b)apply(b.dataset.v722Tab)});
  const requested=(()=>{try{return localStorage.getItem('coremotion-v722-tab')}catch{return null}})();
  apply(requested||'animations',false);
  // Refresh the active-clip indicator when the user selects another animation.
  right.addEventListener('click',()=>queueMicrotask(updateStatus));
  document.addEventListener('coremotion-animation-selected',updateStatus);
  const galleryBtn=document.getElementById('v712OpenGallery');
  if(galleryBtn){const intro=document.createElement('p');intro.className='v722Hint';intro.textContent='Browse, preview and apply your existing working animation clips here.';galleryBtn.before(intro)}
  // Clearer AI states and examples, without claiming the offline interpreter is AI.
  const prompt=document.getElementById('v78Prompt');const ask=document.getElementById('v78Ask');
  if(prompt && ask){
   const examples=document.createElement('div');examples.className='v722Examples';
   examples.innerHTML='<span>Try a prompt:</span>';
   for(const value of ['Make this punch more powerful','Give this idle a relaxed personality','Add more swagger and shoulder movement']){
    const b=document.createElement('button');b.type='button';b.textContent=value;b.addEventListener('click',()=>{prompt.value=value;prompt.focus()});examples.append(b);
   }
   prompt.after(examples);
   const offline=document.createElement('button');offline.type='button';offline.id='v722Offline';offline.textContent='Apply prompt offline (rules)';
   ask.after(offline);
   const info=document.createElement('div');info.className='v722OfflineNote';
   info.textContent='Offline mode matches familiar motion words to bounded style controls; it is not generative AI. For natural-language AI interpretation, click Check AI and connect Ollama.';
   offline.parentElement.after(info);
   const interpret=(sentence)=>{
    const s=sentence.toLowerCase();let p={...v78State.values};const matched=[];
    const set=(partial,label)=>{p={...p,...partial};matched.push(label)};
    if(/swag|swagger|strut|confiden|attitude|cool/.test(s))set({...V78_PRESETS.swag},'swagger');
    if(/hero|proud|bold|commanding/.test(s))set({...V78_PRESETS.heroic},'heroic');
    if(/sneak|stealth|quiet|cautious|subtle/.test(s))set({...V78_PRESETS.sneaky},'subtle');
    if(/punch|power|strong|impact|aggress|heavy|dramatic|exaggerat/.test(s))set({...V78_PRESETS.punchy},'impact');
    if(/relax|casual|natural|gentle|soft|calm/.test(s))set({armSwing:.14,hipSway:.08,shoulderRoll:.08,armWidth:.02,lean:0,bounce:.04,exaggeration:.06},'relaxed');
    if(/more arm|arm swing|swing.*arm/.test(s))set({armSwing:Math.min(1,p.armSwing+.25)},'arm swing');
    if(/shoulder/.test(s))set({shoulderRoll:Math.min(1,p.shoulderRoll+.24)},'shoulders');
    if(/hip|sway/.test(s))set({hipSway:Math.min(1,p.hipSway+.20)},'hips');
    if(/lean forward|lean in/.test(s))set({lean:.40},'forward lean');
    if(/lean back/.test(s))set({lean:-.30},'backward lean');
    if(/bounce|bouncy/.test(s))set({bounce:Math.min(1,p.bounce+.3)},'bounce');
    if(/subtle|less exaggerat|tone down|reduce/.test(s))set({exaggeration:Math.min(p.exaggeration,.10),armWidth:Math.min(p.armWidth,.07)},'restrained');
    if(/no bounce|without bounce/.test(s))set({bounce:0},'no bounce');
    if(/no arm swing|without arm swing/.test(s))set({armSwing:0},'no arm swing');
    if(/no t.pose|arms (down|close)|keep arms relaxed/.test(s))set({armWidth:0},'neutral arm width');
    return {profile:v78Bounded(p),matched};
   };
   offline.addEventListener('click',()=>{
    if(!v78Key()){v78Message('Load a character and choose a working animation first.',true);return}
    const sentence=prompt.value.trim();if(!sentence){v78Message('Describe a movement style first.',true);prompt.focus();return}
    const result=interpret(sentence);
    if(!result.matched.length){v78Message('Offline rules do not recognize this instruction. Use Ollama AI for more flexible interpretation, or adjust sliders manually.',true);return}
    v78SetProfile(result.profile,'Offline prompt applied ('+result.matched.join(', ')+'). This changes motion style controls, not the original animation.');
   });
  }
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();


// V7.23 — REAL GENERATION PATH. No slider fallback, prerecorded clip or fake success.
// Connect to the companion local MDM service which executes actual diffusion inference.
(function v723RealGeneration(){
 const API='http://127.0.0.1:8765';
 const hml22={hips:[0,3],leftthigh:[1,4],rightthigh:[2,5],spine1:[3,6],leftshin:[4,7],rightshin:[5,8],spine2:[6,9],leftfoot:[7,10],rightfoot:[8,11],spine3:[9,12],neck:[12,15],leftshoulder:[13,16],rightshoulder:[14,17],leftupperarm:[16,18],rightupperarm:[17,19],leftforearm:[18,20],rightforearm:[19,21]};
 const depth=b=>{let d=0;while(b?.parent?.isBone&&d<80){d++;b=b.parent}return d};
 function roles(){
  const named=new Map();
  const auto=v74CurrentAutoMap()?.named;
  if(auto)for(const [key,bone] of auto)named.set(key,bone);
  for(const bone of v7AllBones()){const role=v72Canon(bone.name);if(!named.has(role))named.set(role,bone)}
  return named;
 }
 function buildClip(xyz,prompt){
  if(!state.loaded||!state.rigInfo?.skinnedMeshes)throw Error('Load a rigged humanoid character before generating.');
  const frames=xyz.frames;
  if(!Array.isArray(frames)||frames.length<2||frames.length>500||frames.some(f=>!Array.isArray(f)||f.length!==22))throw Error('AI service returned an invalid 22-joint motion.');
  const fps=Number(xyz.fps)||20;
  if(fps<1||fps>120)throw Error('Unsupported motion framerate');
  const named=roles(), rest=v72Library.targetRest;
  const pairs=Object.entries(hml22).map(([role,indices])=>({role,bone:named.get(role),indices})).filter(p=>p.bone&&rest.has(p.bone.name));
  const core=['hips','spine1','leftupperarm','rightupperarm','leftthigh','rightthigh','leftshin','rightshin'];
  const missing=core.filter(r=>!pairs.find(p=>p.role===r));
  if(missing.length)throw Error('Character is missing needed humanoid joints: '+missing.join(', ')+'. Automatic rigging is not available in this update.');
  pairs.sort((a,b)=>depth(a.bone)-depth(b.bone));
  const tracksData=new Map(pairs.map(p=>[p.bone,[]]));
  let valid=0;
  const getPoint=(frame,i)=>{
   const p=frame[i];if(!Array.isArray(p)||p.length!==3||p.some(x=>!Number.isFinite(x)))throw Error('AI output contains invalid coordinates');
   return new THREE.Vector3(p[0],p[1],p[2]);
  };
  for(const frame of frames){
   const solved=new Map();
   for(const {bone,indices,role} of pairs){
    const bind=rest.get(bone.name);
    const dir=getPoint(frame,indices[1]).sub(getPoint(frame,indices[0]));
    if(dir.lengthSq()<1e-9)throw Error('AI generated a zero-length '+role+' limb segment');
    dir.normalize();
    // A world-space direction drives each limb. This is pose generation from
    // inferred xyz, not an offset layered on a previously imported animation.
    const child=pairs.find(p=>p.indices[0]===indices[1]);
    const targetTail=child?.bone.getWorldPosition(new THREE.Vector3())||null;
    const base=bind.worldPosition;
    // The next bone's position in the target neutral pose gives its true axis.
    const baseDir=targetTail?.clone().sub(base)||new THREE.Vector3(0,1,0);
    if(baseDir.lengthSq()<1e-9)baseDir.set(0,1,0);
    baseDir.normalize();
    const qDelta=new THREE.Quaternion().setFromUnitVectors(baseDir,dir);
    const desired=qDelta.multiply(bind.worldQuaternion.clone()).normalize();
    const parent=bone.parent;
    const parentWorld=parent?.isBone && solved.has(parent)?solved.get(parent):
      (parent?.isBone&&rest.has(parent.name)?rest.get(parent.name).worldQuaternion:
       parent?.getWorldQuaternion(new THREE.Quaternion())||new THREE.Quaternion());
    const local=parentWorld.clone().invert().multiply(desired).normalize();
    solved.set(bone,desired);
    tracksData.get(bone).push(...local.toArray());
    if(role==='leftupperarm')valid++;
   }
  }
  if(valid<2)throw Error('No generated pose samples were produced');
  const times=frames.map((_,i)=>i/fps);
  const tracks=pairs.map(({bone})=>new THREE.QuaternionKeyframeTrack(bone.name+'.quaternion',times,tracksData.get(bone)));
  const name=v72UniqueClipName('AI Generated · '+prompt.slice(0,48));
  const clip=new THREE.AnimationClip(name,times.at(-1),tracks);
  clip.userData={generator:'MDM',prompt,source:'Independent AI-generated 22-joint motion'};
  return clip;
 }
 async function request(path,init={},timeout=15000){
  const c=new AbortController();const timeoutId=setTimeout(()=>c.abort(),timeout);
  try{const response=await fetch(API+path,{...init,signal:c.signal,cache:'no-store'});
   const data=await response.json();if(!response.ok)throw Error(data.error||data.detail||'AI model error');return data;
  }finally{clearTimeout(timeoutId)}
 }
 function init(){
  const nav=document.getElementById('v722Tabs');const right=document.querySelector('.sidebar.right');
  const oldPane=document.getElementById('v722Panel-animations');
  if(!nav||!right||!oldPane||document.getElementById('v723GeneratePane'))return;
  const tab=document.createElement('button');tab.type='button';tab.textContent='✦ Generate';tab.dataset.v722Tab='generate';
  nav.prepend(tab);
  const pane=document.createElement('section');pane.id='v723GeneratePane';pane.className='v722Pane v723GenPane';
  pane.innerHTML=`<h2>Generate new motion with AI</h2>
   <p>Uses a real pretrained Motion Diffusion Model. Does not alter sliders or reuse animation clips.</p>
   <label for="v723Prompt">Describe an entirely new animation</label>
   <textarea id="v723Prompt" rows="4" maxlength="300" placeholder="A person performs a spinning kick and lands in a fighting stance"></textarea>
   <label for="v723Seconds">Length</label>
   <select id="v723Seconds"><option value="2">2 seconds</option><option value="3" selected>3 seconds</option><option value="4">4 seconds</option><option value="5">5 seconds</option></select>
   <div class="v723Actions"><button type="button" id="v723Check">Check AI model</button><button type="button" id="v723Generate" class="primary">✦ Generate new animation</button></div>
   <div id="v723Status" class="v723Status" role="status" aria-live="polite">Connect a pretrained MDM model to generate new motion.</div>
   <details><summary>Model setup (required once)</summary>
    <p>Download the separate CoreMotion MDM Bridge kit. Install the official pretrained Motion Diffusion Model, configure its checkpoint, and start the local bridge.</p>
    <p>The model does not come with this tiny GitHub update. Without installed AI weights, generation will not run.</p>
   </details>
   <details><summary>Advanced note</summary><p>This generates 22-joint motion from text and estimates humanoid bone rotations. Different custom rigs may need correction. It does not create or rig 3D characters from an image yet.</p></details>`;
  nav.after(pane);
  const others=[...right.querySelectorAll('.v722Pane')].filter(p=>p!==pane);
  const status=pane.querySelector('#v723Status');const output=(msg,err=false)=>{status.textContent=msg;status.classList.toggle('error',err)};
  const switchTo=()=>{
   for(const p of others)p.hidden=true;
   pane.hidden=false;
   nav.querySelectorAll('button').forEach(b=>b.classList.toggle('active',b===tab));
   right.scrollTop=0;
  };
  tab.addEventListener('click',e=>{e.stopPropagation();switchTo()});
  // Original workspace click handler controls only the original panels.
  for(const b of nav.querySelectorAll('button:not([data-v722-tab="generate"])')){
    b.addEventListener('click',()=>{pane.hidden=true});
  }
  // Generative workflow first, manual tools remain accessible behind other tabs.
  switchTo();
  const check=pane.querySelector('#v723Check'),go=pane.querySelector('#v723Generate');
  check.addEventListener('click',async()=>{
   output('Checking local AI model…');
   try{const s=await request('/status');
     output(s.ready?'MDM is ready. Load a rigged character and generate a new motion.':'Model not ready: '+s.issues.join(' '),!s.ready);
   }catch(e){output('AI model service is offline. Start the separate MDM Bridge kit first. '+e.message,true)}
  });
  go.addEventListener('click',async()=>{
   if(go.disabled)return;
   if(!state.loaded||!state.rigInfo?.skinnedMeshes){output('Load a rigged humanoid character first. A static image or unrigged mesh cannot accept bone animation.',true);return}
   const prompt=pane.querySelector('#v723Prompt').value.trim();
   if(prompt.length<3){output('Describe the animation you want to generate.',true);return}
   go.disabled=true;check.disabled=true;output('Running actual text-to-motion diffusion inference. This may take a while…');
   try{
    const data=await request('/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt,seconds:Number(pane.querySelector('#v723Seconds').value)})},620000);
    const clip=buildClip(data,prompt);
    state.clips.push(clip);
    if(!state.mixer)state.mixer=new THREE.AnimationMixer(state.model);
    refreshClipUI();updatePipelineUI();chooseClip(clip);
    output('Generated '+data.frames.length+' unique AI motion frames using '+data.generatedBy+'. New playable clip: '+clip.name+'.');
   }catch(e){output('Generation not completed: '+e.message,true)}
   finally{go.disabled=false;check.disabled=false}
  });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();

// V7.24: Local automatic humanoid rigging. Actual mesh-to-bone skinning in Blender.
// No fake generative AI claims: geometry-based fitting, NOT a neural model.


// V7.24.4: Integrate automatic geometry-based rigging with EXISTING image → 3D → loadModel workflow.
// No additional uploader, separate service, or sidebar. Already-skinned models remain unchanged.
function v724FitAndSkin(root){
  root.updateMatrixWorld(true);
  const meshes=[];const bounds=new THREE.Box3();let totalVertices=0;
  root.traverse(o=>{if(!o.isMesh||!o.geometry?.attributes?.position)return;
   if(o.isSkinnedMesh)throw new Error('This model already has skinning; use the normal character loader.');
   const n=o.geometry.attributes.position.count;
   if(n<3)return;
   totalVertices+=n;meshes.push(o);bounds.expandByObject(o);
  });
  if(!meshes.length)throw Error('No triangle meshes were found. Upload an unrigged 3D humanoid GLB.');
  if(totalVertices>350000)throw Error('Mesh too detailed for browser rigging ('+totalVertices+' vertices). Simplify the model to 350,000 vertices or less.');
  if(totalVertices<80)throw Error('Too few vertices to identify a humanoid.');
  const min=bounds.min,max=bounds.max;
  const dims=bounds.getSize(new THREE.Vector3()),height=dims.y,width=dims.x,depth=dims.z;
  if(!Number.isFinite(height)||height<.05)throw Error('Model must stand upright on the Y axis. Invalid geometry height.');
  const ratio=width/height;
  if(ratio<.21||ratio>1.65)throw Error('Body width/height ratio '+ratio.toFixed(2)+' is outside the supported upright humanoid range.');
  const cx=(min.x+max.x)/2,cy=min.y,cz=(min.z+max.z)/2;
  // Sample world-space mesh vertices to validate that shoulder and leg bands exist.
  // V7.24.4: measure both arm silhouettes over their actual range of heights.
  // The previous .77-height cross-section missed wrists and elbows on A-pose
  // models, leaving those vertices assigned to the chest instead of the arms.
  const shoulders=[],hips=[],shins=[],armCloud={Left:[],Right:[]};
  const point=new THREE.Vector3();
  for(const mesh of meshes){const att=mesh.geometry.attributes.position,step=Math.max(1,Math.ceil(att.count/25000));
    for(let i=0;i<att.count;i+=step){point.fromBufferAttribute(att,i).applyMatrix4(mesh.matrixWorld);
      const u=(point.y-cy)/height,x=point.x-cx;
      if(Math.abs(u-.77)<.055)shoulders.push(point.x);
      if(Math.abs(u-.52)<.055)hips.push(point.x);
      if(Math.abs(u-.19)<.055)shins.push(point.x);
      if(u>.34&&u<.93)armCloud[x<0?'Left':'Right'].push({x:Math.abs(x),y:u});
    }
  }
  if(shoulders.length<8||hips.length<8||shins.length<8)throw Error('Could not locate shoulder, hip and leg geometry. Use a standing A/T-pose humanoid.');
  function quantile(arr,q){arr.sort((a,b)=>a-b);return arr[Math.max(0,Math.min(arr.length-1,Math.floor(q*(arr.length-1))))]}
  const hipSpan=quantile(hips,.9)-quantile(hips,.1);
  const torsoHalf=Math.max(width*.085,hipSpan*.49);
  const armProfiles={};
  for(const side of ['Left','Right']){
    const cloud=armCloud[side].filter(v=>v.x>torsoHalf*1.05);
    if(cloud.length<10)throw Error(side+' arm not distinguishable from torso. Use a front-facing A- or T-pose with visible arms.');
    const tipX=Math.min(width*.52,quantile(cloud.map(v=>v.x),.96));
    if(tipX<torsoHalf*1.20)throw Error(side+' arm does not extend far enough for automatic fitting.');
    const shoulderX=Math.min(torsoHalf*1.14,tipX*.60);
    const elbowX=shoulderX+(tipX-shoulderX)*.52;
    const wristX=shoulderX+(tipX-shoulderX)*.89;
    // Estimate the central arm line at each joint from the observed mesh,
    // rather than inventing a horizontal bone regardless of its A-pose slope.
    function heightAt(x,defaultY){
      const radius=Math.max(width*.035,(tipX-shoulderX)*.12);
      const band=cloud.filter(v=>Math.abs(v.x-x)<radius);
      if(band.length<6)return defaultY;
      const ys=band.map(v=>v.y);
      return THREE.MathUtils.clamp(quantile(ys,.5),.36,.91);
    }
    const shY=heightAt(shoulderX,.79);
    const elY=heightAt(elbowX,shY-.035);
    const wrY=heightAt(wristX,elY-.027);
    armProfiles[side]={shoulderX,elbowX,wristX,tipX,shY,elY,wrY};
  }
  const legX=Math.max(width*.065,Math.min(hipSpan*.27,width*.165));
  const at=(x,h,z=0)=>new THREE.Vector3(cx+x,cy+height*h,cz+z);
  const definitions=[
   ['Hips',null,at(0,.53),at(0,.58)],
   ['Spine','Hips',at(0,.58),at(0,.69)],
   ['Spine1','Spine',at(0,.69),at(0,.78)],
   ['Spine2','Spine1',at(0,.78),at(0,.855)],
   ['Neck','Spine2',at(0,.855),at(0,.91)],
   ['Head','Neck',at(0,.91),at(0,.99)]
  ];
  for(const [side,s] of [['Left',-1],['Right',1]]){
    const a=armProfiles[side];
    definitions.push(
      [side+'Shoulder','Spine2',at(s*a.shoulderX*.72,.80),at(s*a.shoulderX,a.shY)],
      [side+'Arm',side+'Shoulder',at(s*a.shoulderX,a.shY),at(s*a.elbowX,a.elY)],
      [side+'ForeArm',side+'Arm',at(s*a.elbowX,a.elY),at(s*a.wristX,a.wrY)],
      [side+'Hand',side+'ForeArm',at(s*a.wristX,a.wrY),at(s*a.tipX,a.wrY-.012)],
      [side+'UpLeg','Hips',at(s*legX,.53),at(s*legX*1.08,.285)],
      [side+'Leg',side+'UpLeg',at(s*legX*1.08,.285),at(s*legX*1.08,.075)],
      [side+'Foot',side+'Leg',at(s*legX*1.08,.075),at(s*legX*1.08,.038,-depth*.28)],
      [side+'ToeBase',side+'Foot',at(s*legX*1.08,.038,-depth*.28),at(s*legX*1.08,.035,-depth*.44)]
    );
  }
  const output=new THREE.Group();output.name='CoreMotion_AutoRig';
  const named=new Map(),segments=[];
  for(const [name,parent,head,tail] of definitions){
    const b=new THREE.Bone();b.name=name;named.set(name,b);segments.push({name,head,tail,parent});
    const parentHead=parent?segments.find(x=>x.name===parent)?.head:null;
    b.position.copy(head).sub(parentHead||new THREE.Vector3());
    if(parent)named.get(parent).add(b);else output.add(b);
  }
  output.updateMatrixWorld(true);
  const skeleton=new THREE.Skeleton(definitions.map(d=>named.get(d[0])));
  const names=definitions.map(d=>d[0]);let converted=0;
  const materials=[];
  for(const obj of meshes){
    const geo=obj.geometry.clone();geo.applyMatrix4(obj.matrixWorld);
    const position=geo.getAttribute('position');
    const indices=new Uint16Array(position.count*4),weights=new Float32Array(position.count*4);
    const p=new THREE.Vector3(),segDir=new THREE.Vector3(),near=new THREE.Vector3();
    for(let i=0;i<position.count;i++){
      p.fromBufferAttribute(position,i);
      const u=(p.y-cy)/height,ax=Math.abs(p.x-cx);
      // Shoulder seam gets a soft blend between upper arm and chest. The old
      // fixed y>.67 gate incorrectly classified lowered arms as torso skin.
      const side=p.x<cx?'Left':'Right',profile=armProfiles[side];
      // v7.24.5: wrists on A-pose characters can sit below the waist.
      // Use the fitted arm centerline rather than a horizontal shoulder-height gate.
      const nearArmLine=(sx,sy,ex,ey)=>{
        const vx=ex-sx,vy=(ey-sy)*height;
        const px=ax-sx,py=(u-sy)*height;
        const t=THREE.MathUtils.clamp((px*vx+py*vy)/Math.max(1e-8,vx*vx+vy*vy),0,1);
        return Math.hypot(px-t*vx,py-t*vy);
      };
      const armLineDist=Math.min(
        nearArmLine(profile.shoulderX,profile.shY,profile.elbowX,profile.elY),
        nearArmLine(profile.elbowX,profile.elY,profile.wristX,profile.wrY),
        nearArmLine(profile.wristX,profile.wrY,profile.tipX,profile.wrY-.012));
      const farOut=ax>Math.max(torsoHalf*1.10,profile.shoulderX+(profile.elbowX-profile.shoulderX)*.12);
      const armRadius=Math.max(height*.052,width*.057);
      const armConfidence=farOut&&u>.32&&u<.93?1-THREE.MathUtils.smoothstep(armLineDist,armRadius*.40,armRadius*2.2):0;
      let region='torso';
      // No leg classification for vertices outboard of the pelvis and close to
      // an estimated forearm. This was the source of the rigid lower arms.
      if(armConfidence>.34)region='arms';
      else if(u<.48)region='legs';
      else if(u>.89&&ax<torsoHalf*1.45)region='head';
      const candidates=[];
      for(let j=0;j<segments.length;j++){
        const s=segments[j],name=s.name;
        const isArm=/Shoulder|Arm|ForeArm|Hand/.test(name),isLeg=/UpLeg|Leg|Foot|ToeBase/.test(name),isHead=/Head|Neck/.test(name);
        if(region==='arms'&&!isArm)continue;
        if(region==='arms'&&name.startsWith(side==='Left'?'Right':'Left'))continue;
        if(region==='legs'&&!isLeg&&name!=='Hips')continue;
        if(region==='head'&&!isHead&&name!=='Spine2')continue;
        if(region==='torso'&&isLeg)continue;
        segDir.copy(s.tail).sub(s.head);const denom=Math.max(1e-9,segDir.lengthSq());
        const t=THREE.MathUtils.clamp(p.clone().sub(s.head).dot(segDir)/denom,0,1);
        near.copy(s.head).addScaledVector(segDir,t);
        let d=p.distanceTo(near);
        if(name.startsWith('Left')&&p.x>cx+width*.035)d+=width;
        if(name.startsWith('Right')&&p.x<cx-width*.035)d+=width;
        // Only outboard vertices are biased toward the arm, leaving shoulder
        // seam vertices free to blend with chest and clavicle influences.
        if(region==='torso'&&isArm)d+=height*.12*(1-armConfidence);
        if(region==='torso'&&isArm&&name.startsWith(side==='Left'?'Right':'Left'))d+=width;
        if(region==='torso'&&isHead)d+=height*.10;
        candidates.push({j,d});
      }
      candidates.sort((a,b)=>a.d-b.d);
      const selected=candidates.slice(0,4);
      const unnorm=selected.map(o=>1/Math.pow(Math.max(o.d,height*.024),3.5));
      const sum=unnorm.reduce((a,b)=>a+b,0);
      for(let k=0;k<4;k++){
        indices[i*4+k]=selected[k]?.j||0;
        weights[i*4+k]=selected[k]?unnorm[k]/sum:0;
      }
    }
    geo.setAttribute('skinIndex',new THREE.Uint16BufferAttribute(indices,4));
    geo.setAttribute('skinWeight',new THREE.Float32BufferAttribute(weights,4));
    // GLTFExporter handles skinned nodes and materials; bake transforms into geometry.
    const material=obj.material;
    const skinned=new THREE.SkinnedMesh(geo,material);
    skinned.name=(obj.name||'Mesh')+'_AutoSkinned';
    skinned.frustumCulled=false;
    output.add(skinned);
    skinned.bind(skeleton);
    converted++;
  }
  if(!converted)throw Error('Rigging produced no skinned meshes.');
  output.updateMatrixWorld(true);
  // Add a genuine keyframed deformation test so users can validate mesh movement
  // before attaching unrelated motions from the library.
  const tracks=[];const times=[0,.25,.5,.75,1];
  const poses={LeftArm:[0,-.32,-.65,-.32,0],RightArm:[0,.32,.65,.32,0],LeftUpLeg:[0,.20,-.24,.20,0],RightUpLeg:[0,-.20,.24,-.20,0],LeftLeg:[0,-.12,.22,-.12,0],RightLeg:[0,.12,-.22,.12,0]};
  for(const [name,values] of Object.entries(poses)){
    const quats=[];
    for(const angle of values){const q=new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1,0,0),angle);
      if(name.endsWith('Arm'))q.setFromAxisAngle(new THREE.Vector3(0,0,1),angle);
      quats.push(q.x,q.y,q.z,q.w);
    }
    tracks.push(new THREE.QuaternionKeyframeTrack(name+'.quaternion',times,quats));
  }
  const test=new THREE.AnimationClip('Rig Test - Arm and Leg Bends',1,tracks);
  return {root:output,test,meshes:converted,bones:definitions.length,vertices:totalVertices};
 }
function v724ExportRig(root,clips){
  return new Promise((resolve,reject)=>{
   try{new GLTFExporter().parse(root,buffer=>resolve(buffer),e=>reject(e),{binary:true,animations:clips,onlyVisible:false,trs:true});}
   catch(e){reject(e)}
  });
 }
async function v724RigCurrentGeneratedScene(g,label,source){
 const original=analyzeRig(g.scene);
 if(original.skinnedMeshes)return {result:'existing-rig'};
 const beforeRotation=g.scene.rotation.clone();
 // TripoSR emits left-pointing (+X vertical) models. Correct axis BEFORE measuring torso and limbs.
 if(source==='triposr'){g.scene.rotation.z-=Math.PI/2;g.scene.updateMatrixWorld(true);}
 // For static models only: fit and skin while the source scene is still unloaded.
 // We deliberately do not run this over an existing rig, preserving assetfurnace animations.
 try{
   const model=v724FitAndSkin(g.scene);
   model.root.updateMatrixWorld(true);
   const verified=analyzeRig(model.root);
   if(verified.skinnedMeshes<1||verified.bones<15)throw Error('Automatic rig validation failed: no usable skinning.');
   g.scene=model.root;
   // Only add the explicit articulation test on newly rigged models.
   // Existing source clips are not compatible with this new skeleton.
   g.animations=[model.test];
   return {result:'created',bones:verified.bones,meshes:verified.skinnedMeshes,vertices:model.vertices};
 }catch(e){
   g.scene.rotation.copy(beforeRotation);g.scene.updateMatrixWorld(true);
   return {result:'unsupported',error:e?.message||String(e)};
 }
}
