import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
const $ = id=>document.getElementById(id);
const DIRS=['S','SW','W','NW','N','NE','E','SE'];
const PRESETS=[
 ['idle','Idle',2.4,true],['walk','Walk',0.95,true],['run','Run',0.64,true],['heavy','Heavy Walk',1.2,true],
 ['sneak','Sneak',1.5,true],['jump','Jump',1.05,false],['fall','Fall',1.0,true],['roll','Roll',0.9,false],
 ['punch','Punch',0.74,false],['kick','Kick',0.95,false],['slash','Sword Slash',0.85,false],['combo','2-Hit Combo',1.25,false],
 ['shoot','Shoot',0.68,true],['block','Guard',1.4,true],['hit','Hit Reaction',0.7,false],['death','Death',1.4,false],
 ['swim','Swim',1.2,true],['wave','Wave',1.5,true]
];
const state={file:null,cutoutFile:null,model:null,pivot:null,rig:null,mixer:null,clips:[],style:'original',preset:'idle',playing:false,speed:1,time:0,dir:'S',angle:0,zoom:1.0,frames:16,selection:'idle',loaded:false,busy:false,exporting:false,fit:null,axis:null,face:null,axisPreset:'Y',modelSource:'generic',rigInfo:null,skeletonHelper:null,facingFlip:false,calibrationKey:null};
let renderer,scene,camera,hemi,key,fill,footFloorGuide, stage=$('stage'), last=performance.now();
const speedSlider=$('speedSlider');
const motionWorkspace={key:null,favorites:new Set(),variants:[],queue:[],running:false,switching:false,steps:[],index:0,repeatNumber:1,stepStart:0,stepEnd:1,nextId:1,selectedStep:0,timeline:null,elapsed:0};
const log=(message,where='aiProgress',error=false)=>{let el=$(where);el.textContent=message;el.classList.toggle('error',error)};
const $buttons=(selector,fn)=>document.querySelectorAll(selector).forEach(b=>b.addEventListener('click',()=>fn(b)));
function setup3d(){
 renderer=new THREE.WebGLRenderer({canvas:stage,antialias:true,alpha:true,preserveDrawingBuffer:true});
 renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.outputColorSpace=THREE.SRGBColorSpace;
 renderer.setClearColor(0x000000,0); renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.35;
 scene=new THREE.Scene(); scene.background=null;
 camera=new THREE.OrthographicCamera(-3.75,3.75,3.75,-3.75,0.01,100); camera.position.set(0,1.5,10);camera.lookAt(0,1.5,0);
 hemi=new THREE.HemisphereLight(0xbddfff,0x35405f,2.3);scene.add(hemi);
 key=new THREE.DirectionalLight(0xffffff,3.0);key.position.set(-3,6,5);scene.add(key);
 fill=new THREE.DirectionalLight(0x6c9bd9,1.9);fill.position.set(4,2,-4);scene.add(fill);
 // Preview-only reference for foot calibration. Never rendered into exported sprites.
 footFloorGuide=new THREE.GridHelper(5.5,14,0x52c5dc,0x39576c);
 footFloorGuide.position.y=-0.027;footFloorGuide.visible=false;
 footFloorGuide.material.transparent=true;footFloorGuide.material.opacity=.44;
 scene.add(footFloorGuide);
 stage.addEventListener('wheel',e=>{e.preventDefault();state.zoom=Math.max(.65,Math.min(2.5,state.zoom+(e.deltaY>0?-.08:.08)));camera.zoom=state.zoom;camera.updateProjectionMatrix()},{passive:false});
 let drag=false, prev=0;stage.addEventListener('pointerdown',e=>{if(v7PointerDown(e))return;drag=true;prev=e.clientX;stage.setPointerCapture(e.pointerId)});
 stage.addEventListener('pointerup',()=>{drag=false;v7PointerUp()});stage.addEventListener('pointercancel',()=>{drag=false;v7PointerUp()});
 stage.addEventListener('pointermove',e=>{if(v7PointerMove(e))return;if(!drag||!state.pivot)return;const dx=e.clientX-prev;prev=e.clientX;state.pivot.rotation.y += dx*.012});
 window.addEventListener('resize',resizeRenderer);resizeRenderer();
 requestAnimationFrame(tick);
}
function resizeRenderer(){const box=$('sceneWrap').getBoundingClientRect();if(box.width<1||box.height<1)return;renderer.setSize(box.width,box.height,false);camera.left=-3.75*box.width/box.height;camera.right=3.75*box.width/box.height;camera.top=3.75;camera.bottom=-3.75;camera.updateProjectionMatrix()}
function tick(now){requestAnimationFrame(tick);if(state.exporting)return;const d=Math.min(.05,(now-last)/1000);last=now;
 if(state.playing){
  if(motionWorkspace.running){workspaceTick(d)}
  else {
   state.time+=d*state.speed;
   // Original clip playback is unchanged by the Motion Workspace.
   if(hasMotion()&&!loopPlayback()&&state.time>=currentPeriod()){
    state.time=currentPeriod();state.playing=false;$('playBtn').textContent='↻ Replay';
   }
  }
 }
 // A paused frame is a held 3D pose, not a new animation evaluation.
 // The old updateAnimation-on-every-RAF behavior could repeatedly touch IK/ankles
 // while time was frozen. Scrubbing and slider changes explicitly re-evaluate once.
 if(state.playing&&state.loaded){if(!motionWorkspace.running)updateAnimation(state.time);updateProgressUI();}
 v7RenderScene();
}
function clearModel(){
 workspaceStopSequence();motionWorkspace.key=null;v7BeforeClear();
 if(state.skeletonHelper){scene.remove(state.skeletonHelper);state.skeletonHelper.geometry.dispose();state.skeletonHelper.material.dispose();state.skeletonHelper=null;}
 if(state.pivot){scene.remove(state.pivot);state.pivot.traverse(o=>{if(o.geometry&&!o.userData.keep)try{o.geometry.dispose()}catch{} });}
 state.pivot=null;state.model=null;state.fit=null;state.axis=null;state.face=null;state.rig=null;
 state.mixer=null;state.clips=[];state.time=0;state.loaded=false;state.rigInfo=null;state.facingFlip=false;state.calibrationKey=null;
}
const gltfLoader=new GLTFLoader();
// The compass rotates the outer pivot; the axis group corrects mesh coordinate axes.
// Separating the two makes directional sprites consistent after an orientation fix.
function standModel(){
 if(!state.fit||!state.axis)return;
 const fit=state.fit,pivot=state.pivot,prevY=pivot.rotation.y;
 pivot.rotation.y=0;fit.position.set(0,0,0);fit.scale.setScalar(1);pivot.updateMatrixWorld(true);
 const b=new THREE.Box3().setFromObject(state.face),sz=b.getSize(new THREE.Vector3());
 const height=Math.max(0.01,sz.y,sz.x*.85,sz.z*.85);
 const scale=3/height;
 fit.scale.setScalar(scale);
 fit.position.set(-(b.min.x+b.max.x)*scale/2,-b.min.y*scale,-(b.min.z+b.max.z)*scale/2);
 pivot.rotation.y=prevY;
 pivot.updateMatrixWorld(true);
}
function selectAxis(axisId){
 if(!state.axis)return;
 state.axisPreset=axisId;
 state.axis.rotation.set(0,0,0);
 if(axisId==='XL')state.axis.rotation.z=-Math.PI/2; // TripoSR sideways: head points left
 if(axisId==='XR')state.axis.rotation.z=Math.PI/2;
 if(axisId==='ZP')state.axis.rotation.x=-Math.PI/2;
 if(axisId==='ZN')state.axis.rotation.x=Math.PI/2;
 $('axisSelect').value=axisId;
 standModel();
 log('Orientation set to '+$('axisSelect').selectedOptions[0].text+'. Check the head, feet and facing.','orientationMessage');
}
function flipFacing(){
 if(!state.face)return;
 state.facingFlip=!state.facingFlip;
 state.face.rotation.y=state.facingFlip?Math.PI:0;
 standModel();
 log('Front/back flipped. The eight-direction compass is independent of model orientation.','orientationMessage');
}
function hasMotion(){return !!(state.loaded&&state.mixer&&state.selection.startsWith('clip::')&&state.clips.length);}
function analyzeRig(root){
 const info={meshCount:0,skinnedMeshes:0,bones:0,uniqueBoneNames:[],clips:[],trackSummary:[],issues:[],type:'static'};
 const boneSet=new Set();const nameSet=new Set();
 root.traverse(o=>{if(o.name)nameSet.add(o.name);if(o.isMesh)info.meshCount++;if(o.isSkinnedMesh){info.skinnedMeshes++;for(const b of (o.skeleton?.bones||[]))boneSet.add(b.name||'(unnamed)');}});
 info.bones=boneSet.size;info.uniqueBoneNames=Array.from(boneSet).sort();
 if(info.skinnedMeshes>0&&info.bones>0)info.type='skinned';
 else if(info.skinnedMeshes>0)info.issues.push('Skinned meshes exist but readable bones were not found.');
 else info.issues.push('This mesh has no skin weights. Animations cannot deform its arms or legs.');
 if(info.bones>0&&info.bones<10)info.issues.push('Fewer than 10 unique bones. Confirm that this rig can articulate the limbs.');
 info._names=nameSet;
 return info;
}
function validateClip(clip,names){
 const mismatched=[];
 for(const track of clip.tracks){
  const k=track.name.lastIndexOf('.');if(k<=0){mismatched.push(track.name);continue;}
  const target=track.name.substring(0,k);
  if(!names.has(target))mismatched.push(target);
 }
 return [...new Set(mismatched)];
}
function rigReport(){
 if(!state.rigInfo)return {status:'no model loaded'};
 const info=state.rigInfo;
 return {version:3,modelSource:state.modelSource,meshCount:info.meshCount,skinnedMeshes:info.skinnedMeshes,
  boneCount:info.bones,bones:info.uniqueBoneNames,animationClips:state.clips.map(c=>({name:c.name,durationSeconds:c.duration,tracks:c.tracks.length,missingTargets:validateClip(c,info._names)})),
  warnings:info.issues,orientation:state.axisPreset,flipped:state.facingFlip,
  note:'A GLB mesh is not a rig. Good results require weight-painted bones and correctly authored animation clips. Animation-only GLBs must use compatible bone names AND rest poses.'};
}
function updatePipelineUI(){
 const i=state.rigInfo,clips=state.clips.length;
 let status='No 3D model',summary='Generate a model, or load a GLB with a skeleton and animation clips.';
 if(i){
  if(i.skinnedMeshes&&clips){status='Rigged + animated';summary=`${i.skinnedMeshes} skinned mesh(es) · ${i.bones} bones · ${clips} usable clip(s). Real motion preview is available.`;}
  else if(i.skinnedMeshes){status='Rigged, no animation';summary=`${i.skinnedMeshes} skinned mesh(es) · ${i.bones} bones. Attach animation GLB files using the SAME skeleton and rest pose.`;}
  else if(clips){status='Animated transforms only';summary=`${clips} node animation(s), but no skinned humanoid. Limbs will not deform like a properly rigged character.`;}
  else{status='Static mesh (no rig)';summary='TripoSR created geometry but no skeleton. Move to a rigging tool, then import the rigged and animated GLB.';}
 }
 $('rigStatus').textContent=status;
 $('pipelineBadge').textContent=status;
 $('pipelineSummary').textContent=summary;
 $('inspectRigBtn').disabled=!state.loaded;
 $('rigReportBtn').disabled=!state.loaded;
 $('motionInput').disabled=!Boolean(i?.skinnedMeshes);
 $('bonesToggle').disabled=!Boolean(i?.skinnedMeshes);
 $('exportStaticBtn').disabled=!state.loaded;
 $('exportOneBtn').disabled=!Boolean(state.loaded&&clips);
 $('exportAllBtn').disabled=!Boolean(state.loaded&&clips);
 $('playBtn').disabled=!Boolean(state.loaded&&clips);
 $('scrub').disabled=!Boolean(state.loaded&&clips);
 if(!clips){state.playing=false;$('playBtn').textContent='▶ Play';$('motionName').textContent='Static pose';}
}
function showBones(visible){
 if(state.skeletonHelper){scene.remove(state.skeletonHelper);state.skeletonHelper.geometry.dispose();state.skeletonHelper.material.dispose();state.skeletonHelper=null;}
 if(!visible||!state.rigInfo?.skinnedMeshes)return;
 const helper=new THREE.SkeletonHelper(state.model);helper.material.depthTest=false;helper.material.transparent=true;helper.material.opacity=.75;
 helper.renderOrder=999;scene.add(helper);state.skeletonHelper=helper;
}
function showRigDetails(){
 $('rigJson').textContent=JSON.stringify(rigReport(),null,2);
 $('rigVeil').classList.add('show');
}
async function importAnimationGLB(file){
 if(!state.loaded||!state.rigInfo?.skinnedMeshes){log('Import a properly skinned GLB character before adding motion.','motionImportStatus',true);return;}
 const url=URL.createObjectURL(file);
 try{
  const g=await new Promise((resolve,reject)=>gltfLoader.load(url,resolve,undefined,reject));
  if(!g.animations?.length)throw new Error('No animation clips were found in this GLB.');
  let imported=0;const rejected=[];
  for(const c of g.animations){
   const missing=validateClip(c,state.rigInfo._names);
   if(missing.length){rejected.push(`${c.name}: missing target(s) ${missing.slice(0,4).join(', ')}`);continue;}
   // Compatible names are necessary, but different bone rest poses can still distort the animation.
   const copy=c.clone();let base=copy.name||'Animation';if(state.clips.some(x=>x.name===base))base=filename(file.name)+'_'+base;
   copy.name=base;state.clips.push(copy);imported++;
  }
  if(!imported)throw new Error('No compatible clips. '+rejected.slice(0,2).join(' | '));
  if(!state.mixer)state.mixer=new THREE.AnimationMixer(state.model);
  refreshClipUI();updatePipelineUI();chooseClip(state.clips[state.clips.length-imported]);
  log(`Added ${imported} real clip(s). ${rejected.length} incompatible clip(s) skipped. Skeleton names must match AND rest poses must agree.`, 'motionImportStatus',!!rejected.length);
 }catch(e){log(e.message,'motionImportStatus',true)}finally{URL.revokeObjectURL(url);$('motionInput').value='';}
}
async function loadModel(url,label='3D model',source='generic',persistentAssetId=null){
 log('Loading 3D model…');
 return new Promise((resolve,reject)=>gltfLoader.load(url,g=>{
   try{
     clearModel();const root=g.scene;
     root.updateMatrixWorld(true);
     const geometryBounds=new THREE.Box3().setFromObject(root);
     if(geometryBounds.isEmpty())throw new Error('This model has no visible 3D geometry');
     state.pivot=new THREE.Group();state.pivot.name='Compass direction';scene.add(state.pivot);
     state.fit=new THREE.Group();state.fit.name='Center and scale';state.pivot.add(state.fit);
     state.face=new THREE.Group();state.face.name='Front/back facing correction';state.fit.add(state.face);
     state.axis=new THREE.Group();state.axis.name='Editable imported mesh orientation';state.face.add(state.axis);
     state.axis.add(root);state.model=root;state.modelSource=source;state.calibrationKey=calibrationStorageKey(source,persistentAssetId||label);
     state.rigInfo=analyzeRig(root);
     state.clips=g.animations||[];
     if(state.clips.length===1&&/^(ArmatureAction|Action|Animation)$/i.test(state.clips[0].name)){
       const inferred=/sword|slash|swing|attack/i.test(label)?'Sword Swing':/walk/i.test(label)?'Walk':/run/i.test(label)?'Run':null;
       if(inferred)state.clips[0].name=inferred;
     }
     if(state.clips.length)state.mixer=new THREE.AnimationMixer(root);
     selectAxis(source==='triposr'?'XL':'Y');
     state.loaded=true;state.time=0;state.playing=false;
     mapMotionBones();
     restoreFootCalibration();
     v7LoadRig();
     $('emptyState').style.display='none';$('previewTitle').textContent=label;
     $('bonesToggle').checked=false;
     setDirection(state.dir);refreshClipUI();applyStyle(state.style);
     updatePipelineUI();
     if(state.clips.length){chooseClip(state.clips[0]);$('motionHint').textContent='Playing imported GLB clip. Choose presets or clips, or attach additional motion with an identical skeleton.';log('Animated GLB loaded. Select clips or import matching motion files.');}
     else {$('motionName').textContent='Static pose';$('motionHint').textContent='No animation clips were found. Static meshes cannot walk or attack until rigged and animated. Use the Rigging & Motion panel.';log('Static mesh loaded. It needs a proper rig for animations.');}
     resolve();
   }catch(e){log(e.message,'aiProgress',true);reject(e)}
 },undefined,e=>{log('Unable to open GLB: '+e.message,'aiProgress',true);reject(e)}));
}
function updateAnimation(time){
 // Deterministically resample source GLB, then apply non-destructive corrective motion layers.
 updateMotionLab(time);
 v7ApplyLayer();
}
function setDirection(dir){state.dir=dir;const angle=DIRS.indexOf(dir)*Math.PI/4;if(state.pivot)state.pivot.rotation.y=angle;
 document.querySelectorAll('#compass button').forEach(el=>el.classList.toggle('active',el.dataset.dir===dir));$('directionStatus').textContent='Facing '+dir;}
function setPreset(name){
 if(!state.loaded){$('motionHint').textContent='Load a rigged and animated character first.';return;}
 if(!state.clips.length){$('motionHint').textContent='This is a static mesh. A real animation requires a skeleton, skin weights and motion clips.';return;}
 const pattern={idle:/idle|breath|stand/i,walk:/walk/i,run:/run|sprint/i,heavy:/heavy/i,sneak:/sneak|crouch/i,jump:/jump/i,fall:/fall/i,roll:/roll/i,punch:/punch/i,kick:/kick/i,slash:/slash|sword|attack/i,combo:/combo/i,shoot:/shoot|fire/i,block:/guard|block/i,hit:/hit|damage/i,death:/death|die/i,swim:/swim/i,wave:/wave/i}[name];
 const matched=state.clips.find(c=>pattern?.test(c.name));
 if(matched){chooseClip(matched);$('motionHint').textContent='Playing real embedded animation: '+matched.name;return;}
 $('motionHint').textContent='No '+name+' clip is available. Import a compatible animation GLB or select another clip. No fake animation was created.';
}
function chooseClip(clip){
 if(!state.mixer||!clip)return;
 if(motionWorkspace.running&&!motionWorkspace.switching)workspaceStopSequence();
 state.selection='clip::'+clip.name;state.preset='clip';state.time=0;state.mixer.stopAllAction();
 state.mixer.clipAction(clip).reset().play();state.mixer.setTime(0);
 labState.endKey=''; labState.endPose=null;
 captureLabAnchors();updateAnimation(0);updateProgressUI();refreshPlaybackLabel();
 document.querySelectorAll('.preset').forEach(b=>b.classList.toggle('active',b.textContent.toLowerCase()===clip.name.toLowerCase()));
 $('motionName').textContent=clip.name;state.playing=true;$('playBtn').textContent='❚❚ Pause';
 $('clipSelect').value=String(state.clips.indexOf(clip));updatePipelineUI();
 if($('wsCurrentClip'))$('wsCurrentClip').textContent=clip.name;
 v71RefreshCatalog();v71GuideMessage('Previewing '+clip.name+'. Select an art style or export its sprite sheet.');
}
function refreshClipUI(){v71RefreshCatalog();const sec=$('clipsSection'),sel=$('clipSelect');sec.style.display=state.clips.length?'block':'none';sel.innerHTML='<option value="">Choose a clip...</option>';
 state.clips.forEach((c,i)=>{const o=document.createElement('option');o.value=i;o.textContent=c.name+' ('+c.duration.toFixed(1)+'s)';sel.append(o)});refreshBatchClips();workspaceRefresh()}
function applyStyle(name){state.style=name;document.querySelectorAll('.styleChoice').forEach(b=>b.classList.toggle('active',b.dataset.style===name));
 $('styleBadge').textContent=({'original':'Original texture','pixel':'Pixel art','toon':'Cel shaded','paint':'Hand-painted','silhouette':'Silhouette','gold':'Gold/bronze','mono':'Monochrome','cyber':'Cyberpunk'}[name]);
 v71GuideMessage('Rendering look: '+$('styleBadge').textContent+'. Choose an animation next.');
 if(!state.loaded)return;
 state.pivot.traverse(o=>{
   if(!o.isMesh)return;
   const base=o.userData.originalMaterial||(o.userData.originalMaterial=o.material);
   if(name==='original'||name==='pixel'){o.material=base;return;}
   const styleMat=(m)=>{
     const color=m.color?.clone()||new THREE.Color(0x879fb0);
     if(name==='toon')return new THREE.MeshToonMaterial({color,map:m.map||null,vertexColors:!!m.vertexColors,side:THREE.DoubleSide});
     if(name==='paint')return new THREE.MeshStandardMaterial({color,map:m.map||null,vertexColors:!!m.vertexColors,roughness:1,metalness:0,flatShading:true,side:THREE.DoubleSide});
     if(name==='silhouette')return new THREE.MeshBasicMaterial({color:0x07101b,side:THREE.DoubleSide});
     if(name==='gold')return new THREE.MeshStandardMaterial({color:0xb99651,roughness:.8,metalness:.35,side:THREE.DoubleSide});
     if(name==='mono')return new THREE.MeshStandardMaterial({color:0xadb9c4,roughness:1,flatShading:true,side:THREE.DoubleSide});
     if(name==='cyber')return new THREE.MeshStandardMaterial({color:0x14456f,roughness:.4,metalness:.45,emissive:0x071a32,emissiveIntensity:.8,side:THREE.DoubleSide});
     return m;
   };
   o.material=Array.isArray(base)?base.map(styleMat):styleMat(base);
 });
}
function currentPeriod(){
 if(state.selection.startsWith('clip::'))return state.clips.find(c=>c.name===state.selection.slice(6))?.duration||1;
 return 1;
}
// Non-cyclic actions (sword swings, hits, jumps) should never snap back to frame zero.
// The loop setting affects *preview and export*, not the source GLB animation.
function loopPlayback(){
 const mode=$('playbackMode')?.value||'auto';
 if(mode==='loop')return true;
 if(mode==='once')return false;
 return /idle|walk|run|sprint|sneak|swim|guard|block|breath|hover/i.test(state.selection.slice(6));
}
function refreshPlaybackLabel(){
 if(!$('playbackHint'))return;
 const looping=loopPlayback();
 $('playbackHint').textContent=looping?
  'Loop preview: continuous cycles. Motion Lab can blend the loop seam to avoid a visible reset.':
  'One-shot: ends and freezes the final pose. Pausing will not reapply foot corrections.';
}

function updateProgressUI(){
 if(!state.loaded||!state.clips.length){$('frameBadge').textContent=state.loaded?'Static pose':'No model';$('timeText').textContent='No animation';$('scrub').value=0;return;}
 const period=currentPeriod(),t=loopPlayback()?((state.time/period)%1+1)%1:THREE.MathUtils.clamp(state.time/period,0,1);
 $('scrub').value=t*1000;$('timeText').textContent=`${(t*period).toFixed(2)}s / ${period.toFixed(2)}s`;
 const n=Number($('countSelect').value),current=loopPlayback()?Math.min(n-1,Math.floor(t*n)):Math.min(n-1,Math.round(t*(n-1)));$('frameBadge').textContent=`Frame ${current+1} / ${n}`;
 document.querySelectorAll('#frames .frame').forEach((el,i)=>el.classList.toggle('active',i===(loopPlayback()?Math.min(7,Math.floor(t*8)):Math.min(7,Math.round(t*7)))));
}
function buildTimeline(){const div=$('frames');div.innerHTML='';for(let i=0;i<8;i++){const b=document.createElement('button');b.className='frame';b.textContent=String(i+1).padStart(2,'0');b.addEventListener('click',()=>{state.playing=false;$('playBtn').textContent='▶ Play';state.time=currentPeriod()*(loopPlayback()?i/8:i/7);updateAnimation(state.time);updateProgressUI()});div.appendChild(b)}}
async function askBg(){if(!state.file)return;log('Running local background removal…');$('removeBgBtn').disabled=true;
 try{const fd=new FormData();fd.append('image',state.file);const r=await fetch('/api/remove-background',{method:'POST',body:fd});const data=await r.json();if(!r.ok)throw Error(data.detail||'Background removal failed');const resp=await fetch(data.url);state.cutoutFile=new File([await resp.blob()],'character_no_background.png',{type:'image/png'});$('cutoutPreview').src=URL.createObjectURL(state.cutoutFile);$('cutoutPreview').style.display='block';log('Background removed. Ready to generate the 3D character.');}
 catch(e){log(e.message,'aiProgress',true)}finally{$('removeBgBtn').disabled=false}}
async function generate(){if(!state.file)return;state.busy=true;$('generateBtn').disabled=true;log('Sending image to your local TripoSR process…');
 try{const fd=new FormData();fd.append('image',state.cutoutFile||state.file);const r=await fetch('/api/generate-3d',{method:'POST',body:fd});const d=await r.json();if(!r.ok)throw Error(d.detail||'Generation failed');
 const id=d.job_id;
 while(true){await new Promise(res=>setTimeout(res,1300));const resp=await fetch('/api/jobs/'+id);const j=await resp.json();log(j.message);if(j.status==='error')throw Error(j.message);if(j.status==='done'){await loadModel(j.result,'AI-generated character · TripoSR','triposr');break;}}
 }catch(e){log(e.message,'aiProgress',true)}finally{state.busy=false;$('generateBtn').disabled=!state.file}}
function filename(s){return String(s||'character').replace(/[^a-z0-9_-]/gi,'_').slice(0,50)}
function dataURLBlob(canvas){return new Promise(resolve=>canvas.toBlob(resolve,'image/png'))}
const crcTable=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let j=0;j<8;j++)c=c&1?0xedb88320^(c>>>1):c>>>1;crcTable[n]=c>>>0}
function crc32(data){let c=0xffffffff;for(let i=0;i<data.length;i++)c=crcTable[(c^data[i])&255]^(c>>>8);return(c^0xffffffff)>>>0}
function rawZip(files){const blocks=[],cd=[];let offset=0;const enc=new TextEncoder();const w16=(dv,o,v)=>dv.setUint16(o,v,true),w32=(dv,o,v)=>dv.setUint32(o,v,true);
 for(const f of files){const n=enc.encode(f.name),data=f.bytes,c=crc32(data);const local=new Uint8Array(30+n.length+data.length),view=new DataView(local.buffer);w32(view,0,0x04034b50);w16(view,4,20);w16(view,8,0);w32(view,14,c);w32(view,18,data.length);w32(view,22,data.length);w16(view,26,n.length);local.set(n,30);local.set(data,30+n.length);blocks.push(local);
 const dir=new Uint8Array(46+n.length),d=new DataView(dir.buffer);w32(d,0,0x02014b50);w16(d,4,20);w16(d,6,20);w32(d,16,c);w32(d,20,data.length);w32(d,24,data.length);w16(d,28,n.length);w32(d,42,offset);dir.set(n,46);cd.push(dir);offset+=local.length;
 }
 let cdSize=cd.reduce((s,b)=>s+b.length,0);const end=new Uint8Array(22),dv=new DataView(end.buffer);w32(dv,0,0x06054b50);w16(dv,8,files.length);w16(dv,10,files.length);w32(dv,12,cdSize);w32(dv,16,offset);return new Blob([...blocks,...cd,end],{type:'application/zip'})}
function download(blob,name){const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000)}
// V6.3: ROOT-MOTION STABILIZATION IN ALL THREE DIMENSIONS.
// Walking clips can travel toward/away from the camera when the model is rotated
// to diagonal views. Simply following world X (V6.2) let the mesh cross the
// camera's NEAR clipping plane and made later SW frames disappear.
// During export ONLY, apply the inverse X/Z root displacement to the outer
// compass pivot. The original animation, vertical jumps, GLB, and preview
// remain untouched. A single fitted camera is shared by all 8 directions.
function exportRigAnchor(){
 if(labState.bones?.hips?.isBone)return labState.bones.hips;
 const root=state.model?.getObjectByName('bone_0');if(root?.isBone)return root;
 let firstSkin=null;state.model?.traverse(o=>{if(!firstSkin&&o.isSkinnedMesh&&o.skeleton?.bones?.length)firstSkin=o});
 if(firstSkin){const bones=firstSkin.skeleton.bones;return bones.find(b=>!b.parent?.isBone)||bones[0]}
 return state.model;
}
function exportVisibleBounds(){
 state.pivot.updateMatrixWorld(true);
 // Skinned mesh bounds must be recomputed for the current bone pose.
 state.model.traverse(o=>{
  if(!o.isSkinnedMesh||!o.visible)return;
  // Three.js does not refresh a SkinnedMesh's cached bounding sphere on each
  // animation sample. The exporter measures a fresh box; refresh the sphere too.
  // Without this, the renderer may decide a visible character is off-screen.
  if(typeof o.computeBoundingBox==='function')o.computeBoundingBox();
  if(typeof o.computeBoundingSphere==='function')o.computeBoundingSphere();
 });
 const box=new THREE.Box3().setFromObject(state.model,true);
 if(box.isEmpty()||[box.min.x,box.min.y,box.min.z,box.max.x,box.max.y,box.max.z].some(v=>!Number.isFinite(v)))throw new Error('Cannot compute animated model bounds.');
 return box;
}
function exportSampleTime(index,count,period){
 if(count<=1)return 0;
 return period*index/(loopPlayback()?count:count-1);
}
// Samples the animation with the pivot at its original position, measures
// skeletal root travel, and then offsets the entire model in X and Z only.
// This must happen AFTER updateAnimation, since bone-specific IK needs its
// original world-space pose. Y is intentionally unchanged for jumps/falls.
function exportInPlacePose(time,dir,reference,anchor,anchorPoint){
 state.pivot.position.set(0,0,0);
 state.pivot.rotation.y=DIRS.indexOf(dir)*Math.PI/4;
 updateAnimation(time);
 state.pivot.updateMatrixWorld(true);
 const p=anchor.getWorldPosition(anchorPoint);
 state.pivot.position.set(reference.x-p.x,0,reference.z-p.z);
 state.pivot.updateMatrixWorld(true);
 return exportVisibleBounds();
}
async function prepareExportCameraPlan(forcedStill=false,frameCountOverride=null){
 if(!state.loaded||!state.pivot)throw new Error('No 3D character loaded');
 const count=forcedStill?1:(frameCountOverride??Number($('countSelect').value)),period=currentPeriod();
 const oldTime=state.time,oldRot=state.pivot.rotation.y,oldPosition=state.pivot.position.clone();
 const anchor=exportRigAnchor(),anchorPos=new THREE.Vector3();
 const refs={},extent={minX:Infinity,maxX:-Infinity,minY:Infinity,maxY:-Infinity,minZ:Infinity,maxZ:-Infinity};
 try{
  for(let d=0;d<DIRS.length;d++){
   const dir=DIRS[d];
   state.pivot.position.set(0,0,0);state.pivot.rotation.y=d*Math.PI/4;
   updateAnimation(0);state.pivot.updateMatrixWorld(true);
   refs[dir]=anchor.getWorldPosition(anchorPos).clone();
   for(let i=0;i<count;i++){
    const bound=exportInPlacePose(exportSampleTime(i,count,period),dir,refs[dir],anchor,anchorPos);
    extent.minX=Math.min(extent.minX,bound.min.x);extent.maxX=Math.max(extent.maxX,bound.max.x);
    extent.minY=Math.min(extent.minY,bound.min.y);extent.maxY=Math.max(extent.maxY,bound.max.y);
    extent.minZ=Math.min(extent.minZ,bound.min.z);extent.maxZ=Math.max(extent.maxZ,bound.max.z);
   }
   if(d%2===1)await new Promise(done=>setTimeout(done,0));
  }
  const width=extent.maxX-extent.minX,height=extent.maxY-extent.minY;
  if(!Number.isFinite(width+height)||width<=0||height<=0)throw new Error('Invalid animated bounds during export.');
  const framing=Number($('exportFitSlider').value)/100;
  // Fit all sampled poses, across all directions, with at least 12% padding.
  // A single camera transform prevents East/West walk frames changing scale.
  const half=Math.max(width,height)*.5*Math.max(1.12,1.25*framing);
  const cameraZ=extent.maxZ+Math.max(10,extent.maxZ-extent.minZ+5);
  const cameraFar=Math.max(100,cameraZ-extent.minZ+25);
  return {halfExtent:Math.max(.15,half),centerX:(extent.minX+extent.maxX)/2,centerY:(extent.minY+extent.maxY)/2,
    cameraZ,cameraFar,refs,width,height,frames:count,stabilization:'XZ-pivot',
    measuredBounds:{...extent},framingMode:'fixed-camera-straight-on'};
 }finally{
  state.pivot.rotation.y=oldRot;state.pivot.position.copy(oldPosition);
  updateAnimation(oldTime);state.pivot.updateMatrixWorld(true);
 }
}
// Export diagnostics work on alpha, not RGB. Transparent black character parts
// still count as pixels. We reject frames that are blank OR touch an edge.
function exportAlphaBounds(ctx,x,y,size){
 const pixels=ctx.getImageData(x,y,size,size).data;
 let l=size,t=size,r=-1,b=-1,count=0;
 for(let py=0;py<size;py++)for(let px=0;px<size;px++){
  if(pixels[(py*size+px)*4+3]<8)continue;
  l=Math.min(l,px);r=Math.max(r,px);t=Math.min(t,py);b=Math.max(b,py);count++;
 }
 return count?{left:l,right:r,top:t,bottom:b,count}:null;
}
function exportBoundsInsideFrame(b,size){
 if(!b)return false;
 const pad=Math.max(2,Math.floor(size*.015));
 return b.left>=pad&&b.right<size-pad&&b.top>=pad&&b.bottom<size-pad;
}
async function renderSheet(dir,forcedStill=false,plan=null,frameCountOverride=null){
 const count=forcedStill?1:(frameCountOverride??Number($('countSelect').value)),size=Number($('sizeSelect').value),columns=forcedStill?1:Number($('colSelect').value),rows=Math.ceil(count/columns);
 if(!DIRS.includes(dir))throw new Error('Invalid export direction');
 const layout=plan||await prepareExportCameraPlan(forcedStill);
 const sheet=document.createElement('canvas');sheet.width=size*columns;sheet.height=size*rows;
 if(sheet.width>16384||sheet.height>16384)throw new Error('Sprite sheet is too large for this browser. Reduce frame size or columns.');
 const ctx=sheet.getContext('2d',{willReadFrequently:true});ctx.clearRect(0,0,sheet.width,sheet.height);
 const oldTime=state.time,oldRot=state.pivot.rotation.y,oldPosition=state.pivot.position.clone();
 const oldSize=new THREE.Vector2();renderer.getSize(oldSize);
 const oldRatio=renderer.getPixelRatio();
 const oldCam={left:camera.left,right:camera.right,top:camera.top,bottom:camera.bottom,near:camera.near,far:camera.far,zoom:camera.zoom,
   position:camera.position.clone(),quaternion:camera.quaternion.clone()};
 const helperVisible=state.skeletonHelper?.visible,footGuideVisible=footFloorGuide?.visible;
 // V6.6: avoid false frustum rejection of moving/skinned meshes during export.
 // Culling is a visibility optimization based on cached bounds, not a reliable
 // test of whether the animated vertices are visible. Always restore it later.
 const savedMeshCulling=[];
 state.model.traverse(o=>{
  if(o.isMesh){savedMeshCulling.push([o,o.frustumCulled]);o.frustumCulled=false;}
 });
 const pixelStyle=state.style==='pixel';const low=Math.min(size,Number($('pixelSelect').value));
 const renderSize=pixelStyle?low:Math.min(2048,size*2);
 const anchor=exportRigAnchor(),anchorPoint=new THREE.Vector3();
 try{
  renderer.setPixelRatio(1);renderer.setSize(renderSize,renderSize,false);
  camera.zoom=1;camera.left=-layout.halfExtent;camera.right=layout.halfExtent;
  camera.top=layout.halfExtent;camera.bottom=-layout.halfExtent;
  camera.near=.01;camera.far=layout.cameraFar;camera.updateProjectionMatrix();
  // DO NOT reuse the preview camera's quaternion: the preview can be tilted
  // toward a different target. Export uses a fixed +Z -> -Z camera; the
  // character's pivot rotation alone chooses the eight viewing directions.
  camera.quaternion.set(0,0,0,1);
  camera.position.set(layout.centerX,layout.centerY,layout.cameraZ);
  camera.updateMatrixWorld(true);
  if(state.skeletonHelper)state.skeletonHelper.visible=false;
  if(footFloorGuide)footFloorGuide.visible=false;
  for(let i=0;i<count;i++){
   const time=exportSampleTime(i,count,currentPeriod());
   const bound=exportInPlacePose(time,dir,layout.refs[dir],anchor,anchorPoint);
   // The measured world-space bbox must fit the *same* camera for every frame.
   // Never silently recenter individual frames: that creates jitter.
   const epsilon=1e-5;
   if(bound.min.x<layout.centerX-layout.halfExtent-epsilon||bound.max.x>layout.centerX+layout.halfExtent+epsilon||
      bound.min.y<layout.centerY-layout.halfExtent-epsilon||bound.max.y>layout.centerY+layout.halfExtent+epsilon||
      bound.max.z>=layout.cameraZ-camera.near||bound.min.z<=layout.cameraZ-layout.cameraFar){
     throw new Error(`${dir} frame ${i+1}/${count} exceeds the measured animation bounds; try Export framing 120%.`);
   }
   v7RenderScene();
   const x=(i%columns)*size,y=Math.floor(i/columns)*size;
   ctx.imageSmoothingEnabled=!pixelStyle;if(!pixelStyle)ctx.imageSmoothingQuality='high';
   ctx.clearRect(x,y,size,size);ctx.drawImage(renderer.domElement,x,y,size,size);
   const frame=exportAlphaBounds(ctx,x,y,size);
   if(!frame)throw new Error(`${dir} frame ${i+1}/${count} still rendered blank with mesh culling disabled. Export stopped; no incomplete pack was downloaded. This animation may need a source-GLB inspection.`);
   if(!exportBoundsInsideFrame(frame,size))throw new Error(`${dir} frame ${i+1}/${count} touches the image border. Increase Export framing for fully visible sprites.`);
   if(i%8===7)await new Promise(done=>setTimeout(done,0));
  }
  const blob=await dataURLBlob(sheet);
  if(!blob)throw new Error('Could not encode sprite sheet as PNG.');
  return blob;
 }finally{
  // Rendering optimizations must never leak back into the user's preview.
  for(const [mesh,previous] of savedMeshCulling)mesh.frustumCulled=previous;
  state.time=oldTime;state.pivot.rotation.y=oldRot;state.pivot.position.copy(oldPosition);
  if(state.skeletonHelper)state.skeletonHelper.visible=helperVisible;
  if(footFloorGuide)footFloorGuide.visible=footGuideVisible;
  renderer.setPixelRatio(oldRatio);renderer.setSize(oldSize.x,oldSize.y,false);
  camera.left=oldCam.left;camera.right=oldCam.right;camera.top=oldCam.top;camera.bottom=oldCam.bottom;
  camera.near=oldCam.near;camera.far=oldCam.far;camera.zoom=oldCam.zoom;
  camera.position.copy(oldCam.position);camera.quaternion.copy(oldCam.quaternion);
  camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
  updateAnimation(oldTime);state.pivot.updateMatrixWorld(true);v7RenderScene();
 }
}
async function exportSheets(all){if(!hasMotion()||state.exporting){log('Load an animated GLB clip before exporting animation frames.','exportProgress',true);return;}state.exporting=true;state.playing=false;$('playBtn').textContent='▶ Play';$('exportOneBtn').disabled=true;$('exportAllBtn').disabled=true;
 const dirs=all?DIRS:[state.dir];const files=[];
 try{log('Measuring full animation for stable framing…','exportProgress');const plan=await prepareExportCameraPlan(false);for(let i=0;i<dirs.length;i++){log(`Rendering direction ${dirs[i]} (${i+1}/${dirs.length})…`,'exportProgress');const blob=await renderSheet(dirs[i],false,plan);files.push({name:`core_keys_${filename(state.selection)}_${dirs[i]}_${$('sizeSelect').value}px.png`,bytes:new Uint8Array(await blob.arrayBuffer())});}
  if(all){files.push({name:'animation.json',bytes:new TextEncoder().encode(JSON.stringify({animation:state.selection,style:state.style,root_motion:'stabilized_XZ_pivot',auto_framed:true,frames:Number($('countSelect').value),frame_size:Number($('sizeSelect').value),columns:Number($('colSelect').value),fps:(Number($('countSelect').value)-(loopPlayback()?0:1))/currentPeriod(),loop:loopPlayback(),directions:DIRS,origin:'bottom center',background:'transparent'},null,2))});download(rawZip(files),`core_keys_${filename(state.selection)}_8_directions.zip`)}
  else download(new Blob([files[0].bytes],{type:'image/png'}),files[0].name);
  log('Export complete — transparent PNG sprites, aligned across directions.','exportProgress');
 }catch(e){log('Export error: '+e.message,'exportProgress',true)}finally{state.exporting=false;updatePipelineUI();last=performance.now()}}
// V6.7: production-first batch exporter, with independently sampled frame counts.
// Frame presets are recommendations, not speed adjustments or invented animation.
// 16 samples capture the full left/right stride in the user's working Walk GLB.
const BATCH_FRAME_OPTIONS=[8,16,24,32,40,48];
function recommendedFramesForClip(name){
 const n=String(name||'').toLowerCase();
 if(/combo|multi[ _-]?hit|chain[ _-]?attack/.test(n))return 24;
 if(/walk|run|sprint|jog|sneak|swim|crawl|dash|roll|climb|jump|fall|dodge/.test(n))return 16;
 if(/sword|slash|swing|attack|punch|kick|shoot|fire|death|hit[ _-]?react|wave|dance|kata/.test(n))return 16;
 return 8; // idle, breath, guard and unclassified clips
}
const batchSelectedNames=new Set();
const batchFramePrefs=new Map();
let activeFrameCharacterKey=null;
function batchFramePrefsKey(){return 'coremotion-export-frames-v1::'+(state.calibrationKey||'unidentified-character')}
function loadBatchFramePrefs(){
 const key=batchFramePrefsKey();
 if(activeFrameCharacterKey===key)return;
 activeFrameCharacterKey=key;
 batchFramePrefs.clear();batchSelectedNames.clear();
 try{
  const parsed=JSON.parse(localStorage.getItem(key)||'{}');
  if(parsed&&typeof parsed==='object'&&!Array.isArray(parsed))for(const [name,n] of Object.entries(parsed)){
   if(BATCH_FRAME_OPTIONS.includes(Number(n)))batchFramePrefs.set(name,Number(n));
  }
 }catch{} // Browser storage restrictions never block batch exports.
}
function saveBatchFramePrefs(){
 try{localStorage.setItem(batchFramePrefsKey(),JSON.stringify(Object.fromEntries(batchFramePrefs)))}catch{}
}
function framesForBatchClip(clip){
 const n=batchFramePrefs.get(clip.name);
 return BATCH_FRAME_OPTIONS.includes(n)?n:recommendedFramesForClip(clip.name);
}
let batchExportCancel=false;
function batchUpdateButton(){
 const button=$('batchExportBtn');if(!button)return;
 const n=state.clips.filter(c=>batchSelectedNames.has(c.name)).length;
 const selected=state.clips.filter(c=>batchSelectedNames.has(c.name));
 const samples=selected.reduce((sum,clip)=>sum+framesForBatchClip(clip),0)*DIRS.length;
 $('batchCount').textContent=`${n} selected · ${samples} frames`;
 button.disabled=!state.loaded||!n||state.exporting;
 button.textContent=n?`Export ${n} animation${n===1?'':'s'} × 8 directions (ZIP)`:'Choose animations to export';
}
function refreshBatchClips(){
 const list=$('batchClipList');if(!list)return;
 loadBatchFramePrefs();
 const current=state.clips.map(c=>c.name);
 // On first import select a small starter set, then preserve the user's selections.
 if(!current.some(name=>batchSelectedNames.has(name))&&current.length){
  const starters=state.clips.filter(c=>/idle|walk/i.test(c.name)).slice(0,2);
  (starters.length?starters:state.clips.slice(0,1)).forEach(c=>batchSelectedNames.add(c.name));
 }
 list.replaceChildren();
 if(!current.length){const t=document.createElement('span');t.className='tiny';t.textContent='Load a rigged character and its animation clips first.';list.append(t);}
 for(const [i,clip] of state.clips.entries()){
  const row=document.createElement('div');row.className='batchClipChoice';
  const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.value=clip.name;checkbox.id=`batchclip-${i}`;checkbox.checked=batchSelectedNames.has(clip.name);
  checkbox.addEventListener('change',()=>{if(checkbox.checked)batchSelectedNames.add(clip.name);else batchSelectedNames.delete(clip.name);batchUpdateButton();});
  const caption=document.createElement('label');caption.htmlFor=checkbox.id;caption.className='batchClipLabel';caption.textContent=`${clip.name} · ${clip.duration.toFixed(2)}s`;caption.title=caption.textContent;
  const frameSelect=document.createElement('select');frameSelect.className='batchFrameSelect';frameSelect.setAttribute('aria-label',`Frame count for ${clip.name}`);frameSelect.title=`Frames for ${clip.name} (suggested ${recommendedFramesForClip(clip.name)})`;
  const recommendation=recommendedFramesForClip(clip.name);
  for(const count of BATCH_FRAME_OPTIONS){const option=document.createElement('option');option.value=String(count);option.textContent=count+'f'+(count===recommendation?' ★':'');frameSelect.append(option)}
  frameSelect.value=String(framesForBatchClip(clip));
  frameSelect.addEventListener('change',()=>{batchFramePrefs.set(clip.name,Number(frameSelect.value));saveBatchFramePrefs();batchUpdateButton()});
  row.append(checkbox,caption,frameSelect);list.append(row);
 }
 batchUpdateButton();
}
function batchMessage(message,error=false){log(message,'batchProgress',error)}
async function exportProductionPack(){
 if(!state.loaded||!state.clips.length||state.exporting){batchMessage('Load an animated model before exporting.',true);return;}
 const selected=state.clips.filter(c=>batchSelectedNames.has(c.name));
 if(!selected.length){batchMessage('Select at least one animation.',true);return;}
 const totalSheets=selected.length*DIRS.length;
 const totalFrames=selected.reduce((s,c)=>s+framesForBatchClip(c)*DIRS.length,0);
 if(totalFrames>1800&&!confirm(`This export will render ${totalFrames} frames. Continue?`))return;
 const oldClip=state.clips.find(c=>state.selection==='clip::'+c.name)||state.clips[0];
 const oldTime=state.time,oldPlaying=state.playing,oldDir=state.dir;
 const data=[];const clipsMeta=[];
 batchExportCancel=false;state.exporting=true;state.playing=false;
 $('playBtn').textContent='▶ Play';$('batchCancelBtn').style.display='block';batchUpdateButton();
 let done=0;
 try{
  for(let j=0;j<selected.length;j++){
   if(batchExportCancel)break;
   const clip=selected[j];chooseClip(clip);state.playing=false;
   const clipFrames=framesForBatchClip(clip);
   const isLoop=loopPlayback();
   batchMessage(`Measuring ${clip.name} · ${clipFrames} frames per direction…`);
   const plan=await prepareExportCameraPlan(false,clipFrames);
   const folder=`animations/${String(j+1).padStart(2,'0')}_${filename(clip.name)}`;
   const m={name:clip.name,duration_seconds:clip.duration,frames:clipFrames,frame_size_px:Number($('sizeSelect').value),columns:Number($('colSelect').value),rows:Math.ceil(clipFrames/Number($('colSelect').value)),root_motion:'stabilized_XZ_pivot',auto_framed:true,visible_frames:clipFrames,loop:isLoop,fps:(clipFrames-(isLoop?0:1))/clip.duration,directions:{}};
   for(const dir of DIRS){
    if(batchExportCancel)break;
    batchMessage(`Rendering ${clip.name}: ${dir} · ${done+1}/${totalSheets} sheets`);
    const blob=await renderSheet(dir,false,plan,clipFrames);
    const name=`${folder}/${dir}.png`;
    data.push({name,bytes:new Uint8Array(await blob.arrayBuffer())});
    m.directions[dir]=name;done++;
    await new Promise(resolve=>setTimeout(resolve,0));
   }
   if(!batchExportCancel)clipsMeta.push(m);
  }
  if(batchExportCancel){batchMessage('Batch export stopped. No ZIP was downloaded.');return;}
  // Each animation now owns its frame count; never describe mixed counts as a single count.
  const counts=clipsMeta.map(c=>c.frames);
  const sharedCount=counts.every(n=>n===counts[0])?counts[0]:null;
  data.push({name:'manifest.json',bytes:new TextEncoder().encode(JSON.stringify({studio:'Core Motion Studio V6.7',art_style:state.style,frame_strategy:'per_animation',frames_per_clip:sharedCount,size_px:Number($('sizeSelect').value),columns:Number($('colSelect').value),directions:DIRS,transparent_background:true,root_motion:'stabilized_XZ_pivot',camera_framing:'fixed_camera_all_directions_per_clip',frames_verified_nonempty:true,animations:clipsMeta},null,2))});
  batchMessage(`Packaging ${clipsMeta.length} animations · ${done} directional sheets…`);
  download(rawZip(data),'CoreMotion_Animation_Sprite_Pack.zip');
  batchMessage(`Exported ${clipsMeta.length} animations, ${done} direction sheets, and manifest.json.`);
 }catch(error){batchMessage('Export failed: '+(error?.message||error),true)}
 finally{
  if(oldClip){chooseClip(oldClip);state.time=oldTime;updateAnimation(oldTime);}
  setDirection(oldDir);state.playing=oldPlaying;
  $('playBtn').textContent=oldPlaying?'❚❚ Pause':'▶ Play';
  state.exporting=false;$('batchCancelBtn').style.display='none';batchUpdateButton();updatePipelineUI();updateProgressUI();last=performance.now();
 }
}
$('batchSelectAll').addEventListener('click',()=>{state.clips.forEach(c=>batchSelectedNames.add(c.name));refreshBatchClips()});
$('batchSelectNone').addEventListener('click',()=>{batchSelectedNames.clear();document.querySelectorAll('#batchClipList input').forEach(el=>el.checked=false);batchUpdateButton()});
$('batchExportBtn').addEventListener('click',exportProductionPack);
$('batchCancelBtn').addEventListener('click',()=>{batchExportCancel=true;batchMessage('Stopping after the current direction…')});
$('batchResetFrames').addEventListener('click',()=>{batchFramePrefs.clear();saveBatchFramePrefs();refreshBatchClips();batchMessage('Recommended per-animation counts restored (Walk/Run 16f, Idle 8f).');});
$('applySingleFrameSuggestion').addEventListener('click',()=>{
 const clip=state.clips.find(c=>state.selection==='clip::'+c.name);
 if(!clip){log('Choose a real animation clip first.','exportProgress',true);return;}
 const n=framesForBatchClip(clip);
 $('countSelect').value=String(n);
 log(`${clip.name}: ${n} frames selected for single-animation export.`, 'exportProgress');
});

async function exportEightStillViews(){
 if(!state.loaded||state.exporting)return;
 state.exporting=true;state.playing=false;
 const files=[];const oldSelect=state.selection;const oldTime=state.time;
 try{
  const plan=await prepareExportCameraPlan(true);for(const dir of DIRS){log('Rendering static '+dir+' view…','exportProgress');const blob=await renderSheet(dir,true,plan);
   files.push({name:`core_keys_static_${dir}_${$('sizeSelect').value}px.png`,bytes:new Uint8Array(await blob.arrayBuffer())});
  }
  files.push({name:'README.txt',bytes:new TextEncoder().encode('These are EIGHT STILL VIEWS, not animation frames. Add a real rig and animation clips for motion sheets.\n')});
  download(rawZip(files),'core_keys_8_static_views.zip');log('Eight still PNG views exported.','exportProgress');
 }catch(e){log(e.message,'exportProgress',true)}finally{state.selection=oldSelect;state.time=oldTime;state.exporting=false;updatePipelineUI();last=performance.now()}
}
async function refreshStatus(){try{const r=await fetch('/api/status');const d=await r.json();$('backendStatus').innerHTML='<span class="statusdot"></span>Local backend online';$('triposrHome').value=d.settings.triposr_home||'';$('triposrPython').value=d.settings.triposr_python||'';$('meshRes').value=d.settings.mc_resolution;$('chunkSize').value=d.settings.chunk_size;
  if(d.model_ready)log('Local TripoSR configured. Upload a T-pose to generate 3D.');else log('3D generation needs local TripoSR setup (⚙ Settings).');
  if(!d.background_ready)$('removeBgBtn').title='Install rembg in the application environment';
 }catch(e){$('backendStatus').textContent='Backend not connected';log('Launch with start_windows.bat — not by double-clicking index.html.','aiProgress',true)}}
$('imageInput').addEventListener('change',e=>{state.file=e.target.files?.[0];state.cutoutFile=null;const p=$('inputPreview');if(!state.file)return;p.src=URL.createObjectURL(state.file);p.style.display='block';$('uploadSymbol').style.display='none';$('uploadLabel').textContent=state.file.name;$('removeBgBtn').disabled=false;$('generateBtn').disabled=false;$('cutoutPreview').style.display='none';log('Image selected. Remove background or generate a 3D model.')});
$('removeBgBtn').addEventListener('click',askBg);$('generateBtn').addEventListener('click',generate);
$('glbInput').addEventListener('change',e=>{const f=e.target.files?.[0];if(!f)return;const url=URL.createObjectURL(f);loadModel(url,f.name,/^mesh\.glb$/i.test(f.name)?'triposr':'generic').finally(()=>URL.revokeObjectURL(url));});
$('demoBtn').addEventListener('click',()=>loadModel('/examples/demo_robot.glb','Sample cyber-armored T-pose · demo'));
$('inspectRigBtn').addEventListener('click',showRigDetails);
$('rigReportBtn').addEventListener('click',()=>download(new Blob([JSON.stringify(rigReport(),null,2)],{type:'application/json'}),'core_motion_rig_report.json'));
$('rigCloseBtn').addEventListener('click',()=>$('rigVeil').classList.remove('show'));
$('rigVeil').addEventListener('click',e=>{if(e.target===$('rigVeil'))$('rigVeil').classList.remove('show')});
$('riggedDemoBtn').addEventListener('click',()=>loadModel('/examples/rigged_robot_demo.glb','Rigged robot · genuine 3D clips','demo-rigged'));
$('motionInput').addEventListener('change',e=>{if(e.target.files?.[0])importAnimationGLB(e.target.files[0]);});
$('bonesToggle').addEventListener('change',e=>showBones(e.target.checked));
$('exportStaticBtn').addEventListener('click',exportEightStillViews);
$('resetViewBtn').addEventListener('click',()=>{state.zoom=1;camera.zoom=1;camera.updateProjectionMatrix();camera.position.set(0,1.5,10);camera.lookAt(0,1.5,0);setDirection('S')});
$('axisSelect').addEventListener('change',e=>selectAxis(e.target.value));
$('flipFacingBtn').addEventListener('click',flipFacing);
$buttons('#compass button',b=>setDirection(b.dataset.dir));
$buttons('#styles .styleChoice',b=>applyStyle(b.dataset.style));
const pres=$('presetList');for(const p of PRESETS){const b=document.createElement('button');b.className='preset'+(p[0]==='idle'?' active':'');b.dataset.preset=p[0];b.textContent=p[1];b.addEventListener('click',()=>setPreset(p[0]));pres.append(b)}
$('clipSelect').addEventListener('change',e=>{if(e.target.value!=='')chooseClip(state.clips[Number(e.target.value)])});
$('playBtn').addEventListener('click',()=>{
 if(!state.clips.length)return;
 // Clicking Play after a finished one-shot should replay from the beginning.
 if(!state.playing&&!loopPlayback()&&state.time>=currentPeriod()-0.0001)state.time=0;
 state.playing=!state.playing;$('playBtn').textContent=state.playing?'❚❚ Pause':'▶ Play';
 // Do not resample after pressing Pause; leave the corrected bones untouched.
 updateProgressUI();last=performance.now();
});
$('playbackMode').addEventListener('change',()=>{
 workspaceStopSequence();
 if(!loopPlayback()&&state.time>=currentPeriod()){
  state.time=currentPeriod();state.playing=false;$('playBtn').textContent='↻ Replay';
 }
 refreshPlaybackLabel();updateAnimation(state.time);updateProgressUI();
});
$('restartBtn').addEventListener('click',()=>{workspaceStopSequence();state.time=0;state.playing=true;$('playBtn').textContent='❚❚ Pause';updateAnimation(0);last=performance.now()});
$('scrub').addEventListener('input',e=>{workspaceStopSequence();state.playing=false;$('playBtn').textContent='▶ Play';state.time=currentPeriod()*Number(e.target.value)/1000;updateAnimation(state.time);updateProgressUI()});
speedSlider.addEventListener('input',e=>{workspaceStopSequence();state.speed=Number(e.target.value);$('speedVal').textContent=state.speed.toFixed(2)+'×'});
$('angleSlider').addEventListener('input',e=>{state.angle=Number(e.target.value);$('angleVal').textContent=state.angle+'°';camera.position.y=1.5+Math.sin(state.angle*Math.PI/180)*10;camera.position.z=Math.cos(state.angle*Math.PI/180)*10;camera.lookAt(0,1.5,0)});
$('exportOneBtn').addEventListener('click',()=>exportSheets(false));$('exportAllBtn').addEventListener('click',()=>exportSheets(true));
$('countSelect').addEventListener('change',()=>{labState.endKey='';updateAnimation(state.time);updateProgressUI()});
$('exportFitSlider').addEventListener('input',e=>$('exportFitVal').textContent=e.target.value+'%');
$('settingsButton').addEventListener('click',()=>$('settingsVeil').classList.add('show'));
$('closeSettings').addEventListener('click',()=>$('settingsVeil').classList.remove('show'));
$('settingsVeil').addEventListener('click',e=>{if(e.target===$('settingsVeil'))$('settingsVeil').classList.remove('show')});
$('saveSettings').addEventListener('click',async()=>{const body={triposr_home:$('triposrHome').value.trim(),triposr_python:$('triposrPython').value.trim(),mc_resolution:Number($('meshRes').value),chunk_size:Number($('chunkSize').value)};
 try{const r=await fetch('/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw Error(d.detail||'Could not save configuration');log('Settings saved.','settingsMessage');$('settingsVeil').classList.remove('show');refreshStatus();}catch(e){log(e.message,'settingsMessage',true)}});
// V4 MOTION LAB: non-destructive pose adjustments applied after the REAL GLB clip.
// For this 52-joint SkinTokens rig, leg A and leg B are mapped by their world positions,
// not by arbitrary guesses from bounding boxes. Other rigs retain basic playback/export.
const LAB_DEFAULT={footMode:'level',level:70,lock:35,pitchA:0,pitchB:0,endFootHold:false,loopBlend:12,attackType:'source',power:50,turn:50,timing:0};
const lab={...LAB_DEFAULT},labState={bones:null,anchors:null,basePosition:null,clipId:'',warned:false,endPose:null,endKey:'',loopStartPose:null};
const labBone=n=>state.model?.getObjectByName(n);
const qtmp=new THREE.Quaternion(),vtmp=new THREE.Vector3();
// V5.4: Map 28-joint and 52-joint SkinTokens rigs by hierarchy (not names).
// The 28-joint model has a 19-joint torso branch and 7-joint arms, unlike the older 52-joint model.
// GLB exporters can rename SkinTokens joints while retaining the identical hierarchy.
let footRigBones=[];
const rigChildren=(bone,set)=>bone.children.filter(ch=>ch.isBone&&set.has(ch));
function skinnedBones(){
 const meshes=[];state.model?.traverse(o=>{if(o.isSkinnedMesh&&o.skeleton?.bones?.length)meshes.push(o)});
 meshes.sort((a,b)=>b.skeleton.bones.length-a.skeleton.bones.length);
 // Only use actual skin joints, never non-deforming helper bones from the scene.
 return (meshes[0]?.skeleton?.bones||[]).filter(b=>b?.isBone);
}
function namedHumanoidRig(bones){
 const norm=s=>String(s||'').toLowerCase().replace(/[^a-z0-9]/g,'');
 const nmap=bones.map(b=>({b,n:norm(b.name)}));
 const search=(part,side)=>{
  const aliases={hip:['upleg','thigh'],knee:['lowerleg','shin','calf','leg'],ankle:['foot','ankle'],toe:['toebase','toe','ball']};
  const sides=side==='L'?['left','l']:['right','r'];
  const matches=nmap.filter(({n})=>{
   if(!aliases[part].some(a=>n.includes(a)))return false;
   if(part==='knee'&&(n.includes('upleg')||n.includes('thigh')))return false;
   if(part==='ankle'&&(n.includes('toe')||n.includes('ball')))return false;
   return n.includes(side==='L'?'left':'right')||sides.some(s=>n.startsWith(s)||n.includes(s+'foot')||n.includes(s+'leg')||n.includes(s+'thigh')||n.includes(s+'toe'));
  });
  return matches[0]?.b||null;
 };
 const L={hip:search('hip','L'),knee:search('knee','L'),ankle:search('ankle','L'),toe:search('toe','L')};
 const R={hip:search('hip','R'),knee:search('knee','R'),ankle:search('ankle','R'),toe:search('toe','R')};
 if(!L.ankle||!L.toe||!R.ankle||!R.toe||L.ankle===R.ankle)return null;
 const findName=(...terms)=>nmap.find(({n})=>terms.some(t=>n===t||n.endsWith(t)))?.b||null;
 return {hips:findName('hips','pelvis')||L.hip?.parent||null,
  spine:findName('spine','spine1'),chest:findName('spine2','chest'),upperSpine:findName('upperchest','spine3'),
  armA:findName('leftarm','leftupperarm'),elbowA:findName('leftforearm','leftlowerarm'),
  armB:findName('rightarm','rightupperarm'),elbowB:findName('rightforearm','rightlowerarm'),legs:[L,R]};
}
function mapSkinTokensByStructure(bones){
 // AssetFurnace can output either a 28-joint simplified SkinTokens skeleton
 // or a 52-joint extended skeleton. Their hip -> thigh -> shin -> ankle -> toe
 // chains are equivalent, but arm/spine counts differ. Never rely on bone names.
 if(bones.length<26)return null;
 const smallRig=bones.length<40;
 const minTorso=smallRig?17:20;
 const minArm=smallRig?6:8;
 const set=new Set(bones),children=b=>rigChildren(b,set);
 const subtreeSize=(bone,depth=0)=>depth>70?0:1+children(bone).reduce((n,ch)=>n+subtreeSize(ch,depth+1),0);
 function straightChain(root){
  const path=[root];let b=root;
  for(let i=0;i<8;i++){
   const cs=children(b);if(cs.length!==1)break;
   b=cs[0];path.push(b);
  }
  return path;
 }
 for(const hips of bones){
  const branches=children(hips);
  if(branches.length<3||branches.length>5)continue;
  const info=branches.map(root=>({root,path:straightChain(root),count:subtreeSize(root)}));
  const legBranches=info.filter(v=>v.path.length===4&&children(v.path[3]).length===0);
  const upper=info.filter(v=>v.count>=minTorso).sort((a,b)=>b.count-a.count)[0];
  if(legBranches.length!==2||!upper)continue;
  const spinalPath=straightChain(upper.root);
  const shoulderHub=spinalPath.find(b=>{
   const cs=children(b);return cs.filter(ch=>subtreeSize(ch)>=minArm).length>=2;
  });
  if(!shoulderHub)continue;
  const armBranches=children(shoulderHub).filter(ch=>subtreeSize(ch)>=minArm).sort((a,b)=>{
   // Stable ordering across GLB exporters even if names change.
   return bones.indexOf(a)-bones.indexOf(b);
  });
  if(armBranches.length<2)continue;
  // Keep left/right order stable: compare the actual positions in the model's rest pose.
  state.model.updateMatrixWorld(true);
  const xpos=bone=>bone.getWorldPosition(new THREE.Vector3()).x;
  legBranches.sort((a,b)=>xpos(b.root)-xpos(a.root));
  armBranches.sort((a,b)=>xpos(b)-xpos(a));
  const leg=info=>({hip:info.path[0],knee:info.path[1],ankle:info.path[2],toe:info.path[3]});
  return {hips,spine:spinalPath[0]||null,chest:spinalPath[1]||null,upperSpine:shoulderHub,
   armA:armBranches[0],elbowA:straightChain(armBranches[0])[1]||null,
   armB:armBranches[1],elbowB:straightChain(armBranches[1])[1]||null,
   legs:legBranches.map(leg)};
 }
 return null;
}
function mappedLowerBody(m){return !!(m?.legs?.length===2&&m.legs.every(l=>l.ankle?.isBone&&l.toe?.isBone))}
function activateFootRig(m,method){
 if(!mappedLowerBody(m))return false;
 labState.bones=m;labState.basePosition=state.model.position.clone();
 labState.anchors=null;labState.clipId='';labState.endPose=null;labState.endKey='';labState.loopStartPose=null;
 labState.mappingMethod=method;
 $('labMapping').textContent='✓ Foot controls active · '+method+'. Preview and PNG exports use the same correction.';
 if(state.selection.startsWith('clip::')){captureLabAnchors();updateAnimation(state.time)}
 return true;
}
function refreshManualRigSelectors(){
 const current=footRigBones=skinnedBones();
 const sels=['rigAnkleA','rigToeA','rigAnkleB','rigToeB'];
 for(const id of sels){
  const sel=$(id);sel.innerHTML='';
  const blank=document.createElement('option');blank.value='';blank.textContent='Select joint…';sel.append(blank);
  current.forEach((bone,i)=>{const o=document.createElement('option');o.value=String(i);o.textContent=String(i).padStart(2,'0')+' · '+(bone.name||'(unnamed)');sel.append(o)});
 }
 if(labState.bones)selectManualRigBones(labState.bones);
 $('rigMappingCount').textContent=current.length+' skinned bones detected.';
}
function selectManualRigBones(m){
 if(!m?.legs)return;
 const names=['rigAnkleA','rigToeA','rigAnkleB','rigToeB'];
 const targets=[m.legs[0].ankle,m.legs[0].toe,m.legs[1].ankle,m.legs[1].toe];
 names.forEach((id,i)=>$(id).value=String(footRigBones.indexOf(targets[i])));
}
function applyManualFootRig(quiet=false){
 const ids=['rigAnkleA','rigToeA','rigAnkleB','rigToeB'];
 const joints=ids.map(id=>{const value=$(id).value;return value===''?null:footRigBones[Number(value)]});
 if(joints.some(b=>!b)||new Set(joints).size!==4){if(!quiet)$('rigMapFeedback').textContent='Choose four distinct joints: each ankle and its toe.';return false}
 const [a,at,b,bt]=joints;
 const leg=(ankle,toe)=>({ankle,toe,knee:ankle.parent?.isBone?ankle.parent:null,
  hip:ankle.parent?.parent?.isBone?ankle.parent.parent:null});
 const legs=[leg(a,at),leg(b,bt)];
 const base=labState.bones||{hips:null,spine:null,chest:null,upperSpine:null,armA:null,elbowA:null,armB:null,elbowB:null};
 const candidate={...base,legs};
 if(legs[0].hip?.parent&&legs[0].hip.parent===legs[1].hip?.parent)candidate.hips=legs[0].hip.parent;
 activateFootRig(candidate,'manually selected ankle/toe joints');
 if(!quiet){$('rigMapFeedback').textContent='Manual foot mapping applied. Try changing Foot A pitch by 10° to verify, then save for this character.';updateFootRigAvailability();}
 return true;
}
function updateFootRigAvailability(){
 const enabled=Boolean(labState.bones);
 for(const id of ['footCalSave','footCalReset','footCalInspect','footFloorToggle'])$(id).disabled=!enabled;
 if(footFloorGuide)footFloorGuide.visible=enabled&&Boolean($('footFloorToggle').checked);
 refreshLabLabels();
}
function mapMotionBones(){
 labState.bones=null;labState.anchors=null;labState.clipId='';labState.endPose=null;labState.endKey='';labState.loopStartPose=null;
 footRigBones=[];
 if(!state.model)return;
 const exact={hips:labBone('bone_0'),spine:labBone('bone_1'),chest:labBone('bone_2'),upperSpine:labBone('bone_3'),
  armA:labBone('bone_6'),elbowA:labBone('bone_7'),armB:labBone('bone_25'),elbowB:labBone('bone_26'),
  legs:[{hip:labBone('bone_44'),knee:labBone('bone_45'),ankle:labBone('bone_46'),toe:labBone('bone_47')},
        {hip:labBone('bone_48'),knee:labBone('bone_49'),ankle:labBone('bone_50'),toe:labBone('bone_51')}]};
 const exactOk=Object.values(exact).every(v=>Array.isArray(v)?v.every(l=>Object.values(l).every(o=>o?.isBone)):v?.isBone);
 const bones=skinnedBones();
 let m=null,method='';
 if(exactOk){m=exact;method='original 52-bone SkinTokens names'}
 else if((m=mapSkinTokensByStructure(bones)))method='automatic '+bones.length+'-bone skeleton hierarchy';
 else if((m=namedHumanoidRig(bones)))method='named humanoid joints';
 if(m)activateFootRig(m,method);
 else $('labMapping').textContent='⚠ This rig is animated but its foot joints were not identified. Use the Manual foot joint mapping below. No source GLB has been changed.';
 refreshManualRigSelectors();updateFootRigAvailability();
 $('rigMapFeedback').textContent=m?'Mapped automatically. If a different joint responds, use Manual foot joint mapping to override.':'No automatic match. Select ankle and toe joints to enable foot controls.';
}
function sampleBase(t){
 if(!state.mixer||!state.selection.startsWith('clip::'))return;
 if(labState.basePosition)state.model.position.copy(labState.basePosition);
 state.mixer.setTime(Math.max(0,t));
 state.model.updateMatrixWorld(true);
}
function captureLabAnchors(){
 if(!labState.bones||!state.mixer||!state.selection.startsWith('clip::'))return;
 const key=state.selection;
 sampleBase(0);
 labState.anchors=labState.bones.legs.map(l=>state.model.worldToLocal(l.ankle.getWorldPosition(new THREE.Vector3()).clone()));
 // The source clip's exact start pose is cached, before corrective foot/IK layers.
 // Use it only for explicit loop seam blending. Source animation remains unchanged.
 const bones=[];state.model.traverse(o=>{if(o.isBone)bones.push(o)});
 labState.loopStartPose=bones.map(b=>({bone:b,position:b.position.clone(),rotation:b.quaternion.clone(),scale:b.scale.clone()}));
 labState.clipId=key;
}
const angleRad=deg=>deg*Math.PI/180;
function swingEnvelope(u){
 // Smooth anticipation and punchy impact, then a slow recovery. Zero at both endpoints.
 const gauss=(x,center,spread)=>Math.exp(-.5*((x-center)/spread)**2);
 return {wind:gauss(u,.19,.105),strike:gauss(u,.49,.12),recover:gauss(u,.71,.18)};
}
function rotateLocal(bone,axis,radians){if(!bone||!radians)return;bone.quaternion.multiply(new THREE.Quaternion().setFromAxisAngle(axis,radians)).normalize();}
function applySwordAccent(u){
 if(lab.attackType==='source'||!labState.bones)return;
 const m=labState.bones,amp=(lab.power/100),tw=(lab.turn/100),e=swingEnvelope(u);
 const flow=(-.52*e.wind + 1.05*e.strike - .23*e.recover),rev=lab.attackType==='reverse'?-1:1;
 const axX=new THREE.Vector3(1,0,0),axY=new THREE.Vector3(0,1,0),axZ=new THREE.Vector3(0,0,1);
 rotateLocal(m.spine,axY,rev*flow*tw*.24);
 rotateLocal(m.chest,axY,rev*flow*tw*.32);
 rotateLocal(m.upperSpine,axY,rev*flow*tw*.15);
 if(lab.attackType==='heavy'){
   rotateLocal(m.armA,axZ,amp*(-.40*e.wind+.52*e.strike-.14*e.recover));
   rotateLocal(m.armA,axX,amp*(-.24*e.wind+.20*e.strike));
   rotateLocal(m.elbowA,axX,amp*(-.16*e.wind+.22*e.strike));
   rotateLocal(m.armB,axZ,amp*(.16*e.wind-.19*e.strike));
 }else if(lab.attackType==='diagonal'){
   rotateLocal(m.armA,axX,amp*(-.42*e.wind+.48*e.strike));
   rotateLocal(m.armA,axZ,amp*(.15*e.wind-.34*e.strike));
   rotateLocal(m.elbowA,axZ,amp*(.20*e.wind-.28*e.strike));
   rotateLocal(m.armB,axY,amp*(-.14*e.strike));
 }else if(lab.attackType==='reverse'){
   rotateLocal(m.armB,axZ,amp*(.43*e.wind-.46*e.strike+.09*e.recover));
   rotateLocal(m.armB,axX,amp*(-.30*e.wind+.27*e.strike));
   rotateLocal(m.elbowB,axX,amp*(-.18*e.wind+.28*e.strike));
   rotateLocal(m.armA,axY,amp*(.18*e.strike));
 }
 state.model.updateMatrixWorld(true);
}
// Rotate a bone in WORLD space, converted properly into its parent's local coordinates.
function applyWorldRotation(bone,worldDelta){
 if(!bone||!bone.parent)return;
 const parentWorldQ=bone.parent.getWorldQuaternion(new THREE.Quaternion());
 const localDelta=parentWorldQ.clone().invert().multiply(worldDelta).multiply(parentWorldQ);
 bone.quaternion.premultiply(localDelta).normalize();
 bone.updateMatrixWorld(true);
}
function footLevel(leg,strength,addPitch){
 const ankle=leg.ankle,toe=leg.toe,origin=ankle.getWorldPosition(new THREE.Vector3()),fwd=toe.getWorldPosition(new THREE.Vector3()).sub(origin);
 const horizontal=new THREE.Vector3(fwd.x,0,fwd.z);
 if(horizontal.length()<1e-6)return;
 const pitch=Math.atan2(fwd.y,horizontal.length());
 const right=new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0),horizontal.normalize()).normalize();
 if(right.lengthSq()<1e-6)return;
 // Cap extreme inferred toe slopes so one bad bone does not flip the entire foot.
 const angle=THREE.MathUtils.clamp(pitch,-.65,.65)*strength + angleRad(addPitch);
 applyWorldRotation(ankle,new THREE.Quaternion().setFromAxisAngle(right,angle));
}
// V5.5: A/B pitch fields are direct ankle edits, not a request to recompute
// both feet (and both legs through the optional planted-feet IK solver).
// Freeze the current visible frame, then rotate ONLY the selected ankle by
// the difference in degrees. Play/scrub/export still resample the full source
// clip deterministically and apply both saved pitches.
function isolatedAnklePitchDelta(leg,deltaDegrees){
 if(!leg?.ankle||!leg?.toe||Math.abs(deltaDegrees)<1e-7)return;
 state.model.updateMatrixWorld(true);
 const anklePoint=leg.ankle.getWorldPosition(new THREE.Vector3());
 const forward=leg.toe.getWorldPosition(new THREE.Vector3()).sub(anklePoint);
 forward.y=0;
 if(forward.lengthSq()<1e-10)return;
 const pitchAxis=new THREE.Vector3().crossVectors(new THREE.Vector3(0,1,0),forward.normalize()).normalize();
 if(pitchAxis.lengthSq()<1e-10)return;
 applyWorldRotation(leg.ankle,new THREE.Quaternion().setFromAxisAngle(pitchAxis,angleRad(deltaDegrees)));
 state.model.updateMatrixWorld(true);
}
function editFootPitchIndependently(index){
 const input=$(index===0?'labPitchA':'labPitchB');
 const key=index===0?'pitchA':'pitchB';
 const value=THREE.MathUtils.clamp(Number(input.value)||0,-30,30);
 const delta=value-(Number(lab[key])||0);
 lab[key]=value;
 if(state.loaded&&labState.bones&&state.mixer&&state.selection.startsWith('clip::')){
  // Both feet otherwise move because the animation keeps playing during edits.
  state.playing=false;$('playBtn').textContent='▶ Play';last=performance.now();
  if(lab.footMode!=='off')isolatedAnklePitchDelta(labState.bones.legs[index],delta);
  updateProgressUI();
  const hint=$('independentFootHint');
  if(hint)hint.textContent=(index===0?'Foot A':'Foot B')+' edited alone at the paused frame. Playback and exports use the saved pitch.';
 }else if(state.loaded&&lab.footMode==='off'){
  const hint=$('independentFootHint');
  if(hint)hint.textContent='Contact correction is Off. Choose Level shoes to preview foot pitch.';
 }
}
function limitedCCD(leg,target,strength){
 if(strength<=0)return;
 const tip=leg.ankle;
 // Small, bounded solver for attack/idle contact. Full locomotion needs gait-aware stance windows.
 for(let iter=0;iter<5;iter++){
  for(const joint of [leg.knee,leg.hip]){
   const jp=joint.getWorldPosition(new THREE.Vector3());
   const v=tip.getWorldPosition(new THREE.Vector3()).sub(jp),w=target.clone().sub(jp);
   if(v.length()<1e-7||w.length()<1e-7)continue;
   const change=new THREE.Quaternion().setFromUnitVectors(v.normalize(),w.normalize());
   const aa=2*Math.acos(THREE.MathUtils.clamp(change.w,-1,1));
   const limited=Math.min(aa,.13)*strength;
   if(limited<1e-6)continue;
   let axis=new THREE.Vector3(change.x,change.y,change.z);
   if(axis.lengthSq()<1e-9)continue;
   axis.normalize();
   applyWorldRotation(joint,new THREE.Quaternion().setFromAxisAngle(axis,limited));
  }
  if(tip.getWorldPosition(new THREE.Vector3()).distanceTo(target)<.002)break;
 }
}
function applyFootContact(){
 if(!labState.bones||lab.footMode==='off')return;
 const hasStriding=/walk|run|sprint|sneak|swim/i.test(state.selection);
 const strength=lab.lock/100;
 // Stance-locking a continuous walking cycle without ground-contact tags would cause more foot sliding.
 // Thus IK is ONLY applied on stationary/attack clips here; leveling remains available on all clips.
 if(lab.footMode==='lock'&&!hasStriding&&labState.anchors&&labState.bones.legs.every(l=>l.knee?.isBone&&l.hip?.isBone)){
  labState.bones.legs.forEach((leg,i)=>{
   const target=state.model.localToWorld(labState.anchors[i].clone());
   limitedCCD(leg,target,strength);
  });
 }
 labState.bones.legs.forEach((leg,i)=>footLevel(leg,lab.level/100,i===0?Number(lab.pitchA):Number(lab.pitchB)));
}
// Blend the source 3D joint poses across the last part of a forced loop.
// Unlike a pause, this is continuous motion and affects playback + sprite exports alike.
// Only mapped SkinTokens rigs can use this control; 0% = original source clip.
function blendLoopSeam(cycle){
 if(!labState.bones||!loopPlayback()||lab.loopBlend<=0||!labState.loopStartPose)return;
 const range=THREE.MathUtils.clamp(lab.loopBlend/100,0,0.30);
 const from=1-range;
 if(cycle<=from)return;
 const w=THREE.MathUtils.smoothstep(cycle,from,1);
 for(const p of labState.loopStartPose){
  p.bone.position.lerp(p.position,w);
  p.bone.quaternion.slerp(p.rotation,w).normalize();
  p.bone.scale.lerp(p.scale,w);
 }
 state.model.updateMatrixWorld(true);
}
// End-frame correction for a one-shot attack: freeze the lower-body source pose
// at the penultimate exported frame, and blend into it without touching the torso.
// Works in preview AND in sprite-sheet rendering; source GLB and saved sliders remain unchanged.
function holdLastFrameFeet(cycle, period){
 if(!labState.bones||!lab.endFootHold||loopPlayback()||lab.footMode==='off')return;
 const n=Math.max(2,Number($('countSelect').value)||8);
 const holdAt=(n-2)/(n-1); // 8-frame sequence: freeze foot motion at frame 7 (6/7).
 if(cycle<=holdAt)return;
 const key=state.selection+'|'+n;
 if(labState.endKey!==key){
  const b=labState.bones;
  const legBones=[b.hips,...b.legs.flatMap(l=>[l.hip,l.knee,l.ankle,l.toe])].filter(Boolean);
  sampleBase(holdAt*period);
  labState.endPose=legBones.map(o=>({bone:o,position:o.position.clone(),rotation:o.quaternion.clone()}));
  labState.endKey=key;
  sampleBase(cycle*period); // Restore current pose before blending.
 }
 const weight=THREE.MathUtils.smoothstep(cycle,holdAt,Math.min(1,holdAt+0.045));
 for(const p of labState.endPose){
  p.bone.position.lerp(p.position,weight);
  p.bone.quaternion.slerp(p.rotation,weight).normalize();
 }
 state.model.updateMatrixWorld(true);
}
function updateMotionLab(time){
 if(!state.mixer||!state.selection.startsWith('clip::'))return;
 const period=currentPeriod();
 const cycle=period>0?(loopPlayback()?((time%period)+period)%period/period:THREE.MathUtils.clamp(time/period,0,.999999)):0;
 // Phase-warp is smooth, monotone, and periodic at the loop boundary.
 const warped=THREE.MathUtils.clamp(cycle + .0013*lab.timing*Math.sin(2*Math.PI*cycle),0,.999999);
 sampleBase(warped*period);
 if(!labState.bones)return;
 if(labState.clipId!==state.selection)captureLabAnchors();
 // Forced loops blend smoothly back to the start pose. One-shots retain their end.
 blendLoopSeam(warped);
 // Legacy last-frame pose hold is optional and OFF by default in V4.3.
 holdLastFrameFeet(warped,period);
 applySwordAccent(warped);
 applyFootContact();
}
function refreshLabLabels(){
 const f=id=>$(id);lab.footMode=f('labFootMode').value;lab.endFootHold=f('labEndFootHold').checked;lab.loopBlend=Number(f('labLoopBlend').value);
 for(const [key,id,display] of [['level','labLevel','labLevelVal'],['lock','labLock','labLockVal'],['loopBlend','labLoopBlend','labLoopBlendVal'],['power','labPower','labPowerVal'],['turn','labTurn','labTurnVal'],['timing','labTiming','labTimingVal']]){
  lab[key]=Number(f(id).value);f(display).textContent=(key==='timing'?(lab[key]>0?'+':'')+lab[key]:lab[key])+'%';
 }
 for(const key of ['pitchA','pitchB'])lab[key]=THREE.MathUtils.clamp(Number(f('lab'+(key==='pitchA'?'PitchA':'PitchB')).value)||0,-30,30);
 lab.attackType=f('labAttackType').value;
 $('labNotice').textContent=labState.bones?'Corrections are live in preview and PNG exports. IK only applies to non-walking clips; no AI animation or weapon mesh is created.':'This file lacks the mapped 52-bone SkinTokens rig; the original animation still plays.';
}
function setLabFromProfile(profile){
 for(const [key,def] of Object.entries(LAB_DEFAULT)){
  const value=profile[key];
  if(typeof def==='boolean')lab[key]=typeof value==='boolean'?value:def;
  else if(typeof def==='number')lab[key]=Number.isFinite(Number(value))?Number(value):def;
  else lab[key]=(typeof value==='string')?value:def;
 }
 $('labFootMode').value=['off','level','lock'].includes(lab.footMode)?lab.footMode:'level';
 $('labEndFootHold').checked=Boolean(lab.endFootHold);$('labLoopBlend').value=lab.loopBlend;
 $('labAttackType').value=['source','heavy','diagonal','reverse'].includes(lab.attackType)?lab.attackType:'source';
 for(const [key,id] of [['level','labLevel'],['lock','labLock'],['loopBlend','labLoopBlend'],['power','labPower'],['turn','labTurn'],['timing','labTiming'],['pitchA','labPitchA'],['pitchB','labPitchB']])$(id).value=lab[key];
 refreshLabLabels();if(state.loaded)updateAnimation(state.time);
}

// V5.2 ONE-TIME FOOT CALIBRATION
// Source assets from Pixal3D can contain a toe-up rest pose because one front
// reference has no side/depth constraint. This applies consistent per-character
// ankle pitch across all loaded clips. It does NOT change the source GLB bind
// pose or change what AssetFurnace displays; only Core Motion preview + exports.
const FOOT_CALIBRATION_VERSION=1;
const FOOT_CALIBRATION_PREFIX='core_motion_feet_v52:';
const footFields=['footMode','level','lock','pitchA','pitchB'];
function calibrationStorageKey(source,id){
 const clean=String(id||'unnamed').trim().toLowerCase().replace(/\s+/g,' ').slice(0,160);
 return FOOT_CALIBRATION_PREFIX+String(source||'glb')+':'+clean;
}
function savedFootPayload(){
 return {version:FOOT_CALIBRATION_VERSION,
  footMode:lab.footMode,level:lab.level,lock:lab.lock,pitchA:lab.pitchA,pitchB:lab.pitchB,
  manualJoints:labState.mappingMethod==='manually selected ankle/toe joints' ? ['rigAnkleA','rigToeA','rigAnkleB','rigToeB'].map(id=>$(id).value) : null,
  savedAt:new Date().toISOString()};
}
function describeFootSave(text,isError=false){
 const el=$('footCalibrationStatus');if(!el)return;
 el.textContent=text;el.style.color=isError?'#ff9d9d':'#b6d2e0';
}
function restoreFootCalibration(){
 // Every new character starts at neutral per-character defaults rather than
 // inheriting ankle rotations from the last imported GLB.
 const data={...LAB_DEFAULT};
 const key=state.calibrationKey;
 let restored=false;let savedJointIndexes=null;
 if(key){try{
  const val=localStorage.getItem(key);
  if(val){const saved=JSON.parse(val);if(saved?.version===FOOT_CALIBRATION_VERSION){
    for(const k of footFields)if(saved[k]!==undefined)data[k]=saved[k];
    savedJointIndexes=Array.isArray(saved.manualJoints)?saved.manualJoints:null;
    restored=true;
  }}
 }catch(e){describeFootSave('Browser storage unavailable: '+e.message,true)}}
 for(const k of footFields)lab[k]=data[k];
 if(savedJointIndexes?.length===4&&footRigBones.length){
  ['rigAnkleA','rigToeA','rigAnkleB','rigToeB'].forEach((id,i)=>$(id).value=String(savedJointIndexes[i]));
  applyManualFootRig(true);
 }
 $('labFootMode').value=['off','level','lock'].includes(lab.footMode)?lab.footMode:'level';
 $('labLevel').value=lab.level;$('labLock').value=lab.lock;
 $('labPitchA').value=lab.pitchA;$('labPitchB').value=lab.pitchB;
 refreshLabLabels();
 const mapped=Boolean(labState.bones);
 updateFootRigAvailability();
 describeFootSave(mapped?(restored?'Saved foot calibration restored for this character.':'No calibration saved yet. Adjust once, then save for all its clips.'):'Needs a SkinTokens 52-bone rig.');
}
function saveFootCalibration(){
 if(!state.calibrationKey||!labState.bones){describeFootSave('Import a SkinTokens-rigged character first.',true);return}
 refreshLabLabels();
 try{localStorage.setItem(state.calibrationKey,JSON.stringify(savedFootPayload()));
   describeFootSave('Saved for this character. All current and future attached clips will use these foot settings.');
 }catch(e){describeFootSave('Could not save in browser: '+e.message,true)}
}
function clearFootCalibration(){
 if(!state.calibrationKey)return;
 try{localStorage.removeItem(state.calibrationKey)}catch(e){describeFootSave(e.message,true);return}
 restoreFootCalibration();if(state.loaded)updateAnimation(state.time);
 describeFootSave('Saved calibration reset. Original GLB and all animation files remain unchanged.');
}
function inspectFootCalibration(){
 if(!state.loaded||!labState.bones)return;
 // Inspect in a known side-on view and hold a pose without any unwanted pause resampling.
 const idle=state.clips.find(c=>/idle|stand|breath/i.test(c.name));
 if(idle)chooseClip(idle);
 setDirection('E');state.playing=false;$('playBtn').textContent='▶ Play';
 state.time=idle?Math.min(.12,currentPeriod()*.2):0;
 updateAnimation(state.time);updateProgressUI();
 $('footFloorToggle').checked=true;
 if(footFloorGuide)footFloorGuide.visible=true;
 describeFootSave('Side view paused. Level each sole with Foot Leveling and A/B pitch, then click Save for this character.');
}
function markCalibrationChanged(){
 if(!state.calibrationKey||!labState.bones)return;
 describeFootSave('Foot adjustments changed. Click “Save for this character” to reuse across reloads and all clips.');
}
function initFootCalibration(){
 $('footCalSave').addEventListener('click',saveFootCalibration);
 $('footCalReset').addEventListener('click',clearFootCalibration);
 $('footCalInspect').addEventListener('click',inspectFootCalibration);
 $('footFloorToggle').addEventListener('change',e=>{if(footFloorGuide)footFloorGuide.visible=Boolean(e.target.checked&&state.loaded)});
 for(const id of ['labFootMode','labLevel','labLock','labPitchA','labPitchB'])
  $(id).addEventListener('input',markCalibrationChanged);
 $('rigApplyManual').addEventListener('click',()=>applyManualFootRig());
 $('rigAutoDetect').addEventListener('click',()=>{mapMotionBones();restoreFootCalibration();});
}
function initMotionLab(){
 // Pitch editing is intentionally separate: update only the chosen ankle on the
 // currently visible, paused pose. Re-running IK here could shift both feet.
 for(const id of ['labFootMode','labLevel','labLock','labEndFootHold','labLoopBlend','labAttackType','labPower','labTurn','labTiming'])$(id).addEventListener('input',()=>{refreshLabLabels();if(state.loaded)updateAnimation(state.time)});
 $('labPitchA').addEventListener('input',()=>editFootPitchIndependently(0));
 $('labPitchB').addEventListener('input',()=>editFootPitchIndependently(1));
 $('saveMotionProfile').addEventListener('click',()=>download(new Blob([JSON.stringify({studio:'Core Motion V4.3',version:4,rig:'SkinTokens bone_0-51',playbackMode:$('playbackMode').value,settings:lab},null,2)],{type:'application/json'}),'core_motion_foot_and_sword_profile.json'));
 $('loadMotionProfile').addEventListener('click',()=>$('motionProfileFile').click());
 $('motionProfileFile').addEventListener('change',async(e)=>{const file=e.target.files?.[0];if(!file)return;try{const data=JSON.parse(await file.text());setLabFromProfile(data.settings||data);if(['auto','once','loop'].includes(data.playbackMode))$('playbackMode').value=data.playbackMode;refreshPlaybackLabel();$('labNotice').textContent='Profile loaded. Preview and sprite exports use these settings.';markCalibrationChanged();}catch(err){$('labNotice').textContent='Could not read profile: '+err.message;}e.target.value='';});
 refreshLabLabels();
}

initMotionLab();setup3d();initFootCalibration();buildTimeline();refreshStatus();



// ------------------------------------------------------- V5 local AssetFurnace bridge
// Calls ONLY this studio's local FastAPI bridge, which in turn talks to
// AssetFurnace on 127.0.0.1:8777. No paid API or direct browser CORS calls.
const furnace={online:false,moves:[],assets:[],job:null,pollTimer:null};
function furnaceMessage(message,error=false){const el=$('furnaceProgress');el.textContent=message;el.classList.toggle('error',error)}
async function furnaceRequest(path, options){
 const res=await fetch('/api/furnace/'+path,{cache:'no-store',...(options||{})});
 let data;try{data=await res.json()}catch{throw Error('Invalid response from local AI bridge')}
 if(!res.ok)throw Error(data.detail||data.error||'AI engine request failed');
 return data;
}
function furnaceSelectMoves(moves){
 furnace.moves=moves||[];const select=$('furnaceMove'); const prev=select.value;
 select.replaceChildren();
 for(const move of furnace.moves){const option=document.createElement('option');option.value=move.id;option.textContent=move.label;select.appendChild(option)}
 v71RefreshCatalog();
 if(prev&&furnace.moves.some(x=>x.id===prev))select.value=prev;
 else{const idle=furnace.moves.find(m=>/idle/i.test(m.id+' '+m.label));if(idle)select.value=idle.id}
 $('furnaceMore').disabled=!furnace.moves.length||!$('furnaceAssets').value;
}
async function furnaceGetStatus(){
 try{
  const s=await furnaceRequest('status');furnace.online=Boolean(s.online);
  $('furnaceHome').value=s.home||'C:\\AI\\AssetFurnace';
  $('furnaceState').textContent=s.online?'AI engine connected':'AI engine offline';
  $('furnaceNote').textContent=s.message||'';
  $('furnaceStart').disabled=s.online;
  $('furnaceCreate').disabled=!s.online||!state.file;
  if(s.online){
   try{const m=await furnaceRequest('moves');furnaceSelectMoves(m.moves||[])}catch(e){furnaceMessage('Could not load animation list: '+e.message,true)}
   await furnaceRefreshAssets(false);
  }
  return s;
 }catch(e){furnaceMessage(e.message,true);return {online:false}}
}
async function furnaceStart(){
 $('furnaceStart').disabled=true;furnaceMessage('Starting AssetFurnace locally…');
 try{
  const result=await furnaceRequest('start',{method:'POST'});
  furnaceMessage(result.message);
  // Poll for readiness, but never block the browser or claim success prematurely.
  for(let tries=0;tries<45;tries++){
   await new Promise(r=>setTimeout(r,1800));
   const status=await furnaceGetStatus();if(status.online){furnaceMessage('AI ready. Select a T-pose image and a motion.');return;}
  }
  furnaceMessage('Still offline. Check outputs/furnace_background.log in your studio folder.',true);
 }catch(e){furnaceMessage(e.message,true)}finally{$('furnaceStart').disabled=furnace.online}
}
async function furnaceRefreshAssets(showMessage=true){
 if(!furnace.online)return;
 try{
  const result=await furnaceRequest('assets');furnace.assets=result.assets||[];
  const current=$('furnaceAssets').value;
  $('furnaceAssets').replaceChildren();
  const placeholder=document.createElement('option');placeholder.value='';placeholder.textContent='Select saved character…';$('furnaceAssets').appendChild(placeholder);
  for(const asset of furnace.assets){
   if(asset.kind==='prop'||asset.kind==='prop set')continue;
   const o=document.createElement('option');o.value=asset.id;
   o.textContent=asset.name+(asset.has_rig?' · rigged':' · 3D')+(asset.clips?.length?' · '+asset.clips.length+' moves':'');
   $('furnaceAssets').appendChild(o);
  }
  if([...$('furnaceAssets').options].some(o=>o.value===current))$('furnaceAssets').value=current;
  $('furnaceMore').disabled=!$('furnaceAssets').value||!furnace.moves.length;
  v71RefreshCatalog();
  if(showMessage)furnaceMessage('AssetFurnace library refreshed. Select a character to load or add a move.');
 }catch(e){if(showMessage)furnaceMessage(e.message,true)}
}
function furnaceRunning(runId){
 furnace.job=runId;$('furnaceJobBox').style.display='block';
 $('furnaceCreate').disabled=true;$('furnaceMore').disabled=true;
 furnacePoll(runId);
}
async function furnacePoll(runId){
 if(furnace.job!==runId)return;
 try{
  const job=await furnaceRequest('run/'+encodeURIComponent(runId));
  const finished=job.done||[];const status=String(job.status||'running').toLowerCase();
  const stage=job.current?.step||job.current?.name||job.step||'';
  furnaceMessage('AI pipeline: '+status+(stage?' · '+stage:'')+(finished.length?'\nCompleted stages: '+finished.map(x=>typeof x==='string'?x:(x.step||x.name||'step')).join(', '):''));
  if(['done','finished','complete','completed','error','failed','cancelled','canceled'].includes(status)){
   furnace.job=null;$('furnaceJobBox').style.display='none';
   $('furnaceCreate').disabled=!furnace.online||!state.file;
   if(['error','failed','cancelled','canceled'].includes(status)){
    furnaceMessage('AI pipeline '+status+'. '+String(job.error||job.message||'Check AssetFurnace job log.'),true);return;
   }
   await furnaceRefreshAssets(false);
   furnaceMessage('AI job finished. Select your new character in the library and click Load into editor.');
    v71GuideMessage('3D generation completed. Select the new character in the AI library and click Load into editor.');
   return;
  }
  furnace.pollTimer=setTimeout(()=>furnacePoll(runId),1800);
 }catch(e){furnaceMessage(e.message+'; retrying status…',true);furnace.pollTimer=setTimeout(()=>furnacePoll(runId),5000)}
}
async function furnaceCreate(){
 if(!state.file){furnaceMessage('Upload a T-pose PNG in Section 01 first.',true);return}
 if(furnace.job){furnaceMessage('A job is already running.',true);return}
 try{
  const form=new FormData();form.append('image',state.cutoutFile||state.file);
  form.append('title',state.file.name.replace(/\.[^.]+$/,'').replace(/[-_]/g,' ').slice(0,80));
  form.append('stop_after',$('furnaceStop').value);
  form.append('first_move',$('furnaceMove').value);
  furnaceMessage('Submitting to local Pixal3D → Finish → SkinTokens…');
  const result=await furnaceRequest('create',{method:'POST',body:form});
  if(!result.run_id)throw Error('AssetFurnace did not return a generation ID.');
  furnaceRunning(result.run_id);
 }catch(e){furnaceMessage(e.message,true)}
}
async function furnaceAllClips(){
 const id=$('furnaceAssets').value;
 if(!id||!state.loaded||!state.rigInfo?.skinnedMeshes){
  furnaceMessage('First load the selected rigged character into the editor.',true);return;
 }
 const asset=furnace.assets.find(a=>a.id===id);
 if(!asset?.clips?.length){furnaceMessage('This asset has no saved motion clips.',true);return}
 const button=$('furnaceAllClips');button.disabled=true;
 let added=0,skipped=0,failed=0;
 try{
  for(let i=0;i<asset.clips.length;i++){
   const name=asset.clips[i]||('Clip '+i);
   if(state.clips.some(c=>c.name.toLowerCase()===name.toLowerCase())){skipped++;continue}
   furnaceMessage('Attaching '+(i+1)+'/'+asset.clips.length+': '+name);
   try{
    const result=await furnaceRequest('clip/'+encodeURIComponent(id)+'/'+i);
    const response=await fetch(result.url);
    if(!response.ok)throw Error('Unable to download local clip');
    const before=state.clips.length;
    const blob=await response.blob();
    await importAnimationGLB(new File([blob],(result.name||name)+'.glb',{type:'model/gltf-binary'}));
    if(state.clips.length>before)added++;else failed++;
   }catch(e){failed++;furnaceMessage(name+': '+e.message,true)}
  }
  furnaceMessage('Motion library: '+added+' added, '+skipped+' already loaded, '+failed+' incompatible or unavailable.');
 }finally{button.disabled=false}
}
async function furnaceMore(){
 const id=$('furnaceAssets').value,move=$('furnaceMove').value;
 if(!id||!move){furnaceMessage('Select a rigged character and animation.',true);return}
 try{
  const result=await furnaceRequest('animate-existing',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({asset_id:id,move})});
  if(!result.run_id)throw Error('AssetFurnace did not return a generation ID.');
  furnaceRunning(result.run_id);
 }catch(e){furnaceMessage(e.message,true)}
}
async function furnaceImport(){
 const id=$('furnaceAssets').value;
 if(!id){furnaceMessage('Select an AssetFurnace character first.',true);return}
 try{
  furnaceMessage('Importing your local character, skeleton, and available clips…');
  const result=await furnaceRequest('import/'+encodeURIComponent(id));
  await loadModel(result.url+'?v='+Date.now(),result.name||'AssetFurnace character','assetfurnace',id);
   furnaceMessage('Character imported. Choose an art style, preview available animation clips, then export.');
   v71GuideMessage('3D character loaded. Choose an art style, then pick an animation.');
 }catch(e){furnaceMessage(e.message,true)}
}
async function furnaceCancel(){
 if(!furnace.job)return;
 try{await furnaceRequest('cancel/'+encodeURIComponent(furnace.job),{method:'POST'});furnaceMessage('Cancel requested. Waiting for local AI engine to stop.');}
 catch(e){furnaceMessage(e.message,true)}
}
function initFurnace(){
 $('furnaceStart').addEventListener('click',furnaceStart);
 $('furnaceCheck').addEventListener('click',furnaceGetStatus);
 $('furnaceRefresh').addEventListener('click',()=>furnaceRefreshAssets(true));
 $('furnaceCreate').addEventListener('click',furnaceCreate);
 $('furnaceMore').addEventListener('click',furnaceMore);
 $('furnaceImport').addEventListener('click',furnaceImport);
 $('furnaceAllClips').addEventListener('click',furnaceAllClips);
 $('furnaceCancel').addEventListener('click',furnaceCancel);
 $('imageInput').addEventListener('change',()=>{
  $('furnaceCreate').disabled=!furnace.online||!state.file;
  if(state.file)furnaceMessage('T-pose selected. Use Remove Background if needed, then Generate.');
 });
 $('furnaceAssets').addEventListener('change',()=>{
  const a=furnace.assets.find(a=>a.id===$('furnaceAssets').value);
  $('furnaceMore').disabled=!a?.has_rig||!furnace.moves.length;
  if(a)furnaceMessage(a.name+' · '+(a.has_rig?'Rigged':'Not rigged')+' · '+(a.clips?.length||0)+' motion clips.');
    v71RefreshCatalog();
 });
 $('furnaceSavePath').addEventListener('click',async()=>{
  try{
   const result=await furnaceRequest('config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({furnace_home:$('furnaceHome').value.trim()})});
   furnaceMessage('AssetFurnace path saved: '+result.home);await furnaceGetStatus();
  }catch(e){furnaceMessage(e.message,true)}
 });
 // Never overwrites V4.3 correction settings or GLB file.
 furnaceGetStatus();
}
initFurnace();


// V6.4: built-in local updater. All requests go to the loopback Studio backend.
// A separate launcher stops/restarts the backend when a verified update is queued.
const UPDATE_API='/api/updater';
let updateHasCandidate=false, updateStaged=false, updateCanRollback=false, updateBusy=false, updatePolling=false, updatePreviousVersion='';
function updateMessage(value,error=false){
 const node=$('updateStatus');if(!node)return;
 node.textContent=value;node.style.color=error?'#ff9ba4':'#c1dbed';
}
async function updateRequest(endpoint,options={}){
 const res=await fetch(UPDATE_API+endpoint,{cache:'no-store',...options});
 let value={};try{value=await res.json()}catch{}
 if(!res.ok)throw Error(value.detail||('Update service returned '+res.status));
 return value;
}
async function updateGetStatus(){
 const status=await updateRequest('/status');
 $('installedVersion').textContent='V'+status.version;
 if(document.activeElement!==$('updateFeedUrl'))$('updateFeedUrl').value=status.feed_url||'';
 updateStaged=!!status.has_staged_update; updateCanRollback=!!status.can_rollback;
 $('rollbackUpdate').disabled=updateBusy||!updateCanRollback;
 $('applyUpdate').disabled=updateBusy||!updateStaged;
 return status;
}
function updateSetBusy(b){
 updateBusy=b;
 for(const id of ['checkUpdate','downloadUpdate','applyUpdate','stageManualUpdate','saveUpdateSource','rollbackUpdate']){
  $(id).disabled=b || (id==='downloadUpdate'&&!updateHasCandidate) || (id==='applyUpdate'&&!updateStaged) || (id==='rollbackUpdate'&&!updateCanRollback);
 }
}
async function updateCheck(){
 updateSetBusy(true);updateMessage('Checking the configured release source…');
 try{
  const latest=await updateRequest('/check');
  updateHasCandidate=!!latest.available;
  updateMessage(latest.available?'New version V'+latest.version+' available.\n'+(latest.notes||'Click Download & verify to prepare it.'):'You are already running the latest published release (V'+latest.current_version+').');
 }catch(e){updateHasCandidate=false;updateMessage(e.message,true)}finally{updateSetBusy(false)}
}
async function updateStageRemote(){
 updateSetBusy(true);updateMessage('Downloading the update and verifying its checksums…');
 try{
  const result=await updateRequest('/prepare',{method:'POST'});
  updateStaged=true;updateMessage('V'+result.version+' is verified and ready. Click Install & restart.');
 }catch(e){updateMessage(e.message,true)}finally{updateSetBusy(false);$('applyUpdate').disabled=!updateStaged}
}
async function updateStageFile(){
 const file=$('manualUpdateFile').files?.[0];
 if(!file){updateMessage('Choose a new Core Motion in-app update ZIP first.',true);return}
 updateSetBusy(true);updateMessage('Verifying '+file.name+'…');
 try{
  const data=new FormData();data.append('package',file,file.name);
  const result=await updateRequest('/upload',{method:'POST',body:data});
  updateStaged=true;updateMessage('V'+result.version+' package verified and ready. Click Install & restart.');
 }catch(e){updateMessage(e.message,true)}finally{updateSetBusy(false);$('applyUpdate').disabled=!updateStaged}
}
async function updateInstall(rollback=false){
 if(!window.confirm(rollback?'Restore the previous Core Motion version? Your model and settings files will stay untouched.':'Install the verified update now? The local Studio will restart automatically.'))return;
 updateSetBusy(true);updateMessage('Stopping the local server, applying the update, then restarting. Keep this tab open…');
 try{
  updatePreviousVersion=(await updateGetStatus()).version;
  await updateRequest(rollback?'/rollback':'/apply',{method:'POST'});
  updatePolling=true;
  let attempts=0;
  const polling=async()=>{
   if(!updatePolling)return;
   try{
    const fresh=await updateGetStatus();
    if(fresh.state==='error'){
     updateMessage('Update failed: '+fresh.message,true);updatePolling=false;updateSetBusy(false);return;
    }
    if(fresh.state==='success'&&!fresh.queued&&fresh.message&&fresh.version!==updatePreviousVersion){
     updatePolling=false;updateMessage(fresh.message+'\nReloading Studio…');setTimeout(()=>location.reload(),1200);return;
    }
   }catch{} // Temporary disconnect is expected while the local server restarts.
   if(++attempts>100){updateMessage('The Studio has not reconnected. If necessary, run start_windows.bat again. Your files are backed up.',true);updatePolling=false;updateSetBusy(false);return;}
   setTimeout(polling,1500);
  };
  setTimeout(polling,1500);
 }catch(e){updateMessage(e.message,true);updateSetBusy(false)}
}
function initUpdater(){
 const open=async()=>{
  $('updateVeil').classList.add('show');
  try{
   const status=await updateGetStatus();
   updateMessage(status.message||('Installed: Core Motion V'+status.version+'.\nConfigure a GitHub release source, or choose a future update ZIP.'));
  }catch(e){updateMessage('Cannot reach local updater: '+e.message,true)}
 };
 $('updateButton').addEventListener('click',open);
 $('closeUpdate').addEventListener('click',()=>$('updateVeil').classList.remove('show'));
 $('updateVeil').addEventListener('click',(e)=>{if(e.target===$('updateVeil'))$('updateVeil').classList.remove('show')});
 $('checkUpdate').addEventListener('click',updateCheck);
 $('downloadUpdate').addEventListener('click',updateStageRemote);
 $('applyUpdate').addEventListener('click',()=>updateInstall(false));
 $('rollbackUpdate').addEventListener('click',()=>updateInstall(true));
 $('stageManualUpdate').addEventListener('click',updateStageFile);
 $('saveUpdateSource').addEventListener('click',async()=>{
  try{
   const r=await updateRequest('/source',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({feed_url:$('updateFeedUrl').value.trim()})});
   updateMessage(r.feed_url?'Release source saved. Click Check for updates.':'Release source cleared.');
  }catch(e){updateMessage(e.message,true)}
 });
}
initUpdater();

// V6.8 Motion Workspace: non-destructive clip recipes and sequential preview.
// No animation tracks, original GLBs, or V6.7 sprite-rendering functions are rewritten.
function wsKey(){return 'coremotion-motion-workspace-v1::'+(state.calibrationKey||'temporary-model')}
const wsClamp=(n,min,max)=>Math.min(max,Math.max(min,Number.isFinite(+n)?+n:min));
function wsSafeStep(raw){
 if(!raw||typeof raw.source!=='string')return null;
 const ease=['linear','ease-in','ease-out','ease-in-out'];
 const keyframes=Array.isArray(raw.keyframes)?raw.keyframes.filter(k=>k&&typeof k.bone==='string'&&k.bone.length>0).slice(0,32).map(k=>({
  bone:k.bone.slice(0,100),at:Math.round(wsClamp(k.at,1,99)),rx:wsClamp(k.rx,-45,45),ry:wsClamp(k.ry,-45,45),rz:wsClamp(k.rz,-45,45)
 })):[];
 return {source:raw.source.slice(0,200),label:String(raw.label||raw.source).slice(0,80),
  speed:wsClamp(raw.speed,0.25,2),start:wsClamp(raw.start,0,94),end:wsClamp(raw.end,6,100),
  repeats:Math.round(wsClamp(raw.repeats,1,4)),
  easing:ease.includes(raw.easing)?raw.easing:'linear',fade:wsClamp(raw.fade??0.18,0,.8),keyframes};
}
function workspaceLoad(){
 const key=wsKey();if(motionWorkspace.key===key)return;
 workspaceStopSequence();motionWorkspace.key=key;motionWorkspace.favorites=new Set();motionWorkspace.variants=[];motionWorkspace.queue=[];
 try{
  const v=JSON.parse(localStorage.getItem(key)||'{}');
  if(Array.isArray(v.favorites))motionWorkspace.favorites=new Set(v.favorites.filter(x=>typeof x==='string').slice(0,200));
  if(Array.isArray(v.variants))motionWorkspace.variants=v.variants.slice(0,70).map(x=>({...wsSafeStep(x),id:String(x.id||''),label:String(x.label||'Unnamed').slice(0,80)})).filter(x=>x.source&&x.id&&x.start<x.end);
  if(Array.isArray(v.queue))motionWorkspace.queue=v.queue.slice(0,80).map(wsSafeStep).filter(x=>x&&x.start<x.end);
 }catch{} // Safe fallback if browser storage is missing or invalid.
 motionWorkspace.nextId=1+motionWorkspace.variants.reduce((n,v)=>Math.max(n,Number(v.id)||0),0);
}
function workspaceSave(){
 if(!motionWorkspace.key)return;
 try{localStorage.setItem(motionWorkspace.key,JSON.stringify({schema:'coremotion-motion-workspace-v1',favorites:[...motionWorkspace.favorites],variants:motionWorkspace.variants,queue:motionWorkspace.queue}))}
 catch{wsMessage('Local browser storage is unavailable. Use Export recipe JSON to keep a copy.',true)}
}
function wsMessage(message,isError=false){const el=$('wsStatus');if(!el)return;el.textContent=message;el.classList.toggle('error',isError)}
function wsCategory(name){
 const n=String(name).toLowerCase();
 if(/walk|run|sprint|sneak|swim|crawl|jump|fall|dodge|roll|climb|fly/.test(n))return 'movement';
 if(/punch|kick|slash|sword|attack|hit|shoot|fire|combo|block|guard|death|damage|fight|kata/.test(n))return 'combat';
 return 'other';
}
function wsButton(label,handler,title=''){
 const b=document.createElement('button');b.type='button';b.textContent=label;b.title=title;b.addEventListener('click',handler);return b;
}
function wsClipByName(name){return state.clips.find(c=>c.name===name)}
function wsAddStep(step){
 if(motionWorkspace.queue.length>=80){wsMessage('Maximum 80 sequence steps.',true);return}
 const value=wsSafeStep(step);
 if(!value||!wsClipByName(value.source)||value.start>=value.end){wsMessage('That source clip is not available.',true);return}
 workspaceStopSequence();motionWorkspace.queue.push(value);motionWorkspace.selectedStep=motionWorkspace.queue.length-1;
 workspaceSave();workspaceRenderQueue();wsMessage(`Added ${value.label} to timeline.`);
}
function workspaceRefresh(){
 if(!$('wsLibrary'))return;
 workspaceLoad();
 $('wsCurrentClip').textContent=state.selection.startsWith('clip::')?state.selection.slice(6):'No clip selected';
 const original=$('wsVariantSource').value;
 $('wsVariantSource').replaceChildren();
 for(const c of state.clips){const o=document.createElement('option');o.value=c.name;o.textContent=c.name;$('wsVariantSource').append(o)}
 $('wsVariantSource').value=state.clips.some(x=>x.name===original)?original:(state.clips.find(c=>state.selection==='clip::'+c.name)?.name||state.clips[0]?.name||'');
 $('wsVariantSave').disabled=!state.clips.length;
 $('wsQueuePlay').disabled=!state.clips.length;
 $('wsQueueBatch').disabled=!state.clips.length;
 workspaceRenderLibrary();workspaceRenderVariants();workspaceRenderQueue();
}
function workspaceRenderLibrary(){
 const root=$('wsLibrary');if(!root)return;root.replaceChildren();
 const term=$('wsSearch').value.toLowerCase().trim();const filter=$('wsFilter').value;
 const list=state.clips.filter(c=>c.name.toLowerCase().includes(term)&&(filter==='all'||(filter==='favorites'&&motionWorkspace.favorites.has(c.name))||wsCategory(c.name)===filter));
 if(!list.length){const p=document.createElement('p');p.className='tiny';p.textContent=state.clips.length?'No clips match this filter.':'Load an animated character and attach its saved clips.';root.append(p);return}
 for(const clip of list){
  const row=document.createElement('div');row.className='wsItem';
  const star=wsButton(motionWorkspace.favorites.has(clip.name)?'★':'☆',()=>{
   if(motionWorkspace.favorites.has(clip.name))motionWorkspace.favorites.delete(clip.name);else motionWorkspace.favorites.add(clip.name);
   workspaceSave();workspaceRenderLibrary();
  },'Mark clip as favorite');star.className='wsStar';
  const text=document.createElement('span');text.className='wsItemTitle';text.textContent=`${clip.name} · ${clip.duration.toFixed(2)}s`;text.title=clip.name;
  row.append(star,text,wsButton('▶',()=>{chooseClip(clip);wsMessage('Previewing '+clip.name)},'Preview this clip'),wsButton('+',()=>wsAddStep({source:clip.name,label:clip.name,speed:1,start:0,end:100,repeats:1}),'Add to timeline'));
  root.append(row);
 }
}
function workspaceRenderVariants(){
 const root=$('wsVariants');root.replaceChildren();
 const available=motionWorkspace.variants.filter(v=>wsClipByName(v.source));
 if(!available.length){const p=document.createElement('p');p.className='tiny';p.textContent='No saved motion variations yet.';root.append(p);return}
 for(const v of available){
  const row=document.createElement('div');row.className='wsItem';const label=document.createElement('span');label.className='wsItemTitle';
  label.textContent=`${v.label} · ${v.speed}× · ${v.start}–${v.end}%`;label.title=`Uses original clip ${v.source}, ${v.repeats} repeat(s)`;
  row.append(label,wsButton('▶',()=>workspaceStart([v]),'Preview variation'),wsButton('+',()=>wsAddStep(v),'Add variation to timeline'),wsButton('×',()=>{motionWorkspace.variants=motionWorkspace.variants.filter(x=>x.id!==v.id);workspaceSave();workspaceRenderVariants()},'Delete saved variation'));
  root.append(row)
 }
}
function workspaceRenderQueue(){
 const root=$('wsQueue');root.replaceChildren();let seconds=0;let missing=0;
 for(const [i,s] of motionWorkspace.queue.entries()){
  const clip=wsClipByName(s.source);if(clip)seconds+=clip.duration*(s.end-s.start)/100*s.repeats/s.speed;else missing++;
  const row=document.createElement('div');row.className='wsItem';
  const label=document.createElement('span');label.className='wsItemTitle';label.textContent=`${i+1}. ${s.label} · ${s.speed}×${s.repeats>1?' ×'+s.repeats:''}`;
  if(!clip){label.textContent+=' [missing GLB clip]';label.style.color='#ff9ca9'}
  const up=wsButton('↑',()=>wsMoveQueue(i,-1),'Move earlier');up.disabled=i===0;
  const down=wsButton('↓',()=>wsMoveQueue(i,1),'Move later');down.disabled=i===motionWorkspace.queue.length-1;
  label.style.cursor='pointer';label.title='Click to edit this timeline step';label.addEventListener('click',()=>wsSelectStep(i));
  row.append(label,up,down,wsButton('×',()=>{workspaceStopSequence();motionWorkspace.queue.splice(i,1);
   motionWorkspace.selectedStep=Math.max(0,Math.min(motionWorkspace.selectedStep,motionWorkspace.queue.length-1));
   workspaceSave();workspaceRenderQueue()},'Remove from sequence'));root.append(row);
 }
 $('wsQueueSummary').textContent=`${motionWorkspace.queue.length} step(s) · ~${seconds.toFixed(1)}s${missing?' · '+missing+' clip(s) missing':''}`;
 $('wsQueueExport').disabled=!motionWorkspace.queue.length;
 $('wsQueuePlay').disabled=!motionWorkspace.queue.length||!!missing;
 $('wsQueueBatch').disabled=!motionWorkspace.queue.length||!!missing;
 if(!motionWorkspace.queue.length){const p=document.createElement('p');p.className='tiny';p.textContent='Add clips or saved variations above to build a sequence.';root.append(p)}
 if($('wsSequenceExportBtn'))$('wsSequenceExportBtn').disabled=!motionWorkspace.queue.length||!!missing;
 if($('wsTimelineScrub'))$('wsTimelineScrub').disabled=!motionWorkspace.queue.length||!!missing;
 if($('wsTimelineReplay'))$('wsTimelineReplay').disabled=!motionWorkspace.queue.length||!!missing;
 workspaceRenderTimeline();wsRenderStepEditor();
}
function wsMoveQueue(i,delta){const j=i+delta;if(j<0||j>=motionWorkspace.queue.length)return;
 workspaceStopSequence();const a=motionWorkspace.queue;[a[i],a[j]]=[a[j],a[i]];
 motionWorkspace.selectedStep=j;workspaceSave();workspaceRenderQueue()}
function workspaceExportRecipe(){
 const steps=motionWorkspace.queue.map(s=>({...s,source_duration_seconds:wsClipByName(s.source)?.duration||null}));
 const summary={schema:'coremotion-motion-recipe-v2',studio:'Core Motion V6.9',character:state.calibrationKey||null,sequence:'Custom motion sequence',steps,
  note:'Non-destructive timeline recipe with per-step timing, held-pose transition fades and optional bone rotation offsets. Not a merged GLB or an automatically generated 3D animation.'};
 download(new Blob([JSON.stringify(summary,null,2)],{type:'application/json'}),'CoreMotion_Motion_Sequence.json');wsMessage('Sequence recipe saved as JSON.');
}
function initWorkspace(){
 $('wsSearch').addEventListener('input',workspaceRenderLibrary);
 $('wsFilter').addEventListener('change',workspaceRenderLibrary);
 $('wsVariantSave').addEventListener('click',()=>{
  const source=$('wsVariantSource').value;
  const raw={source,label:$('wsVariantName').value.trim(),speed:Number($('wsVariantSpeed').value),start:Number($('wsVariantStart').value),end:Number($('wsVariantEnd').value),repeats:Number($('wsVariantRepeats').value)};
  if(!source||!wsClipByName(source)){wsMessage('Select a source animation first.',true);return}
  if(!raw.label){wsMessage('Enter a name for the motion variation.',true);return}
  if(raw.start>=raw.end){wsMessage('End percentage must be greater than start.',true);return}
  if(motionWorkspace.variants.length>=70){wsMessage('Maximum 70 saved variations.',true);return}
  const v={...wsSafeStep(raw),id:String(motionWorkspace.nextId++)};
  motionWorkspace.variants.push(v);workspaceSave();workspaceRenderVariants();$('wsVariantName').value='';wsMessage(`Saved ${v.label}. This is a reusable timing variation of ${source}.`);
 });
 $('wsQueuePlay').addEventListener('click',()=>workspaceStart(motionWorkspace.queue));
 $('wsStop').addEventListener('click',()=>{workspaceStopSequence();state.playing=false;$('playBtn').textContent='▶ Play';wsMessage('Sequence preview stopped.');});
 $('wsQueueClear').addEventListener('click',()=>{workspaceStopSequence();motionWorkspace.queue=[];motionWorkspace.selectedStep=0;workspaceSave();workspaceRenderQueue();wsMessage('Timeline cleared. Saved variations were kept.');});
 $('wsQueueExport').addEventListener('click',workspaceExportRecipe);
 $('wsQueueBatch').addEventListener('click',()=>{
  loadBatchFramePrefs();const present=new Set(state.clips.map(x=>x.name));
  for(const step of motionWorkspace.queue)if(present.has(step.source))batchSelectedNames.add(step.source);
  refreshBatchClips();wsMessage('Source clips selected in Batch Export below. The exporter still uses complete original clips, not trimmed variation ranges.');
 });
 $('wsVariantSource').addEventListener('change',()=>{const c=wsClipByName($('wsVariantSource').value);if(c)wsMessage('Source: '+c.name+' · '+c.duration.toFixed(2)+'s')});
 workspaceRefresh();
}
initWorkspace();


// V6.9 TIMELINE ENGINE — non-destructive timeline evaluation and sprite-sequence export.
// The original V6.7/V6.6 single-clip and batch renderers are deliberately unchanged.
const WS_V69_EASING=['linear','ease-in','ease-out','ease-in-out'];
function wsEase(t,mode){
 t=wsClamp(t,0,1);
 if(mode==='ease-in')return t*t;
 if(mode==='ease-out')return 1-(1-t)*(1-t);
 if(mode==='ease-in-out')return t*t*(3-2*t);
 return t;
}
function wsBuildTimeline(steps){
 const segments=[];let cursor=0;
 for(let i=0;i<steps.length;i++){
  const step=steps[i],clip=wsClipByName(step.source);
  if(!clip||step.end<=step.start)throw new Error('A source clip is missing or a trim range is invalid: '+step.source);
  const perRepeat=clip.duration*(step.end-step.start)/100/step.speed;
  if(!(perRepeat>0)||!Number.isFinite(perRepeat))throw new Error('Invalid sequence duration');
  for(let r=0;r<step.repeats;r++){
   segments.push({step,stepIndex:i,repeatIndex:r,begin:cursor,end:cursor+perRepeat,duration:perRepeat,clip});
   cursor+=perRepeat;
  }
 }
 if(!segments.length)throw new Error('Add animation clips to the timeline first.');
 if(cursor>180)throw new Error('Sequence exceeds 180 seconds. Trim or shorten its clips.');
 return {segments,duration:cursor,steps};
}
function wsLocate(t,timeline){
 const seconds=wsClamp(t,0,Math.max(0,timeline.duration-0.000001));
 const index=timeline.segments.findIndex(s=>seconds<s.end);
 const idx=index<0?timeline.segments.length-1:index;
 const seg=timeline.segments[idx];
 const phase=wsClamp((seconds-seg.begin)/seg.duration,0,1);
 return {seg,index:idx,phase,seconds};
}
function wsSelectSourceClip(clip){
 if(state.selection==='clip::'+clip.name)return;
 const ws=motionWorkspace,wasSwitching=ws.switching,wasPlaying=state.playing;
 ws.switching=true;
 try{chooseClip(clip)}finally{ws.switching=wasSwitching;state.playing=wasPlaying}
}
function wsBoneByName(name){let found=null;state.model?.traverse(o=>{if(!found&&o.isBone&&o.name===name)found=o});return found}
function wsApplyPoseKeys(step,clipPercent){
 if(!step.keyframes?.length||!state.model)return;
 const names=[...new Set(step.keyframes.map(k=>k.bone))];
 for(const name of names){
  const bone=wsBoneByName(name);if(!bone)continue;
  const entries=step.keyframes.filter(k=>k.bone===name).sort((a,b)=>a.at-b.at);
  const points=[{at:0,rx:0,ry:0,rz:0},...entries,{at:100,rx:0,ry:0,rz:0}];
  const at=wsClamp(clipPercent,0,100);
  let a=points[0],b=points[points.length-1];
  for(let i=0;i<points.length-1;i++)if(at>=points[i].at&&at<=points[i+1].at){a=points[i];b=points[i+1];break}
  const weight=b.at>a.at?(at-a.at)/(b.at-a.at):1;
  const toRad=Math.PI/180;
  const x=(a.rx+(b.rx-a.rx)*weight)*toRad;
  const y=(a.ry+(b.ry-a.ry)*weight)*toRad;
  const z=(a.rz+(b.rz-a.rz)*weight)*toRad;
  bone.quaternion.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(x,y,z,'XYZ'))).normalize();
 }
 state.model.updateMatrixWorld(true);
}
function wsSampleSegment(seg,phase){
 wsSelectSourceClip(seg.clip);
 const step=seg.step,normalized=wsEase(phase,step.easing);
 const percent=step.start+(step.end-step.start)*normalized;
 const clipTime=Math.min(seg.clip.duration-0.00002,Math.max(0,seg.clip.duration*percent/100));
 state.time=clipTime;
 updateAnimation(clipTime);
 wsApplyPoseKeys(step,phase*100);
 return clipTime;
}
function wsCaptureLocalPose(){
 const pose=[];
 state.model?.traverse(o=>pose.push({obj:o,position:o.position.clone(),rotation:o.quaternion.clone(),scale:o.scale.clone(),morph:o.morphTargetInfluences?.slice()||null}));
 return pose;
}
function wsBlendFromPose(pose,alpha){
 for(const p of pose){const o=p.obj;if(!o||!o.position)continue;
  o.position.lerpVectors(p.position,o.position.clone(),alpha);
  o.quaternion.slerpQuaternions(p.rotation,o.quaternion.clone(),alpha).normalize();
  o.scale.lerpVectors(p.scale,o.scale.clone(),alpha);
  if(p.morph&&o.morphTargetInfluences)for(let i=0;i<Math.min(p.morph.length,o.morphTargetInfluences.length);i++){
   o.morphTargetInfluences[i]=p.morph[i]*(1-alpha)+o.morphTargetInfluences[i]*alpha;
  }
 }
 state.model.updateMatrixWorld(true);
}
function workspaceSampleAt(seconds,timeline,showUI=false){
 if(!state.loaded||!state.mixer||!timeline)return;
 const oldPlaying=state.playing,{seg,index,phase,seconds:actual}=wsLocate(seconds,timeline);
 // Blend from the previous segment's held final pose into the new clip's
 // progressing pose. Unlike a live two-mixer blend, the outgoing clip is frozen.
 const fade=Math.min(seg.step.fade,seg.duration*0.48);
 if(index>0&&fade>0&&actual-seg.begin<fade){
  const prev=timeline.segments[index-1];
  wsSampleSegment(prev,0.99999);
  const prevPose=wsCaptureLocalPose();
  wsSampleSegment(seg,phase);
  wsBlendFromPose(prevPose,wsEase((actual-seg.begin)/fade,'ease-in-out'));
 }else wsSampleSegment(seg,phase);
 state.playing=oldPlaying;
 if(showUI){
  const label=`${seg.stepIndex+1}/${timeline.steps.length}: ${seg.step.label} (${seg.repeatIndex+1}/${seg.step.repeats})`;
  $('wsPlaying').textContent=`${label} · ${actual.toFixed(2)} / ${timeline.duration.toFixed(2)}s`;
  $('wsTimelineScrub').value=String(Math.round(actual/timeline.duration*1000));
  $('wsTimelineTime').textContent=`${actual.toFixed(2)}s / ${timeline.duration.toFixed(2)}s`;
  $('wsTimelineTrack')?.querySelectorAll('.wsClipBlock').forEach((el)=>el.classList.toggle('wsNow',Number(el.dataset.stepIndex)===seg.stepIndex));
 }
}
function workspaceStopSequence(){
 const ws=motionWorkspace;
 ws.running=false;ws.steps=[];ws.timeline=null;ws.elapsed=0;ws.index=0;ws.repeatNumber=1;
 if($('wsStop'))$('wsStop').disabled=true;
 if($('wsPlaying'))$('wsPlaying').textContent='Stopped';
}
function workspaceStart(rawSteps,opts={}){
 if(!state.loaded||!state.mixer){wsMessage('Load a rigged and animated character first.',true);return}
 const steps=rawSteps.map(wsSafeStep);
 if(steps.some(s=>!s||s.start>=s.end||!wsClipByName(s.source))||!steps.length){wsMessage('Sequence contains a missing clip or invalid segment.',true);return}
 let timeline;try{timeline=wsBuildTimeline(steps)}catch(e){wsMessage(e.message,true);return}
 workspaceStopSequence();
 const ws=motionWorkspace;ws.running=true;ws.steps=steps;ws.timeline=timeline;ws.elapsed=wsClamp(opts.startTime??0,0,timeline.duration);
 state.playing=opts.play!==false;
 $('playBtn').textContent=state.playing?'❚❚ Pause':'▶ Play';
 $('wsStop').disabled=false;
 workspaceSampleAt(ws.elapsed,timeline,true);updateProgressUI();last=performance.now();
 wsMessage('Timeline '+(state.playing?'playing':'scrubbing')+'. Transition fades blend from the previous held pose; source GLBs remain unchanged.');
}
function workspaceTick(delta){
 const ws=motionWorkspace;if(!ws.running||!ws.timeline)return;
 ws.elapsed=Math.min(ws.timeline.duration,ws.elapsed+delta);
 workspaceSampleAt(ws.elapsed,ws.timeline,true);
 if(ws.elapsed+0.000001>=ws.timeline.duration){
  state.playing=false;$('playBtn').textContent='↻ Replay';
  ws.running=false;$('wsStop').disabled=true;
  $('wsPlaying').textContent='Sequence complete';wsMessage('Finished. The final pose is held and source GLBs were not modified.');
 }
}
function wsSelectStep(index){
 if(index<0||index>=motionWorkspace.queue.length)return;
 motionWorkspace.selectedStep=index;workspaceRenderTimeline();wsRenderStepEditor();
}
function workspaceRenderTimeline(){
 const track=$('wsTimelineTrack');if(!track)return;
 track.replaceChildren();
 let tl=null;try{if(motionWorkspace.queue.length)tl=wsBuildTimeline(motionWorkspace.queue)}catch(e){/* Missing clips are handled by the library list. */}
 if(!tl){track.textContent='Add motion clips to create an editable timeline.';$('wsTimelineTime').textContent='0.00s / 0.00s';return}
 for(let i=0;i<motionWorkspace.queue.length;i++){
  const s=motionWorkspace.queue[i],clips=tl.segments.filter(g=>g.stepIndex===i);
  const duration=clips.reduce((n,g)=>n+g.duration,0),el=document.createElement('button');
  el.type='button';el.draggable=true;el.className='wsClipBlock'+(motionWorkspace.selectedStep===i?' wsSelected':'');
  el.dataset.stepIndex=String(i);el.style.flexGrow=String(Math.max(0.1,duration));
  el.title=`Drag to reorder. ${s.source}, ${duration.toFixed(2)} seconds. Click to edit.`;
  const text=document.createElement('strong');text.textContent=s.label;
  const sub=document.createElement('span');sub.textContent=`${duration.toFixed(1)}s · ${s.easing}`;
  el.append(text,sub);el.addEventListener('click',()=>wsSelectStep(i));
  el.addEventListener('dragstart',ev=>{ev.dataTransfer?.setData('text/plain',String(i));ev.dataTransfer.effectAllowed='move'});
  el.addEventListener('dragover',ev=>{ev.preventDefault();if(ev.dataTransfer)ev.dataTransfer.dropEffect='move'});
  el.addEventListener('drop',ev=>{ev.preventDefault();const from=Number(ev.dataTransfer?.getData('text/plain'));
    if(!Number.isInteger(from)||from<0||from>=motionWorkspace.queue.length||from===i)return;
    workspaceStopSequence();const [step]=motionWorkspace.queue.splice(from,1);motionWorkspace.queue.splice(i,0,step);
    motionWorkspace.selectedStep=i;workspaceSave();workspaceRenderQueue();wsMessage('Timeline reordered.');
  });
  track.append(el);
 }
 $('wsTimelineTime').textContent=motionWorkspace.running&&motionWorkspace.timeline?`${motionWorkspace.elapsed.toFixed(2)}s / ${motionWorkspace.timeline.duration.toFixed(2)}s`:`0.00s / ${tl.duration.toFixed(2)}s`;
}
function wsRenderStepEditor(){
 const ws=motionWorkspace,index=ws.selectedStep,s=ws.queue[index],panel=$('wsStepEditor');
 if(!panel)return;
 panel.hidden=!s;
 if(!s){$('wsKeyList').replaceChildren();return}
 $('wsSelectedLabel').textContent=`Step ${index+1} — ${s.label}`;
 $('wsStepSpeed').value=String(s.speed);$('wsStepEase').value=s.easing;
 $('wsStepFade').value=String(s.fade);$('wsStepRepeats').value=String(s.repeats);
 $('wsStepStart').value=String(s.start);$('wsStepEnd').value=String(s.end);
 const boneSel=$('wsKeyBone'),old=boneSel.value;boneSel.replaceChildren();
 const names=[];state.model?.traverse(o=>{if(o.isBone&&o.name&&!names.includes(o.name))names.push(o.name)});
 for(const name of names){const opt=document.createElement('option');opt.value=name;opt.textContent=name;boneSel.append(opt)}
 boneSel.value=names.includes(old)?old:(names[0]||'');
 $('wsKeySave').disabled=!names.length;
 wsRenderKeyframes();
}
function wsRenderKeyframes(){
 const s=motionWorkspace.queue[motionWorkspace.selectedStep],root=$('wsKeyList');root.replaceChildren();
 if(!s)return;
 if(!s.keyframes?.length){const p=document.createElement('span');p.className='tiny';p.textContent='No pose offsets yet. Your source animation remains unchanged.';root.append(p);return}
 for(const k of s.keyframes){const row=document.createElement('div');row.className='wsItem';
  const label=document.createElement('span');label.className='wsItemTitle';label.textContent=`${k.bone} · ${k.at}% · (${k.rx}°, ${k.ry}°, ${k.rz}°)`;
  row.append(label,wsButton('×',()=>{workspaceStopSequence();s.keyframes=s.keyframes.filter(x=>x!==k);workspaceSave();wsRenderKeyframes();},'Remove pose keyframe'));root.append(row);
 }
}
function wsUpdateSelectedStep(){
 const s=motionWorkspace.queue[motionWorkspace.selectedStep];if(!s)return;
 const start=wsClamp($('wsStepStart').value,0,94),end=wsClamp($('wsStepEnd').value,6,100);
 if(start>=end){wsMessage('End % must be greater than start %.',true);return}
 workspaceStopSequence();s.start=start;s.end=end;s.speed=wsClamp($('wsStepSpeed').value,.25,2);
 s.repeats=Math.round(wsClamp($('wsStepRepeats').value,1,4));
 s.fade=wsClamp($('wsStepFade').value,0,.8);
 s.easing=WS_V69_EASING.includes($('wsStepEase').value)?$('wsStepEase').value:'linear';
 workspaceSave();workspaceRenderQueue();wsMessage(`Updated ${s.label}: ${s.easing} timing, ${s.fade.toFixed(2)}s pose fade.`);
}
function wsKeySave(){
 const s=motionWorkspace.queue[motionWorkspace.selectedStep],bone=$('wsKeyBone').value;
 if(!s||!bone||!wsBoneByName(bone)){wsMessage('Select a valid rig bone first.',true);return}
 const k={bone,at:Math.round(wsClamp($('wsKeyAt').value,1,99)),rx:wsClamp($('wsKeyX').value,-45,45),ry:wsClamp($('wsKeyY').value,-45,45),rz:wsClamp($('wsKeyZ').value,-45,45)};
 workspaceStopSequence();s.keyframes=s.keyframes||[];
 const j=s.keyframes.findIndex(x=>x.bone===k.bone&&x.at===k.at);
 if(j>=0)s.keyframes[j]=k;else if(s.keyframes.length<32)s.keyframes.push(k);else{wsMessage('Limit: 32 bone keyframes per step.',true);return}
 s.keyframes.sort((a,b)=>a.at-b.at);workspaceSave();wsRenderKeyframes();
 wsMessage(`Pose offset at ${k.at}% saved for ${k.bone}. This rotates the joint locally; the GLB is unchanged.`);
}
function wsSequencePoseAt(seconds,dir,ref,anchor,anchorPoint,timeline){
 state.pivot.position.set(0,0,0);state.pivot.rotation.y=DIRS.indexOf(dir)*Math.PI/4;
 workspaceSampleAt(seconds,timeline,false);
 state.pivot.updateMatrixWorld(true);
 const point=anchor.getWorldPosition(anchorPoint);
 state.pivot.position.set(ref.x-point.x,0,ref.z-point.z);state.pivot.updateMatrixWorld(true);
 return exportVisibleBounds();
}
async function wsSequenceCameraPlan(timeline,count){
 const anchor=exportRigAnchor(),anchorPoint=new THREE.Vector3(),refs={};
 const extent={minX:Infinity,maxX:-Infinity,minY:Infinity,maxY:-Infinity,minZ:Infinity,maxZ:-Infinity};
 for(let d=0;d<DIRS.length;d++){
  const dir=DIRS[d];state.pivot.position.set(0,0,0);state.pivot.rotation.y=d*Math.PI/4;
  workspaceSampleAt(0,timeline,false);state.pivot.updateMatrixWorld(true);
  refs[dir]=anchor.getWorldPosition(anchorPoint).clone();
  for(let i=0;i<count;i++){
   const t=timeline.duration*(i/(count-1)),b=wsSequencePoseAt(t,dir,refs[dir],anchor,anchorPoint,timeline);
   extent.minX=Math.min(extent.minX,b.min.x);extent.maxX=Math.max(extent.maxX,b.max.x);
   extent.minY=Math.min(extent.minY,b.min.y);extent.maxY=Math.max(extent.maxY,b.max.y);
   extent.minZ=Math.min(extent.minZ,b.min.z);extent.maxZ=Math.max(extent.maxZ,b.max.z);
  }
  if(d%2===1)await new Promise(done=>setTimeout(done,0));
 }
 const width=extent.maxX-extent.minX,height=extent.maxY-extent.minY;
 if(!Number.isFinite(width+height)||width<=0||height<=0)throw new Error('Invalid animated bounds for sequence');
 const framing=Number($('exportFitSlider').value)/100;
 const half=Math.max(width,height)*.5*Math.max(1.12,1.25*framing);
 const cameraZ=extent.maxZ+Math.max(10,extent.maxZ-extent.minZ+5);
 return {halfExtent:Math.max(.15,half),centerX:(extent.minX+extent.maxX)/2,centerY:(extent.minY+extent.maxY)/2,
  cameraZ,cameraFar:Math.max(100,cameraZ-extent.minZ+25),refs,measuredBounds:{...extent}};
}
async function wsRenderSequenceSheet(dir,timeline,plan,count){
 const size=Number($('sizeSelect').value),columns=Number($('colSelect').value),rows=Math.ceil(count/columns);
 const sheet=document.createElement('canvas');sheet.width=size*columns;sheet.height=size*rows;
 if(sheet.width>16384||sheet.height>16384||sheet.width*sheet.height>80000000)
  throw new Error('Sequence sheet too large. Reduce sprite size or frame count.');
 const ctx=sheet.getContext('2d',{willReadFrequently:true});ctx.clearRect(0,0,sheet.width,sheet.height);
 const savedSize=new THREE.Vector2();renderer.getSize(savedSize);
 const savedRatio=renderer.getPixelRatio();
 const savedCam={left:camera.left,right:camera.right,top:camera.top,bottom:camera.bottom,near:camera.near,far:camera.far,zoom:camera.zoom,
  position:camera.position.clone(),quaternion:camera.quaternion.clone()};
 const helperVisible=state.skeletonHelper?.visible,footVisible=footFloorGuide?.visible;
 const culling=[];state.model.traverse(o=>{if(o.isMesh){culling.push([o,o.frustumCulled]);o.frustumCulled=false}});
 const pixelStyle=state.style==='pixel',low=Math.min(size,Number($('pixelSelect').value));
 const renderSize=pixelStyle?low:Math.min(2048,size*2);
 const anchor=exportRigAnchor(),anchorPoint=new THREE.Vector3();
 try{
  renderer.setPixelRatio(1);renderer.setSize(renderSize,renderSize,false);
  camera.zoom=1;camera.left=-plan.halfExtent;camera.right=plan.halfExtent;
  camera.top=plan.halfExtent;camera.bottom=-plan.halfExtent;
  camera.near=.01;camera.far=plan.cameraFar;camera.updateProjectionMatrix();
  camera.quaternion.set(0,0,0,1);
  camera.position.set(plan.centerX,plan.centerY,plan.cameraZ);camera.updateMatrixWorld(true);
  if(state.skeletonHelper)state.skeletonHelper.visible=false;if(footFloorGuide)footFloorGuide.visible=false;
  for(let i=0;i<count;i++){
   if(batchExportCancel)throw new Error('Sequence export cancelled. No incomplete ZIP downloaded.');
   const t=timeline.duration*i/(count-1);
   const bound=wsSequencePoseAt(t,dir,plan.refs[dir],anchor,anchorPoint,timeline);
   const e=1e-5;
   if(bound.min.x<plan.centerX-plan.halfExtent-e||bound.max.x>plan.centerX+plan.halfExtent+e||
      bound.min.y<plan.centerY-plan.halfExtent-e||bound.max.y>plan.centerY+plan.halfExtent+e||
      bound.max.z>=plan.cameraZ-camera.near||bound.min.z<=plan.cameraZ-plan.cameraFar)
    throw new Error(`${dir} sequence frame ${i+1}/${count} exceeds camera bounds. Increase Export framing.`);
   v7RenderScene();
   const x=(i%columns)*size,y=Math.floor(i/columns)*size;
   ctx.imageSmoothingEnabled=!pixelStyle;if(!pixelStyle)ctx.imageSmoothingQuality='high';
   ctx.clearRect(x,y,size,size);ctx.drawImage(renderer.domElement,x,y,size,size);
   const frame=exportAlphaBounds(ctx,x,y,size);
   if(!frame)throw new Error(`${dir} sequence frame ${i+1}/${count} rendered blank. Export stopped.`);
   if(!exportBoundsInsideFrame(frame,size))throw new Error(`${dir} sequence frame ${i+1}/${count} is clipped. Increase Export framing.`);
   if(i%8===7)await new Promise(done=>setTimeout(done,0));
  }
  const blob=await dataURLBlob(sheet);if(!blob)throw new Error('Could not encode sequence sheet as PNG');return blob;
 }finally{
  for(const [o,old] of culling)o.frustumCulled=old;
  if(state.skeletonHelper)state.skeletonHelper.visible=helperVisible;
  if(footFloorGuide)footFloorGuide.visible=footVisible;
  renderer.setPixelRatio(savedRatio);renderer.setSize(savedSize.x,savedSize.y,false);
  Object.assign(camera,{left:savedCam.left,right:savedCam.right,top:savedCam.top,bottom:savedCam.bottom,near:savedCam.near,far:savedCam.far,zoom:savedCam.zoom});
  camera.position.copy(savedCam.position);camera.quaternion.copy(savedCam.quaternion);
  camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
 }
}
async function wsExportSequenceSprites(){
 if(state.exporting||!state.loaded||!state.mixer){wsMessage('Load a rigged character before exporting.',true);return}
 let tl;try{tl=wsBuildTimeline(motionWorkspace.queue)}catch(e){wsMessage(e.message,true);return}
 const count=Number($('wsExportCount').value),size=Number($('sizeSelect').value),cols=Number($('colSelect').value);
 if(![8,16,24,32,48,64].includes(count)){wsMessage('Invalid sequence frame count.',true);return}
 if(size*cols*Math.ceil(count/cols)*size>80000000){wsMessage('Sheet too large for safe export. Reduce sprite size or frames.',true);return}
 const oldClip=state.clips.find(c=>state.selection==='clip::'+c.name),oldTime=state.time,oldPlaying=state.playing;
 const oldDir=state.dir,oldPosition=state.pivot.position.clone(),oldRot=state.pivot.rotation.y;
 workspaceStopSequence();state.playing=false;state.exporting=true;batchExportCancel=false;
 $('wsSequenceExportBtn').disabled=true;
 const names=[];
 try{
  wsMessage('Measuring all sequence poses and directions…');
  const plan=await wsSequenceCameraPlan(tl,count);
  const pack=[];
  for(let j=0;j<DIRS.length;j++){
   const dir=DIRS[j];wsMessage(`Rendering sequence ${dir} (${j+1}/8) · ${count} frames…`);
   const blob=await wsRenderSequenceSheet(dir,tl,plan,count);
   const name=`sequence_${dir}_${size}px_${count}f.png`;
   pack.push({name,bytes:new Uint8Array(await blob.arrayBuffer())});names.push(name);
   await new Promise(done=>setTimeout(done,0));
  }
  const manifest={schema:'coremotion-sequence-sprites-v1',studio:'Core Motion V6.9',frames:count,columns:cols,
   rows:Math.ceil(count/cols),sprite_size_px:size,directions:DIRS,sequence_duration_seconds:tl.duration,
   sample_strategy:'full-sequence-uniform-time-including-last-pose',transition:'fade-from-previous-final-pose',
   stabilized_root_motion:'XZ',files:names,steps:tl.steps,transparent_background:true};
  pack.push({name:'manifest.json',bytes:new TextEncoder().encode(JSON.stringify(manifest,null,2))});
  download(rawZip(pack),'CoreMotion_Sequence_Sprite_Pack.zip');
  wsMessage(`Exported ${count} sequence frames × 8 directions with 8 PNGs + manifest.json.`);
 }catch(e){wsMessage('Sequence sprite export failed: '+(e?.message||e),true)}
 finally{
  if(oldClip){motionWorkspace.switching=true;try{chooseClip(oldClip)}finally{motionWorkspace.switching=false}}
  state.time=oldTime;state.pivot.position.copy(oldPosition);state.pivot.rotation.y=oldRot;
  if(oldClip)updateAnimation(oldTime);setDirection(oldDir);
  state.playing=oldPlaying;state.exporting=false;
  $('wsSequenceExportBtn').disabled=!motionWorkspace.queue.length;updateProgressUI();last=performance.now();
 }
}
function initTimelineV69(){
 for(const id of ['wsStepSpeed','wsStepEase','wsStepFade','wsStepRepeats','wsStepStart','wsStepEnd'])$(id).addEventListener('change',wsUpdateSelectedStep);
 $('wsKeySave').addEventListener('click',wsKeySave);
 $('wsSequenceExportBtn').addEventListener('click',wsExportSequenceSprites);
 $('wsTimelineScrub').addEventListener('input',e=>{
  if(!motionWorkspace.running){workspaceStart(motionWorkspace.queue,{play:false,startTime:0});if(!motionWorkspace.running)return}
  state.playing=false;$('playBtn').textContent='▶ Play';
  motionWorkspace.elapsed=motionWorkspace.timeline.duration*Number(e.target.value)/1000;
  workspaceSampleAt(motionWorkspace.elapsed,motionWorkspace.timeline,true);updateProgressUI();
 });
 $('wsTimelineReplay').addEventListener('click',()=>workspaceStart(motionWorkspace.queue,{play:true,startTime:0}));
 workspaceRenderTimeline();wsRenderStepEditor();
}
initTimelineV69();


// V7.0 RIG STUDIO — non-destructive rig posing, reusable poses and custom animation clips.
// Existing clip renderers, timeline, update client and AssetFurnace bridge are unchanged.
const rigStudio={key:null,bones:[],rest:new Map(),poses:[],motions:[],draft:null,selected:null,enabled:false,
 markers:null,markerMeshes:[],drag:null,layerPose:null,layerStrength:0,layerEnabled:false,liveKeys:false};
function v7Key(){return 'coremotion-rig-studio-v1::'+(state.calibrationKey||'temporary-rig')}
function v7Msg(msg,error=false){const el=$('rigStudioStatus');if(el){el.textContent=msg;el.classList.toggle('error',error)}}
function v7Name(text){return String(text||'').trim().slice(0,64)}
function v7AllBones(){const bones=[];const names=new Set();state.model?.traverse(o=>{if(o.isBone&&o.name&&!names.has(o.name)){names.add(o.name);bones.push(o)}});return bones}
function v7Snapshot(){const data={};for(const b of rigStudio.bones){const q=b.quaternion;data[b.name]=[q.x,q.y,q.z,q.w].map(n=>Math.round(n*1e6)/1e6)}return data}
function v7NormalizePose(raw){
 const out={};if(!raw||typeof raw!=='object')return out;
 const valid=new Set(rigStudio.bones.map(b=>b.name));
 for(const [name,q] of Object.entries(raw))if(valid.has(name)&&Array.isArray(q)&&q.length===4&&q.every(n=>typeof n==='number'&&Number.isFinite(n))){
   const quat=new THREE.Quaternion(q[0],q[1],q[2],q[3]);if(quat.lengthSq()>1e-8){quat.normalize();out[name]=quat.toArray()}
 }
 return out;
}
function v7StoredPose(raw){return raw&&typeof raw==='object'&&typeof raw.name==='string'&&raw.name.length>0?
 {name:v7Name(raw.name),bones:v7NormalizePose(raw.bones)}:null}
function v7StoredMotion(raw){
 if(!raw||typeof raw!=='object'||typeof raw.name!=='string')return null;
 const duration=wsClamp(raw.duration,.25,30);
 const keys=Array.isArray(raw.keys)?raw.keys.slice(0,70).map(k=>({at:wsClamp(k?.at,0,duration),bones:v7NormalizePose(k?.bones)})).sort((a,b)=>a.at-b.at):[];
 return {name:v7Name(raw.name),duration,keys};
}
function v7Save(){if(!rigStudio.key)return;
 try{localStorage.setItem(rigStudio.key,JSON.stringify({schema:'coremotion-rig-studio-v1',poses:rigStudio.poses,motions:rigStudio.motions,draft:rigStudio.draft,layerPose:rigStudio.layerPose,layerEnabled:rigStudio.layerEnabled,layerStrength:rigStudio.layerStrength}))}
 catch{v7Msg('Browser storage is full or disabled. Export the studio JSON to keep your edits.',true)}
}
function v7DestroyMarkers(){if(!rigStudio.markers)return;scene.remove(rigStudio.markers);for(const p of rigStudio.markerMeshes){p.geometry.dispose();p.material.dispose()}rigStudio.markerMeshes=[];rigStudio.markers=null}
function v7BeforeClear(){v7DestroyMarkers();rigStudio.key=null;rigStudio.bones=[];rigStudio.rest.clear();rigStudio.selected=null;rigStudio.enabled=false;rigStudio.drag=null;rigStudio.draft=null;rigStudio.layerEnabled=false}
function v7LoadRig(){
 rigStudio.key=v7Key();rigStudio.bones=v7AllBones();rigStudio.rest=new Map(rigStudio.bones.map(b=>[b.name,b.quaternion.clone()]));
 rigStudio.poses=[];rigStudio.motions=[];rigStudio.draft=null;rigStudio.selected=null;rigStudio.enabled=false;
 rigStudio.layerEnabled=false;rigStudio.layerStrength=0;rigStudio.layerPose=null;
 try{const data=JSON.parse(localStorage.getItem(rigStudio.key)||'{}');
  if(Array.isArray(data.poses))rigStudio.poses=data.poses.slice(0,40).map(v7StoredPose).filter(Boolean);
  if(Array.isArray(data.motions))rigStudio.motions=data.motions.slice(0,35).map(v7StoredMotion).filter(m=>m&&m.name&&m.keys.length>=2);
  if(data.draft)rigStudio.draft=v7StoredMotion(data.draft);
  rigStudio.layerPose=v7Name(data.layerPose||'')||null;
  rigStudio.layerStrength=wsClamp(data.layerStrength,0,1);
  rigStudio.layerEnabled=!!data.layerEnabled;
 }catch{}
 for(const motion of rigStudio.motions){const clip=v7BakeMotion(motion);if(clip)state.clips.push(clip)}
 if(!state.mixer&&state.clips.length)state.mixer=new THREE.AnimationMixer(state.model);
 v7BuildMarkers();v7RefreshUI();
 v7Msg(rigStudio.bones.length?`${rigStudio.bones.length} uniquely named rig joints available. Enable Pose mode to select and rotate them.`:'Rig Studio needs a weighted skeleton with named bones.',!rigStudio.bones.length);
}
function v7RestPose(){const values={};for(const [name,q] of rigStudio.rest)values[name]=q.toArray();return values}
function v7ApplyPose(values){for(const b of rigStudio.bones){const q=values?.[b.name];if(q)b.quaternion.fromArray(q).normalize()}state.model?.updateMatrixWorld(true);v7UpdateMarkers()}
function v7StopPreview(){if(motionWorkspace.running)workspaceStopSequence();state.playing=false;$('playBtn').textContent='▶ Play'}
function v7BuildMarkers(){v7DestroyMarkers();if(!scene||!rigStudio.bones.length)return;
 rigStudio.markers=new THREE.Group();rigStudio.markers.name='Core Motion pose handles (preview only)';rigStudio.markers.visible=false;scene.add(rigStudio.markers);
 const sphereGeometry=new THREE.SphereGeometry(.064,10,8);
 for(const bone of rigStudio.bones){const material=new THREE.MeshBasicMaterial({color:0x50cce3,depthTest:false,depthWrite:false,transparent:true,opacity:.87});
  const marker=new THREE.Mesh(sphereGeometry.clone(),material);marker.userData.rigBone=bone;
  marker.renderOrder=1000;rigStudio.markers.add(marker);rigStudio.markerMeshes.push(marker)}
 v7UpdateMarkers();
}
function v7UpdateMarkers(){if(!rigStudio.markers||!rigStudio.enabled||state.exporting)return;
 state.model?.updateMatrixWorld(true);
 for(let i=0;i<rigStudio.markerMeshes.length;i++){const marker=rigStudio.markerMeshes[i],bone=rigStudio.bones[i];bone.getWorldPosition(marker.position);
  const selected=rigStudio.selected===bone.name;marker.scale.setScalar(selected?1.5:1);marker.material.color.setHex(selected?0xffc576:0x50cce3)}
}
function v7RenderScene(){
 if(rigStudio.markers){rigStudio.markers.visible=!!(rigStudio.enabled&&!state.exporting);
  if(rigStudio.markers.visible)v7UpdateMarkers()}
 renderer.render(scene,camera);
}
function v7SetMode(enabled){if(!rigStudio.bones.length){v7Msg('Load a rigged character first.',true);$('rigPoseMode').checked=false;return}
 rigStudio.enabled=enabled;if(enabled){v7StopPreview();$('rigPoseMode').checked=true;v7Msg('Click the cyan joint spheres in the 3D view; drag to rotate along the selected local axis. Orange is the selected joint.')}
 else {rigStudio.drag=null;$('rigPoseMode').checked=false;v7Msg('Pose selection off. Normal viewport rotation is restored.')}
 if(rigStudio.markers)rigStudio.markers.visible=enabled;v7RefreshBoneSelect();v7UpdateMarkers();
}
const v7Raycaster=new THREE.Raycaster();const v7Pointer=new THREE.Vector2();
function v7PointerDown(e){if(!rigStudio.enabled||!rigStudio.markers||state.exporting)return false;
 const rect=stage.getBoundingClientRect();v7Pointer.set((e.clientX-rect.left)/rect.width*2-1,1-(e.clientY-rect.top)/rect.height*2);
 v7Raycaster.setFromCamera(v7Pointer,camera);v7UpdateMarkers();
 const hits=v7Raycaster.intersectObjects(rigStudio.markerMeshes,false);
 if(!hits.length)return false;
 const b=hits[0].object.userData.rigBone;v7StopPreview();rigStudio.selected=b.name;$('rigBoneSelect').value=b.name;
 rigStudio.drag={pointerId:e.pointerId,startX:e.clientX,startY:e.clientY,quaternion:b.quaternion.clone(),bone:b};
 stage.setPointerCapture(e.pointerId);v7UpdateMarkers();v7UpdateRotationInfo();return true;
}
function v7PointerMove(e){const drag=rigStudio.drag;if(!drag)return false;
 if(e.pointerId!==drag.pointerId)return false;
 const axis=$('rigDragAxis').value,delta=((e.clientX-drag.startX)-(e.clientY-drag.startY))*.008;
 const euler=new THREE.Euler(axis==='x'?delta:0,axis==='y'?delta:0,axis==='z'?delta:0,'XYZ');
 drag.bone.quaternion.copy(drag.quaternion).multiply(new THREE.Quaternion().setFromEuler(euler)).normalize();
 state.model.updateMatrixWorld(true);v7UpdateMarkers();v7UpdateRotationInfo();return true;
}
function v7PointerUp(){rigStudio.drag=null}
function v7UpdateRotationInfo(){const b=rigStudio.bones.find(x=>x.name===rigStudio.selected);if(!$('rigJointInfo'))return;
 $('rigJointInfo').textContent=b?`${b.name} · local quaternion ${b.quaternion.toArray().map(v=>v.toFixed(2)).join(', ')}`:'Select a joint sphere or choose a bone from the menu.';
}
function v7RefreshBoneSelect(){const select=$('rigBoneSelect'),prev=rigStudio.selected;select.replaceChildren();
 for(const bone of rigStudio.bones){const opt=document.createElement('option');opt.value=bone.name;opt.textContent=bone.name;select.append(opt)}
 if(prev&&rigStudio.bones.some(b=>b.name===prev))select.value=prev;
 else if(rigStudio.bones.length){rigStudio.selected=rigStudio.bones[0].name;select.value=rigStudio.selected}
 v7UpdateRotationInfo();
}
function v7Nudge(degrees){if(!rigStudio.bones.length)return;v7StopPreview();const b=rigStudio.bones.find(x=>x.name===$('rigBoneSelect').value);if(!b)return;
 const axis=$('rigDragAxis').value,rad=degrees*Math.PI/180;
 b.quaternion.multiply(new THREE.Quaternion().setFromEuler(new THREE.Euler(axis==='x'?rad:0,axis==='y'?rad:0,axis==='z'?rad:0,'XYZ'))).normalize();
 rigStudio.selected=b.name;v7UpdateMarkers();v7UpdateRotationInfo();
}
function v7SavePose(){if(!rigStudio.bones.length)return;const name=v7Name($('rigPoseName').value);
 if(!name){v7Msg('Give this pose a name first.',true);return}
 const pose={name,bones:v7Snapshot()},idx=rigStudio.poses.findIndex(x=>x.name.toLowerCase()===name.toLowerCase());
 if(idx>=0)rigStudio.poses[idx]=pose;else if(rigStudio.poses.length<40)rigStudio.poses.push(pose);else{v7Msg('40 saved poses maximum.',true);return}
 v7Save();v7RefreshUI();$('rigPoseSelect').value=name;v7Msg('Saved pose '+name+' for this character. Original GLB unchanged.');
}
function v7LoadPose(){const name=$('rigPoseSelect').value,pose=rigStudio.poses.find(p=>p.name===name);if(!pose)return;
 v7StopPreview();v7ApplyPose(pose.bones);v7Msg('Applied '+pose.name+'. Save a keyframe to incorporate it into a custom animation.');
}
function v7MirrorBoneName(name){const tryNames=[
 name.replace(/Left/g,'Right'),name.replace(/Right/g,'Left'),name.replace(/left/g,'right'),name.replace(/right/g,'left'),
 name.replace(/^L_/,'R_'),name.replace(/^R_/,'L_'),name.replace(/_L$/,'_R'),name.replace(/_R$/,'_L'),
 name.replace(/\.L$/i,'.R'),name.replace(/\.R$/i,'.L')];
 const found=tryNames.find(n=>n!==name&&rigStudio.rest.has(n));return found||name;
}
function v7MirrorPose(){if(!rigStudio.bones.length)return;
 v7StopPreview();const captured=v7Snapshot(),result={};
 for(const b of rigStudio.bones){const from=v7MirrorBoneName(b.name),source=captured[from],restSrc=rigStudio.rest.get(from),restDst=rigStudio.rest.get(b.name);
  if(!source||!restSrc||!restDst)continue;
  const delta=restSrc.clone().invert().multiply(new THREE.Quaternion().fromArray(source));
  // Approximate sagittal reflection of a local quaternion around the X plane.
  delta.y*=-1;delta.z*=-1;
  result[b.name]=restDst.clone().multiply(delta.normalize()).normalize().toArray();
 }
 v7ApplyPose(result);v7Msg('Mirrored the pose across named left/right joints. Check shoulders and feet: unusual rig axes may require corrections.');
}
function v7ApplyLayer(){if(!rigStudio.layerEnabled||!rigStudio.layerPose||(rigStudio.enabled&&!state.exporting)||!rigStudio.bones.length)return;
 const p=rigStudio.poses.find(v=>v.name===rigStudio.layerPose);if(!p)return;
 const w=rigStudio.layerStrength;if(!w)return;
 for(const b of rigStudio.bones)if(/spine|chest|upperbody|torso|neck|head|shoulder|clavicle|arm|elbow|hand|wrist|finger|thumb/i.test(b.name)){
  const q=p.bones[b.name];if(q)b.quaternion.slerp(new THREE.Quaternion().fromArray(q),w).normalize();
 }
 state.model.updateMatrixWorld(true);
}
function v7RefreshPoseList(){const select=$('rigPoseSelect'),layer=$('rigLayerPose'),prior=select.value,layerPrev=rigStudio.layerPose;
 select.replaceChildren();layer.replaceChildren();
 for(const p of rigStudio.poses){for(const sel of [select,layer]){const option=document.createElement('option');option.value=p.name;option.textContent=p.name;sel.append(option)}}
 if(rigStudio.poses.some(p=>p.name===prior))select.value=prior;
 if(layerPrev&&rigStudio.poses.some(p=>p.name===layerPrev))layer.value=layerPrev;
 rigStudio.layerPose=layer.value||null;
 $('rigPoseLoad').disabled=!rigStudio.poses.length;$('rigPoseDelete').disabled=!rigStudio.poses.length;
 $('rigLayerEnable').disabled=!rigStudio.poses.length;
 $('rigLayerEnable').checked=!!rigStudio.layerEnabled;
 $('rigLayerStrength').value=String(Math.round(rigStudio.layerStrength*100));
 $('rigLayerStrengthValue').textContent=Math.round(rigStudio.layerStrength*100)+'%';
}
function v7BakeMotion(motion){if(!motion?.keys?.length||!rigStudio.bones.length)return null;
 const sorted=[...motion.keys].sort((a,b)=>a.at-b.at);
 if(sorted.length<2||sorted[0].at===sorted[sorted.length-1].at)return null;
 const tracks=[];const times=sorted.map(k=>k.at);
 for(const bone of rigStudio.bones){const fallback=rigStudio.rest.get(bone.name)?.toArray()||[0,0,0,1];const values=[];
  for(const key of sorted)values.push(...(key.bones[bone.name]||fallback));
  tracks.push(new THREE.QuaternionKeyframeTrack(bone.name+'.quaternion',times,values));
 }
 const clip=new THREE.AnimationClip('Studio · '+motion.name,motion.duration,tracks);
 clip.userData={rigStudio:true};return clip;
}
function v7RemoveClipByName(name){const index=state.clips.findIndex(c=>c.name===name);if(index<0)return;
 const existing=state.clips[index];state.mixer?.stopAllAction();state.mixer?.uncacheClip(existing);state.clips.splice(index,1);
}
function v7DraftNew(){if(!rigStudio.bones.length)return;
 const name=v7Name($('rigMotionName').value)||'Custom Movement';const duration=wsClamp($('rigMotionDuration').value,.25,30);
 const initial=v7RestPose();rigStudio.draft={name,duration,keys:[{at:0,bones:initial}]};
 v7StopPreview();v7ApplyPose(initial);$('rigMotionTime').value='0';v7RefreshMotionUI();v7Save();
 v7Msg(`New ${duration.toFixed(2)}s animation “${name}”. Pose the rig, pick a time, and Capture keyframe.`);
}
function v7DraftSample(time){const d=rigStudio.draft;if(!d||!rigStudio.bones.length)return;
 const t=wsClamp(time,0,d.duration);const keys=[...d.keys].sort((a,b)=>a.at-b.at);
 if(!keys.length){v7ApplyPose(v7RestPose());return}
 let a=keys[0],b=keys[keys.length-1];
 if(t<=keys[0].at)b=a;else if(t>=b.at)a=b;else for(let i=0;i<keys.length-1;i++)if(t>=keys[i].at&&t<=keys[i+1].at){a=keys[i];b=keys[i+1];break}
 const p=b.at>a.at?(t-a.at)/(b.at-a.at):0,pose={};
 for(const bone of rigStudio.bones){const rest=rigStudio.rest.get(bone.name)?.toArray()||[0,0,0,1];
  const q1=new THREE.Quaternion().fromArray(a.bones[bone.name]||rest),q2=new THREE.Quaternion().fromArray(b.bones[bone.name]||rest);
  pose[bone.name]=q1.slerp(q2,p).normalize().toArray();
 }
 v7StopPreview();v7ApplyPose(pose);
}
function v7CaptureKey(){const d=rigStudio.draft;if(!d){v7Msg('Click New motion before capturing keyframes.',true);return}
 const at=wsClamp($('rigMotionTime').value,0,d.duration),bones=v7Snapshot();let key=d.keys.find(k=>Math.abs(k.at-at)<.001);
 if(key)key.bones=bones;else if(d.keys.length<70)d.keys.push({at,bones});else{v7Msg('70 keyframes maximum.',true);return}
 d.keys.sort((a,b)=>a.at-b.at);v7Save();v7RefreshMotionUI();v7Msg(`Captured pose at ${at.toFixed(2)}s. The source character remains untouched.`);
}
function v7SaveMotion(){const d=rigStudio.draft;if(!d){v7Msg('Create a motion first.',true);return}
 if(d.keys.length<2||d.keys.at(-1).at-d.keys[0].at<.05){v7Msg('Capture at least two different times, such as 0.0 and 1.0 seconds.',true);return}
 const same=rigStudio.motions.findIndex(m=>m.name.toLowerCase()===d.name.toLowerCase());
 if(same<0&&rigStudio.motions.length>=35){v7Msg('35 animations maximum.',true);return}
 const saved={name:d.name,duration:d.duration,keys:d.keys.map(k=>({at:k.at,bones:{...k.bones}}))};
 const clip=v7BakeMotion(saved);if(!clip){v7Msg('Could not bake rig keyframes.',true);return}
 v7StopPreview();if(!state.mixer)state.mixer=new THREE.AnimationMixer(state.model);
 if(same>=0){v7RemoveClipByName('Studio · '+rigStudio.motions[same].name);rigStudio.motions[same]=saved}
 else rigStudio.motions.push(saved);
 state.clips.push(clip);v7Save();refreshClipUI();updatePipelineUI();chooseClip(clip);
 v7RefreshMotionUI();v7Msg(`Saved Studio · ${d.name}. It is now a playable 3D clip, selectable in Batch Export and the V6.9 timeline.`);
}
function v7RefreshMotionUI(){const d=rigStudio.draft,select=$('rigSavedMotions'),prior=select.value;
 select.replaceChildren();for(const m of rigStudio.motions){const opt=document.createElement('option');opt.value=m.name;opt.textContent=`${m.name} (${m.keys.length} keys)`;select.append(opt)}
 if(rigStudio.motions.some(m=>m.name===prior))select.value=prior;
 $('rigEditMotion').disabled=!rigStudio.motions.length;$('rigDeleteMotion').disabled=!rigStudio.motions.length;
 $('rigMotionTime').disabled=!d;$('rigKeyCapture').disabled=!d;$('rigMotionPublish').disabled=!d;
 if(d){$('rigMotionName').value=d.name;$('rigMotionDuration').value=String(d.duration);$('rigMotionTime').max=String(d.duration);
  $('rigKeySummary').textContent=d.keys.map(k=>k.at.toFixed(2)+'s').join(' · ')||'No keyframes';
 }else {$('rigKeySummary').textContent='Create a motion to start.'}
}
function v7RefreshUI(){v7RefreshBoneSelect();v7RefreshPoseList();v7RefreshMotionUI();
 const enabled=!!rigStudio.bones.length;for(const id of ['rigPoseMode','rigDragAxis','rigPoseName','rigPoseSave','rigPoseMirror','rigMotionName','rigMotionDuration','rigMotionNew','rigNudgeMinus','rigNudgePlus'])$(id).disabled=!enabled;
 $('rigPoseMode').checked=rigStudio.enabled;
}
function v7ExportBackup(){const data={schema:'coremotion-rig-studio-v1',studio:'Core Motion V7.0',character:state.calibrationKey,
  poses:rigStudio.poses,motions:rigStudio.motions,draft:rigStudio.draft,
  note:'Saved pose and quaternion-keyframe recipes for the current named rig. This is not a GLB file.'};
 download(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),'CoreMotion_Rig_Studio_Backup.json');v7Msg('Downloaded pose and animation recipe backup.');
}
function v7Init(){
 $('rigPoseMode').addEventListener('change',e=>v7SetMode(e.target.checked));
 $('rigBoneSelect').addEventListener('change',e=>{rigStudio.selected=e.target.value;v7UpdateMarkers();v7UpdateRotationInfo()});
 $('rigNudgeMinus').addEventListener('click',()=>v7Nudge(-5));$('rigNudgePlus').addEventListener('click',()=>v7Nudge(5));
 $('rigPoseSave').addEventListener('click',v7SavePose);$('rigPoseLoad').addEventListener('click',v7LoadPose);
 $('rigPoseMirror').addEventListener('click',v7MirrorPose);
 $('rigPoseDelete').addEventListener('click',()=>{rigStudio.poses=rigStudio.poses.filter(p=>p.name!==$('rigPoseSelect').value);v7Save();v7RefreshPoseList();v7Msg('Pose removed from library.')});
 $('rigRestPose').addEventListener('click',()=>{v7StopPreview();v7ApplyPose(v7RestPose());v7Msg('Rest pose restored in preview.')});
 $('rigLayerEnable').addEventListener('change',e=>{rigStudio.layerEnabled=e.target.checked;v7Save()});
 $('rigLayerPose').addEventListener('change',e=>{rigStudio.layerPose=e.target.value;v7Save()});
 $('rigLayerStrength').addEventListener('input',e=>{rigStudio.layerStrength=wsClamp(e.target.value,0,100)/100;$('rigLayerStrengthValue').textContent=Math.round(rigStudio.layerStrength*100)+'%';v7Save()});
 $('rigMotionNew').addEventListener('click',v7DraftNew);$('rigKeyCapture').addEventListener('click',v7CaptureKey);$('rigMotionPublish').addEventListener('click',v7SaveMotion);
 $('rigMotionTime').addEventListener('input',e=>{v7DraftSample(e.target.value);$('rigTimeValue').textContent=Number(e.target.value).toFixed(2)+'s'});
 $('rigEditMotion').addEventListener('click',()=>{const src=rigStudio.motions.find(m=>m.name===$('rigSavedMotions').value);if(!src)return;
  rigStudio.draft=structuredClone(src);v7StopPreview();v7RefreshMotionUI();$('rigMotionTime').value='0';v7DraftSample(0);v7Save();v7Msg('Editing saved motion '+src.name+'. Save changes to publish the new version.');
 });
 $('rigDeleteMotion').addEventListener('click',()=>{const name=$('rigSavedMotions').value;if(!name)return;
  v7RemoveClipByName('Studio · '+name);rigStudio.motions=rigStudio.motions.filter(m=>m.name!==name);
  if(state.clips.length)chooseClip(state.clips[0]);else{state.selection='idle';state.playing=false}
  if(rigStudio.draft?.name===name)rigStudio.draft=null;v7Save();refreshClipUI();v7RefreshMotionUI();v7Msg('Deleted Studio · '+name+'. Source clips were not touched.');
 });
 $('rigBackup').addEventListener('click',v7ExportBackup);
 v7RefreshUI();
}
v7Init();


// V7.1 production mode: a catalog is a view of ACTUAL clips and engine-listed moves.
// It must never claim an unavailable preset is installed or automatically retargeted.
const v71FavoritesKey='coremotion-v71-motion-favorites';
const v71PreferencesKey='coremotion-v71-advanced';
let v71Favorites=new Set();
try{v71Favorites=new Set(JSON.parse(localStorage.getItem(v71FavoritesKey)||'[]'))}catch{}
function v71GuideMessage(value){const e=$('v71GuideStatus');if(e)e.textContent=value}
function v71MotionCategory(name){
 const s=String(name||'').toLowerCase();
 if(/walk|run|sprint|sneak|crouch|jump|fall|climb|swim|roll|dash|strafe|crawl|turn|fly|hover|slide|locomotion/.test(s))return 'Movement';
 if(/punch|kick|fight|hit|slash|sword|attack|shoot|fire|block|guard|deflect|combo|reload|aim|death|damage|combat|throw/.test(s))return 'Combat';
 if(/idle|wave|dance|talk|cheer|sit|stand|bow|gesture|point|nod|salute|breath|interact/.test(s))return 'Actions';
 return 'Other';
}
function v71MotionSource(){const source=$('v71Source');return source?source.value:'loaded'}
function v71CatalogData(){
 const loaded=state.clips.map((clip,i)=>({key:'clip:'+clip.name,label:clip.name,source:'loaded',index:i,seconds:Number(clip.duration)||0,category:v71MotionCategory(clip.name)}));
 const moves=(typeof furnace!=='undefined'&&furnace.online?furnace.moves:[]).map(move=>({key:'ai:'+move.id,label:move.label||move.id,source:'engine',move:move.id,category:v71MotionCategory(move.label+' '+move.id)}));
 return loaded.concat(moves);
}
function v71RefreshCatalog(){
 const list=$('v71Motions');if(!list)return;
 const query=($('v71Search')?.value||'').trim().toLowerCase();const category=$('v71Category')?.value||'all';const source=v71MotionSource();
 let entries=v71CatalogData().filter(m=>(source==='all'||source===m.source||(source==='favorites'&&v71Favorites.has(m.key)))&&(category==='all'||m.category===category)&&(!query||m.label.toLowerCase().includes(query)||m.category.toLowerCase().includes(query)));
 entries.sort((a,b)=>Number(v71Favorites.has(b.key))-Number(v71Favorites.has(a.key))||a.label.localeCompare(b.label));
 $('v71MotionCount').textContent=entries.length+' shown';list.replaceChildren();
 if(!entries.length){
  const el=document.createElement('div');el.className='v71Empty';
  el.textContent=source==='loaded'?'No matching animation clips on this character. Load a rigged character or attach its saved AssetFurnace motions.':source==='engine'?'No engine moves to display. Start the local AssetFurnace engine and click Check to load its real preset list.':'No motions match this search and category.';
  list.append(el);return;
 }
 for(const m of entries.slice(0,150)){
  const wrap=document.createElement('div');wrap.className='v71Motion'+(m.source==='loaded'&&state.selection==='clip::'+m.label?' v71Active':'');
  const desc=document.createElement('div');desc.style.minWidth='0';
  const name=document.createElement('div');name.className='v71MotionName';name.title=m.label;name.textContent=m.label;
  const meta=document.createElement('div');meta.className='v71MotionMeta';meta.textContent=m.category+' · '+(m.source==='loaded'?('On character · '+m.seconds.toFixed(1)+'s'):'AssetFurnace preset · generate locally');desc.append(name,meta);
  const actions=document.createElement('div');actions.className='v71Actions';
  const favorite=document.createElement('button');favorite.type='button';favorite.className='fav'+(v71Favorites.has(m.key)?' on':'');favorite.textContent=v71Favorites.has(m.key)?'★':'☆';favorite.title='Favorite motion';favorite.setAttribute('aria-label',(v71Favorites.has(m.key)?'Remove favorite ':'Favorite ')+m.label);
  favorite.addEventListener('click',()=>{if(v71Favorites.has(m.key))v71Favorites.delete(m.key);else v71Favorites.add(m.key);try{localStorage.setItem(v71FavoritesKey,JSON.stringify([...v71Favorites]))}catch{}v71RefreshCatalog()});
  const go=document.createElement('button');go.type='button';go.className='primary';go.textContent=m.source==='loaded'?'▶ Preview':'Select AI move';
  go.addEventListener('click',()=>{
   if(m.source==='loaded'){
    if(state.clips[m.index])chooseClip(state.clips[m.index]);
   }else{
    const pick=$('furnaceMove');if(!pick||![...pick.options].some(x=>x.value===m.move)){v71GuideMessage('This move is no longer available from the AI engine. Click Check to refresh.');return}
    pick.value=m.move;v71GuideMessage('Selected '+m.label+'. Choose a rigged character in the local AI library, then click Generate selected move.');
    $('v5Panel')?.scrollIntoView({block:'start',behavior:'smooth'});
   }
  });
  actions.append(favorite,go);wrap.append(desc,actions);list.append(wrap);
 }
 if(entries.length>150){const more=document.createElement('div');more.className='v71Mini';more.textContent='Showing 150 matches. Narrow the search to find more.';list.append(more)}
}
function v71Advanced(enabled){
 $('coreShell').classList.toggle('guided',!enabled);
 $('v71ModeSwitch').textContent=enabled?'✓ Advanced tools · return to simple':'⚙ Advanced tools';
 $('v71ModeSwitch').setAttribute('aria-pressed',String(enabled));
 if(!enabled){
  const pose=$('rigPoseMode');if(pose?.checked){pose.checked=false;v7SetMode(false)}
  const skeleton=$('bonesToggle');if(skeleton?.checked){skeleton.checked=false;showBones(false)}
  $('rigStudioPanel')?.querySelector('details')?.removeAttribute('open');
 }
 try{localStorage.setItem(v71PreferencesKey,enabled?'1':'0')}catch{}
 v71GuideMessage(enabled?'Advanced rigging and timeline controls are visible. Switch back to Simple mode for the five-step workflow.':'Simple mode: upload, generate, choose style, select a real animation, export. Manual rigging is hidden.');
}
function v71Jump(id){const el=$(id);if(el)el.scrollIntoView({behavior:'smooth',block:'start'})}
function v71Init(){
 let advanced=false;try{advanced=localStorage.getItem(v71PreferencesKey)==='1'}catch{}
 v71Advanced(advanced);
 $('v71ModeSwitch').addEventListener('click',()=>v71Advanced($('coreShell').classList.contains('guided')));
 for(const b of document.querySelectorAll('[data-quick]'))b.addEventListener('click',()=>{
  const step=b.dataset.quick;
  if(step==='upload'){v71Jump('imageDrop');$('imageInput').click()}
  else if(step==='generate'){
   v71Jump('v5Panel');if(!state.file)v71GuideMessage('Upload a character image first; then use Generate from uploaded image in the local AI panel.');
   else if(!furnace.online)v71GuideMessage('Start the local AI engine, then click Generate from uploaded image.');
   else v71GuideMessage('Choose Generate through: 3D → Finish → Rig → Animate, then click Generate from uploaded image.');
  }
  else if(step==='styles')v71Jump('v71StylesSection');
  else if(step==='motions'){v71Jump('v71AnimationsSection');$('v71Search').focus({preventScroll:true})}
  else if(step==='export')v71Jump('v71ExportSection');
 });
 for(const id of ['v71Search','v71Source','v71Category'])$(id).addEventListener(id==='v71Search'?'input':'change',v71RefreshCatalog);
 $('v71ImportMotion').addEventListener('click',()=>{
  if(!state.loaded||!state.rigInfo?.skinnedMeshes){v71GuideMessage('Load a properly rigged character before importing a compatible motion GLB.');return}
  $('motionInput').click();
 });
 // Prefer real, available motions; keep the original 18 shortcut buttons under Advanced mode.
 v71RefreshCatalog();
}
v71Init();
