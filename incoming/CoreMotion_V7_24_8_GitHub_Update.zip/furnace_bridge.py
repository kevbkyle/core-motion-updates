"""Core Motion V5: local-only bridge to a separately installed AssetFurnace 0.5.7.
No AI calls, credentials or model weights go to a third-party service.
AssetFurnace endpoints are from its documented studio/MCP workflow.
"""
from __future__ import annotations
import io
import json
import os
import re
import secrets
import shutil
import struct
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from PIL import Image

router = APIRouter(prefix='/api/furnace', tags=['AssetFurnace local bridge'])
ROOT = Path(__file__).resolve().parent
OUTPUTS = ROOT / 'outputs'
OUTPUTS.mkdir(exist_ok=True)
SETTINGS = ROOT / 'furnace_settings.json'
DEFAULT_HOME = r'C:\AI\AssetFurnace'
HOST = 'http://127.0.0.1:8777'  # deliberately loopback only
_lock = threading.Lock()
_process = None

def home() -> Path:
    try:
        data = json.loads(SETTINGS.read_text(encoding='utf8'))
        return Path(data.get('furnace_home') or DEFAULT_HOME)
    except (OSError, ValueError, TypeError):
        return Path(DEFAULT_HOME)

def _auth_headers():
    headers = {'X-AssetFurnace-Client': 'agent', 'User-Agent': 'CoreMotionV5/1.0'}
    token_file = home() / 'output' / '.studio-token'
    if token_file.exists():
        try:
            token = token_file.read_text(encoding='utf8').strip()
            if token: headers['Authorization'] = 'Bearer ' + token
        except OSError: pass
    return headers

def upstream(path: str, *, method: str='GET', payload=None, files=None, timeout: int=25):
    # Path is always chosen in this module; no arbitrary URL or external host is accepted.
    headers = _auth_headers()
    body = None
    if method == 'POST':
        if files is not None:
            boundary = '----coremotion' + secrets.token_hex(12)
            pieces = []
            for name, val in (payload or {}).items():
                pieces.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{val}\r\n'.encode('utf8'))
            for key, (filename, content, ctype) in files.items():
                pieces.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"; filename="{filename}"\r\nContent-Type: {ctype}\r\n\r\n'.encode('utf8'))
                pieces.append(content)
                pieces.append(b'\r\n')
            pieces.append(f'--{boundary}--\r\n'.encode())
            body = b''.join(pieces)
            headers['Content-Type'] = f'multipart/form-data; boundary={boundary}'
        else:
            body = json.dumps(payload or {}).encode('utf8')
            headers['Content-Type'] = 'application/json'
    req = urllib.request.Request(HOST + '/' + path.lstrip('/'), data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            raw = response.read(3*1024*1024)
            return json.loads(raw.decode('utf8'))
    except urllib.error.HTTPError as exc:
        try:
            detail = json.loads(exc.read(4096).decode('utf8')).get('error', '')
        except Exception:
            detail = ''
        raise HTTPException(502, f'AssetFurnace responded {exc.code}: {detail or exc.reason}') from exc
    except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
        raise HTTPException(503, 'AssetFurnace is not answering at 127.0.0.1:8777. Click Start AI Engine. ' + str(exc)[:180]) from exc
    except (ValueError, UnicodeError) as exc:
        raise HTTPException(502, 'Invalid response from AssetFurnace: ' + str(exc)[:180]) from exc

def catalog(): return upstream('api/catalog')

def _ping() -> bool:
    try:
        catalog()
        return True
    except HTTPException:
        return False

@router.get('/status')
def status():
    configured = home()
    online = _ping()
    base = {'online': online, 'home': str(configured), 'installed': configured.is_dir(),
            'has_launcher': (configured/'lab.cmd').is_file(),
            'message': 'Connected to local Pixal3D/SkinTokens' if online else 'AI engine is not running. Click Start AI Engine.'}
    if online:
        try:
            c = catalog()
            base['engines'] = [{'id': x.get('id'), 'label': x.get('label'), 'state': x.get('state')}
                               for x in c.get('backends', []) if x.get('kind') == '3d']
        except HTTPException: pass
    return base

@router.post('/config')
def config(body: dict):
    raw = str(body.get('furnace_home') or '').strip()
    candidate = Path(raw)
    if not candidate.is_dir() or not ((candidate/'lab.cmd').is_file() or (candidate/'viewer'/'serve.py').is_file()):
        raise HTTPException(400, 'Choose your AssetFurnace folder containing lab.cmd (usually C:\\AI\\AssetFurnace).')
    SETTINGS.write_text(json.dumps({'furnace_home':str(candidate)}, indent=2), encoding='utf8')
    return {'saved': True, 'home': str(candidate)}

@router.post('/start')
def start():
    global _process
    if _ping(): return {'online': True, 'message': 'AssetFurnace was already running.'}
    h = home()
    lab = h / 'lab.cmd'
    if os.name != 'nt' or not lab.is_file():
        raise HTTPException(503, f'Automatic start requires Windows and {lab}. Start AssetFurnace manually with .\\lab.')
    with _lock:
        if _process is None or _process.poll() is not None:
            output = ROOT / 'outputs' / 'furnace_background.log'
            stream = output.open('ab', buffering=0)
            try:
                _process = subprocess.Popen(['cmd.exe','/c',str(lab)], cwd=str(h),
                    stdout=stream, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                    creationflags=getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0))
            finally: stream.close()
    return {'online': False, 'starting': True, 'message': 'Starting AssetFurnace locally. Check status again when its server is ready.'}

@router.get('/moves')
def moves():
    obj = upstream('api/animate/models')
    return {'installed': bool(obj.get('installed')),
            'moves': [{'id': x.get('id'), 'label': x.get('label'), 'seconds': x.get('seconds')}
                      for x in obj.get('presets', []) if x.get('id') and x.get('label')]}

@router.get('/assets')
def assets():
    data = upstream('api/assets')
    items = []
    for a in data.get('assets', []):
        if a.get('hidden') or not a.get('id'):
            continue
        clips = a.get('clips') or []
        items.append({'id': a['id'], 'name': a.get('name') or 'Unnamed character',
            'kind': a.get('kind') or 'character', 'has_rig':bool(a.get('rigged')),
            'has_model':bool(a.get('model')), 'clips':[c.get('name') for c in clips if isinstance(c,dict)]})
    return {'assets': items}

@router.get('/assets/{asset_id}/delete-plan')
def preview_asset_delete(asset_id: str):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', asset_id):
        raise HTTPException(400, 'Invalid asset id.')
    known = assets()['assets']
    if not any(a['id'] == asset_id for a in known):
        raise HTTPException(404, 'Character is not in the AssetFurnace library.')
    return upstream('api/assets/' + asset_id + '/delete-plan')

@router.post('/assets/{asset_id}/delete')
def delete_asset(asset_id: str, confirmation: dict):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', asset_id):
        raise HTTPException(400, 'Invalid asset id.')
    if confirmation.get('confirm') is not True:
        raise HTTPException(400, 'Permanent deletion requires explicit confirmation.')
    plan = preview_asset_delete(asset_id)
    if plan.get('refused'):
        raise HTTPException(409, str(plan['refused']))
    # AssetFurnace itself owns and deletes only the selected version's run folders.
    # Never delete arbitrary paths or directly modify its database from CoreMotion.
    return upstream('api/assets/' + asset_id + '/delete', method='POST', payload={'confirm': True})

@router.post('/create')
async def create(image: UploadFile=File(...), title: str=Form('My Character'),
                 first_move: str=Form(''), stop_after: str=Form('animated')):
    if stop_after not in ('model', 'rigged', 'animated'):
        raise HTTPException(400, 'Stop-after must be model, rigged, or animated.')
    # The upstream AI engine validates whether Pixal3D is ready; its catalog state
    # field differs between AssetFurnace releases, so do not assume one label.
    catalog()
    raw = await image.read(16*1024*1024+1)
    if len(raw)>16*1024*1024: raise HTTPException(413, 'Image exceeds 16 MB.')
    try:
        test = Image.open(io.BytesIO(raw)); test.verify()
        img = Image.open(io.BytesIO(raw)).convert('RGBA')
        buf = io.BytesIO(); img.save(buf, format='PNG'); raw = buf.getvalue()
    except Exception as exc: raise HTTPException(400, 'Please upload a valid character PNG/JPEG/WebP.') from exc
    steps = ['model']
    if stop_after in ('rigged','animated'): steps.extend(['finished','rigged'])
    if stop_after == 'animated':
        if not first_move: raise HTTPException(400, 'Choose a first animation.')
        moves_list = moves()['moves']
        if first_move not in {m['id'] for m in moves_list}:
            raise HTTPException(400, 'Selected animation is unavailable in AssetFurnace.')
        steps.append('animated')
    fields = {'title': re.sub(r'[\r\n]', ' ', title)[:96] or 'My Character',
              'steps':json.dumps(steps), 'want':'character', 'made':'{}',
              'engine':'pixal3d', 'model_seed':str(secrets.randbelow(2**24)),
              'finish_settings':json.dumps({'faces':20000})}
    if first_move and 'animated' in steps: fields['first_move'] = first_move
    result = upstream('api/chains',method='POST',payload=fields,
        files={'file':('character.png', raw, 'image/png')},timeout=90)
    return {'run_id': result.get('id'), 'steps': steps, 'message': 'AssetFurnace started your local generation pipeline.'}

@router.post('/animate-existing')
def animate_existing(body: dict):
    aid = str(body.get('asset_id') or '').strip()
    move = str(body.get('move') or '').strip()
    if not aid or not move: raise HTTPException(400,'Select an asset and an animation.')
    preset_ids = {m['id'] for m in moves()['moves']}
    if move not in preset_ids: raise HTTPException(400, 'That move is not available in AssetFurnace.')
    all_assets = upstream('api/assets').get('assets',[])
    asset = next((x for x in all_assets if x.get('id') == aid), None)
    if not asset: raise HTTPException(404, 'Asset not found in AssetFurnace Library.')
    if not asset.get('rigged'): raise HTTPException(400, 'This character is not rigged yet.')
    made = {k:asset[k] for k in ('picture','back','model','finished','rigged') if asset.get(k)}
    fields={'title': str(asset.get('name') or 'Character'), 'steps':json.dumps(['animated']),
        'want':'character', 'made':json.dumps(made), 'first_move':move}
    result = upstream('api/chains',method='POST',payload=fields,files={},timeout=50)
    return {'run_id':result.get('id'),'message': 'Generating another clip for the same rigged character.'}

@router.get('/run/{run_id}')
def run(run_id: str):
    if not re.fullmatch(r'[\da-fA-F-]{8,64}', run_id): raise HTTPException(400, 'Invalid run id')
    obj = upstream('api/chains/' + run_id)
    return obj

@router.post('/cancel/{run_id}')
def cancel(run_id: str):
    if not re.fullmatch(r'[\da-fA-F-]{8,64}', run_id): raise HTTPException(400,'Invalid run id')
    return upstream('api/chains/' + run_id + '/cancel',method='POST',payload={},files={})

def _asset_glb_candidates(value):
    """Find a valid GLB under AssetFurnace without trusting arbitrary paths.

    AssetFurnace releases may return full paths, relative output paths, or
    file metadata objects. A relative path must not be interpreted relative to
    the CoreMotion process working directory.
    """
    if isinstance(value, dict):
        for key in ('file', 'path', 'url', 'output', 'glb'):
            if value.get(key):
                yield from _asset_glb_candidates(value[key])
        return
    if not isinstance(value, str) or not value.strip():
        return
    value=value.strip()
    if value.startswith('file:///'):
        from urllib.parse import unquote, urlsplit
        uri=urlsplit(value)
        value=unquote(uri.path)
        if os.name=='nt' and re.match(r'^/[A-Za-z]:/',value):
            value=value[1:]
    elif '://' in value:
        return  # Do not fetch remote or arbitrary service URLs.
    configured=home().resolve()
    raw=Path(value)
    variants=[raw] if raw.is_absolute() else [configured/raw, configured/'output'/raw]
    seen=set()
    for candidate in variants:
        resolved=candidate.resolve()
        if resolved in seen: continue
        seen.add(resolved)
        if not resolved.is_relative_to(configured):
            continue
        if resolved.is_file() and resolved.suffix.lower()=='.glb':
            yield resolved


def _asset_glb(value):
    return next(_asset_glb_candidates(value), None)


def _asset_glb_scene_info(path: Path) -> dict:
    """Small, bounded GLB JSON inspection; avoid selecting an animation-only GLB."""
    try:
        with path.open('rb') as f:
            header=f.read(20)
            if len(header)!=20 or header[:4]!=b'glTF': return {'meshes':False,'skinned':False}
            version,total=struct.unpack_from('<II',header,4)
            length,chunk=struct.unpack_from('<I4s',header,12)
            if version!=2 or chunk!=b'JSON' or length>4*1024*1024 or length>total-20:
                return {'meshes':False,'skinned':False}
            data=json.loads(f.read(length))
        nodes=data.get('nodes') or []
        has_mesh=bool(data.get('meshes')) and any('mesh' in n for n in nodes)
        has_skin=has_mesh and bool(data.get('skins')) and any('mesh' in n and 'skin' in n for n in nodes)
        return {'meshes':bool(has_mesh),'skinned':bool(has_skin)}
    except (OSError,ValueError,KeyError,TypeError,struct.error):
        return {'meshes':False,'skinned':False}

@router.get('/import/{asset_id}')
def import_asset(asset_id: str):
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,100}', asset_id): raise HTTPException(400, 'Invalid asset id')
    from_asset = upstream('api/assets').get('assets',[])
    asset = next((a for a in from_asset if a.get('id') == asset_id), None)
    if not asset: raise HTTPException(404, 'Asset not in AssetFurnace Library.')

    # The general model-info response may point to an EARLY unrigged mesh.
    # Never let it outrank a real skinned GLB. Inspect the glTF JSON header
    # (no geometry decode needed) to prefer a weighted, visible character.
    candidates=[(key,asset.get(key)) for key in ('rigged','finished','model')]
    try:
        detail=upstream('api/model-info?' + urllib.parse.urlencode({'asset':asset_id,'stage':'latest'}))
        candidates.append(('model-info',detail))
    except HTTPException:
        pass
    candidates.extend(('clip',clip) for clip in reversed(asset.get('clips') or []) if isinstance(clip,dict))
    ranked=[]
    for stage,value in candidates:
        candidate=_asset_glb(value)
        if not candidate: continue
        info=_asset_glb_scene_info(candidate)
        if not info['meshes']: continue  # Motion-only GLBs cannot show a character.
        priority={'rigged':5,'finished':4,'model-info':3,'model':2,'clip':1}[stage]
        ranked.append((int(info['skinned'])*100+priority,candidate,stage,info))
    ranked.sort(key=lambda item:item[0],reverse=True)
    src=ranked[0][1] if ranked else None
    selected_stage=ranked[0][2] if ranked else None
    selected_info=ranked[0][3] if ranked else None
    if src is None:
        present=', '.join(key for key in ('rigged','finished','model') if asset.get(key)) or 'none'
        raise HTTPException(404,
            'No accessible GLB was found under the configured AssetFurnace folder. '
            'Asset record fields present: '+present+'. '
            'Check that the selected character has finished generating, and that '
            'CoreMotion points to the AssetFurnace installation containing its outputs.')
    if src.stat().st_size > 150*1024*1024:
        raise HTTPException(413, 'GLB exceeds 150 MB. Please export a game-ready version from AssetFurnace.')
    job_id=uuid.uuid4().hex[:14]
    folder=OUTPUTS/job_id
    folder.mkdir(parents=True,exist_ok=True)
    target=folder/'assetfurnace.glb'
    shutil.copy2(src,target)
    return {'url':f'/outputs/{job_id}/assetfurnace.glb',
            'name':asset.get('name') or 'AssetFurnace character',
            'size':target.stat().st_size,
            'source_stage':selected_stage,'source_skinned':bool(selected_info and selected_info['skinned']),
            'message':'Loaded a copy. The original AssetFurnace model is unchanged.'}

@router.get('/clip/{asset_id}/{clip_index}')
def import_clip(asset_id: str, clip_index: int):
    """Copy one animation GLB from AssetFurnace's Library into Core Motion's outputs.
    Separate clips can be loaded into an already-open compatible skeleton."""
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',asset_id):
        raise HTTPException(400,'Invalid asset id')
    assets = upstream('api/assets').get('assets', [])
    asset = next((x for x in assets if x.get('id') == asset_id), None)
    if not asset: raise HTTPException(404,'Asset not found.')
    clips = asset.get('clips') or []
    if clip_index < 0 or clip_index >= len(clips): raise HTTPException(404,'Clip not found')
    c=clips[clip_index]
    raw=c.get('file') if isinstance(c,dict) else None
    if not raw: raise HTTPException(404,'This clip has no file.')
    src=_asset_glb(raw)
    if src is None: raise HTTPException(404,'Clip GLB is missing or outside the configured AssetFurnace folder.')
    if src.stat().st_size>150*1024*1024: raise HTTPException(413,'Clip is larger than 150 MB.')
    job_id=uuid.uuid4().hex[:14]
    dest=OUTPUTS/job_id;dest.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dest/'animation.glb')
    return {'url':f'/outputs/{job_id}/animation.glb','name':c.get('name') or f'Clip {clip_index+1}'}


# V7.8: local-only AI motion direction. The LLM interprets words into bounded,
# non-destructive motion-style parameters; it does NOT generate motion capture.
# No arbitrary URL, remote provider, file uploads or access tokens are accepted.
OLLAMA_HOST='http://127.0.0.1:11434'
MOTION_KEYS=('armSwing','hipSway','shoulderRoll','armWidth','lean','bounce','exaggeration')

def motion_ollama(path, payload=None, timeout=10):
    import urllib.request, urllib.error
    url=OLLAMA_HOST+path
    data=None if payload is None else json.dumps(payload).encode('utf-8')
    request=urllib.request.Request(url, data=data, method='POST' if payload is not None else 'GET',
        headers={'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(request,timeout=timeout) as reply:
            raw=reply.read(1024*1024)
        return json.loads(raw.decode('utf-8'))
    except (urllib.error.URLError, TimeoutError, OSError) as ex:
        raise HTTPException(503, 'Ollama is not available on this computer. Install Ollama and run: ollama pull llama3.2:3b. '+str(ex)[:90]) from ex
    except (ValueError, UnicodeError) as ex:
        raise HTTPException(502, 'Local AI returned unreadable JSON.') from ex

def motion_models():
    payload=motion_ollama('/api/tags', timeout=4)
    models=[]
    for item in payload.get('models',[]):
        name=item.get('name') if isinstance(item,dict) else None
        if isinstance(name,str) and 0<len(name)<180: models.append(name)
    return models

@router.get('/motion-director/models')
def motion_director_models():
    return {'models':motion_models(), 'provider':'local Ollama', 'mode':'language-to-motion-parameters'}

@router.post('/motion-director/edit')
def motion_director_edit(body:dict):
    prompt=str(body.get('prompt') or '').strip()
    clip=str(body.get('clip') or 'Animation')[:100]
    model=str(body.get('model') or '')
    if not prompt or len(prompt)>500: raise HTTPException(400,'Motion prompt must be 1–500 characters.')
    if model not in motion_models(): raise HTTPException(400,'Choose an installed Ollama model using Check AI.')
    current=body.get('current') if isinstance(body.get('current'),dict) else {}
    import math
    def clamp(x,key):
        try: x=float(x)
        except (TypeError,ValueError): x=0.0
        if not math.isfinite(x): x=0.0
        return round(max(-1.0 if key=='lean' else 0.0,min(1.0,x)),3)
    default={k:clamp(current.get(k,0),k) for k in MOTION_KEYS}
    schema={'type':'object','properties':{
        **{k:{'type':'number','minimum':-1 if k=='lean' else 0,'maximum':1} for k in MOTION_KEYS},
        'summary':{'type':'string'}},'required':[*MOTION_KEYS,'summary']}
    guidance='''You are a motion-style parameter director for a skinned humanoid 3D game animation.
Your job is to interpret the player's requested movement STYLE into numerical parameters.
You are NOT generating a new motion, modifying geometry, or inventing a new animation clip.
Return ONLY valid JSON adhering to the provided schema. Numbers must stay in the stated ranges.
armSwing: 0..1 extra opposing arm swing. hipSway: 0..1 side-to-side hips.
shoulderRoll: 0..1 relaxed rolling shoulder rhythm. armWidth: 0..1 arms farther from the hips/torso. lean: -1..1 backwards/forwards lean.
bounce: 0..1 subtle rhythmic body bob. exaggeration: 0..1 bigger gait/gesture.
Favor natural movement, and use smaller values (0.1-0.5) unless asked for very exaggerated.
For swagger/swag emphasize hipSway and loose shoulders. For stealth use small armSwing,bounce.
When asked for bigger arm swings choose armSwing 0.5-0.9. When asked for arms wider/from hips set armWidth 0.3-0.8.
Only describe effects that these controls can produce. If the user requests an unsupported
change (e.g. jump to the moon, actual new sword choreography), say that the edit controls
cannot create that new move and provide the closest style adjustment.
Keep the summary short and describe applied parameter style changes, not promises.'''
    user='Current clip: '+clip+'\nRequested change: '+prompt+'\nCurrent values: '+json.dumps(default)
    response=motion_ollama('/api/chat',{'model':model,'stream':False,'format':schema,
        'options':{'temperature':0.1,'num_predict':190},
        'messages':[{'role':'system','content':guidance},{'role':'user','content':user}]}, timeout=120)
    try: result=json.loads(response['message']['content'])
    except (KeyError,TypeError,ValueError) as ex: raise HTTPException(502,'AI produced invalid motion parameters. Try the prompt again.') from ex
    if not isinstance(result,dict): raise HTTPException(502,'Local AI did not return a parameter object.')
    profile={k:clamp(result.get(k,default[k]),k) for k in MOTION_KEYS}
    summary=str(result.get('summary') or 'Applied motion-style controls.')[:250]
    return {'profile':profile,'summary':summary,'model':model,'mode':'AI-interpreted procedural style, not text-to-motion synthesis'}
